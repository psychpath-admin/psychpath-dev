const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function getAccessToken() {
  return localStorage.getItem('accessToken')
}

function getRefreshToken() {
  return localStorage.getItem('refreshToken')
}

export function logout() {
  localStorage.removeItem('accessToken')
  localStorage.removeItem('refreshToken')
}

async function refreshToken() {
  const refresh = getRefreshToken()
  if (!refresh) return false
  const res = await fetch(`${API_URL}/api/auth/token/refresh/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh }),
  })
  if (!res.ok) {
    logout()
    return false
  }
  const data = await res.json()
  if (data?.access) {
    localStorage.setItem('accessToken', data.access)
    return true
  }
  return false
}

export async function apiFetch(path: string, options: RequestInit = {}) {
  const token = getAccessToken()
  const isFormData = options?.body instanceof FormData
  const baseHeaders: Record<string, string> = { ...(options.headers as any) }
  // Only set Content-Type for non-FormData payloads; browser will set boundary for FormData
  if (!isFormData && !baseHeaders['Content-Type']) {
    baseHeaders['Content-Type'] = 'application/json'
  }
  if (token) baseHeaders['Authorization'] = `Bearer ${token}`

  let res = await fetch(`${API_URL}${path}`, { ...options, headers: baseHeaders })
  if (res.status === 401 && getRefreshToken()) {
    const ok = await refreshToken()
    if (ok) {
      const newToken = getAccessToken()
      const retryHeaders = { ...baseHeaders }
      if (newToken) retryHeaders['Authorization'] = `Bearer ${newToken}`
      res = await fetch(`${API_URL}${path}`, { ...options, headers: retryHeaders })
    }
  }
  return res
}

// Registrar Logbook APIs
export type RegistrarWeek = {
  id: number
  week_starting: string
  status: 'draft' | 'submitted' | 'returned'
  dcc_minutes: number
  cra_minutes: number
  pd_minutes: number
}

export type RegistrarEntry = {
  id: number
  week: number
  date: string
  duration_minutes: number
  category: 'direct_client_contact' | 'client_related_activity' | 'professional_development'
  short_description: string
  reflection: string
  aope?: string
}

export async function getRegistrarWeeks(): Promise<RegistrarWeek[]> {
  const res = await apiFetch('/api/registrar/weeks/')
  if (!res.ok) throw new Error('Failed to fetch registrar weeks')
  return res.json()
}

export async function createRegistrarWeek(payload: { week_starting: string }): Promise<RegistrarWeek> {
  const res = await apiFetch('/api/registrar/weeks/', {
    method: 'POST',
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error('Failed to create week')
  return res.json()
}

export async function submitRegistrarWeek(weekId: number) {
  const res = await apiFetch(`/api/registrar/weeks/${weekId}/submit/`, { method: 'POST' })
  if (!res.ok) throw new Error('Failed to submit week')
  return res.json()
}

export async function getRegistrarStats(): Promise<{ pd_this_year_hours: number; pd_required_hours: number; meets_pd_requirement: boolean }> {
  const res = await apiFetch('/api/registrar/weeks/stats/')
  if (!res.ok) throw new Error('Failed to fetch registrar stats')
  return res.json()
}

export async function getRegistrarEntries(): Promise<RegistrarEntry[]> {
  const res = await apiFetch('/api/registrar/entries/')
  if (!res.ok) throw new Error('Failed to fetch registrar entries')
  return res.json()
}

export async function createRegistrarEntry(payload: Partial<RegistrarEntry> & { duration_hours?: number }) {
  const res = await apiFetch('/api/registrar/entries/', { method: 'POST', body: JSON.stringify(payload) })
  if (!res.ok) throw new Error('Failed to create entry')
  return res.json()
}

export { API_URL }

// Auth functions
export async function login(email: string, password: string) {
  const res = await fetch(`${API_URL}/api/auth/token/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: email, password }),
  })
  if (!res.ok) throw new Error('Login failed')
  const data = await res.json()
  localStorage.setItem('accessToken', data.access)
  localStorage.setItem('refreshToken', data.refresh)
  return data
}

export async function register(email: string, password: string, role: string, organization?: string) {
  const res = await fetch(`${API_URL}/api/auth/register/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, role, organization }),
  })
  if (!res.ok) throw new Error('Registration failed')
  return res.json()
}

export async function getMe() {
  const res = await apiFetch('/api/me/')
  if (!res.ok) throw new Error('Failed to get user info')
  return res.json()
}

// Logbook functions
export async function getLogbooks() {
  const res = await apiFetch('/api/logbook/logbooks/')
  if (!res.ok) throw new Error('Failed to fetch logbooks')
  return res.json()
}

export async function getLogbook(id: number) {
  const res = await apiFetch(`/api/logbook/logbooks/${id}/`)
  if (!res.ok) throw new Error('Failed to fetch logbook')
  return res.json()
}

export async function createLogbook(data: any) {
  const res = await apiFetch('/api/logbook/logbooks/', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to create logbook')
  return res.json()
}

export async function updateLogbook(id: number, data: any) {
  const res = await apiFetch(`/api/logbook/logbooks/${id}/`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to update logbook')
  return res.json()
}

export async function submitLogbook(id: number, comments?: string) {
  const res = await apiFetch(`/api/logbook/logbooks/${id}/submit/`, {
    method: 'POST',
    body: JSON.stringify({ comments }),
  })
  if (!res.ok) throw new Error('Failed to submit logbook')
  return res.json()
}

export async function approveLogbook(id: number, action: 'approve' | 'reject', comments?: string) {
  const res = await apiFetch(`/api/logbook/logbooks/${id}/approve/`, {
    method: 'POST',
    body: JSON.stringify({ action, comments }),
  })
  if (!res.ok) throw new Error('Failed to approve/reject logbook')
  return res.json()
}

export async function downloadLogbookPDF(id: number) {
  const res = await apiFetch(`/api/logbook/logbooks/${id}/pdf/`)
  if (!res.ok) throw new Error('Failed to download PDF')
  return res.blob()
}

// Logbook entry functions
export async function getLogbookEntries(logbookId: number, type: 'dcc' | 'cra' | 'pd' | 'sup') {
  const res = await apiFetch(`/api/logbook/logbooks/${logbookId}/${type}-entries/`)
  if (!res.ok) throw new Error('Failed to fetch entries')
  return res.json()
}

export async function createLogbookEntry(logbookId: number, type: 'dcc' | 'cra' | 'pd' | 'sup', data: any) {
  const res = await apiFetch(`/api/logbook/logbooks/${logbookId}/${type}-entries/`, {
    method: 'POST',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to create entry')
  return res.json()
}

export async function updateLogbookEntry(logbookId: number, type: 'dcc' | 'cra' | 'pd' | 'sup', entryId: number, data: any) {
  const res = await apiFetch(`/api/logbook/logbooks/${logbookId}/${type}-entries/${entryId}/`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to update entry')
  return res.json()
}

export async function deleteLogbookEntry(logbookId: number, type: 'dcc' | 'cra' | 'pd' | 'sup', entryId: number) {
  const res = await apiFetch(`/api/logbook/logbooks/${logbookId}/${type}-entries/${entryId}/`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error('Failed to delete entry')
  return res.json()
}

// Section A API functions
export async function getSectionAEntries() {
  const res = await apiFetch('/api/section-a/entries/')
  if (!res.ok) throw new Error('Failed to fetch Section A entries')
  return res.json()
}

export async function getSectionAEntry(id: number) {
  const res = await apiFetch(`/api/section-a/entries/${id}/`)
  if (!res.ok) throw new Error('Failed to fetch Section A entry')
  return res.json()
}

export async function createSectionAEntry(data: any) {
  const res = await apiFetch('/api/section-a/entries/', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to create Section A entry')
  return res.json()
}

export async function updateSectionAEntry(id: number, data: any) {
  const res = await apiFetch(`/api/section-a/entries/${id}/`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  if (!res.ok) throw new Error('Failed to update Section A entry')
  return res.json()
}

export async function deleteSectionAEntry(id: number) {
  const res = await apiFetch(`/api/section-a/entries/${id}/`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error('Failed to delete Section A entry')
  return res.json()
}

// Client autocomplete
export async function getClientAutocomplete(query: string) {
  const res = await apiFetch(`/api/section-a/entries/client_autocomplete/?q=${encodeURIComponent(query)}`)
  if (!res.ok) throw new Error('Failed to fetch client autocomplete')
  return res.json()
}

// Last session data
export async function getLastSessionData(clientId: string) {
  const res = await apiFetch(`/api/section-a/entries/last_session_data/?client_id=${encodeURIComponent(clientId)}`)
  if (res.status === 404) {
    return null
  }
  if (!res.ok) throw new Error('Failed to fetch last session data')
  return res.json()
}

// Custom activity types
export async function getCustomActivityTypes() {
  const res = await apiFetch('/api/section-a/custom-activity-types/')
  if (!res.ok) throw new Error('Failed to fetch custom activity types')
  return res.json()
}

export async function createCustomActivityType(name: string) {
  const res = await apiFetch('/api/section-a/custom-activity-types/', {
    method: 'POST',
    body: JSON.stringify({ name }),
  })
  if (!res.ok) throw new Error('Failed to create custom activity type')
  return res.json()
}

export async function deleteCustomActivityType(id: number) {
  const res = await apiFetch(`/api/section-a/custom-activity-types/${id}/`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error('Failed to delete custom activity type')
  return res.json()
}

// Section B - Professional Development API functions
import type { PDEntry, PDCompetency, PDWeeklyGroup, PDMetrics } from '@/types/pd'

// Section C - Supervision API functions
import type { SupervisionEntry, SupervisionWeeklyGroup, SupervisionMetrics } from '@/types/supervision'
import type { ProgramSummary } from '@/types/program'

export async function getPDEntries(): Promise<PDEntry[]> {
  const res = await apiFetch('/api/section-b/entries/')
  if (!res.ok) throw new Error('Failed to fetch PD entries')
  return res.json()
}

export async function getPDEntriesGroupedByWeek(): Promise<PDWeeklyGroup[]> {
  const res = await apiFetch('/api/section-b/entries/grouped-by-week/')
  if (!res.ok) throw new Error('Failed to fetch PD entries grouped by week')
  return res.json()
}

export async function getPDCompetencies(): Promise<PDCompetency[]> {
  const res = await apiFetch('/api/section-b/competencies/')
  if (!res.ok) throw new Error('Failed to fetch PD competencies')
  return res.json()
}

export async function getPDMetrics(): Promise<PDMetrics> {
  const res = await apiFetch('/api/section-b/summary-metrics/')
  if (!res.ok) throw new Error('Failed to fetch PD metrics')
  return res.json()
}

export async function createPDEntry(entry: Partial<PDEntry>): Promise<PDEntry> {
  const res = await apiFetch('/api/section-b/entries/', {
    method: 'POST',
    body: JSON.stringify(entry)
  })
  if (!res.ok) throw new Error('Failed to create PD entry')
  return res.json()
}

export async function updatePDEntry(id: number, entry: Partial<PDEntry>): Promise<PDEntry> {
  const res = await apiFetch(`/api/section-b/entries/${id}/`, {
    method: 'PUT',
    body: JSON.stringify(entry)
  })
  if (!res.ok) throw new Error('Failed to update PD entry')
  return res.json()
}

export async function deletePDEntry(id: number): Promise<void> {
  const res = await apiFetch(`/api/section-b/entries/${id}/`, {
    method: 'DELETE'
  })
  if (!res.ok) throw new Error('Failed to delete PD entry')
}

// Section C - Supervision API functions
export async function getSupervisionEntries(): Promise<SupervisionEntry[]> {
  const res = await apiFetch('/api/section-c/entries/')
  if (!res.ok) throw new Error('Failed to fetch supervision entries')
  return res.json()
}

export async function getSupervisionEntriesGroupedByWeek(): Promise<SupervisionWeeklyGroup[]> {
  const res = await apiFetch('/api/section-c/entries/grouped-by-week/')
  if (!res.ok) throw new Error('Failed to fetch supervision entries grouped by week')
  return res.json()
}

export async function getSupervisionMetrics(): Promise<SupervisionMetrics> {
  const res = await apiFetch('/api/section-c/entries/summary_metrics/')
  if (!res.ok) throw new Error('Failed to fetch supervision metrics')
  return res.json()
}

export async function createSupervisionEntry(entry: Partial<SupervisionEntry>): Promise<SupervisionEntry> {
  const res = await apiFetch('/api/section-c/entries/', {
    method: 'POST',
    body: JSON.stringify(entry)
  })
  if (!res.ok) throw new Error('Failed to create supervision entry')
  return res.json()
}

export async function updateSupervisionEntry(id: number, entry: Partial<SupervisionEntry>): Promise<SupervisionEntry> {
  const res = await apiFetch(`/api/section-c/entries/${id}/`, {
    method: 'PUT',
    body: JSON.stringify(entry)
  })
  if (!res.ok) throw new Error('Failed to update supervision entry')
  return res.json()
}

export async function deleteSupervisionEntry(id: number): Promise<void> {
  const res = await apiFetch(`/api/section-c/entries/${id}/`, {
    method: 'DELETE'
  })
  if (!res.ok) throw new Error('Failed to delete supervision entry')
}

// Program Summary API
export async function getProgramSummary(): Promise<ProgramSummary> {
  const res = await apiFetch('/api/program-summary/')
  if (!res.ok) throw new Error('Failed to fetch program summary')
  return res.json()
}


