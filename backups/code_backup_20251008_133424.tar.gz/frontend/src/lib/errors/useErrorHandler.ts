import { useState, useCallback } from 'react'
import type { ErrorDetails, ErrorOverlayProps } from './types'
import { logError, createErrorDetails } from './errorLogger'

/**
 * Error Handler Hook
 * 
 * Provides a complete error handling solution with:
 * - Error overlay state management
 * - Automatic error logging
 * - Consistent error display
 * - Easy integration with any component
 */
export const useErrorHandler = () => {
  const [errorOverlay, setErrorOverlay] = useState<ErrorOverlayProps>({
    error: {
      title: '',
      summary: '',
      explanation: '',
      userAction: ''
    },
    isOpen: false,
    onClose: () => {},
    onGetHelp: () => {}
  })

  /**
   * Show an error overlay with automatic logging
   */
  const showError = useCallback(async (
    error: Error | string | any,
    context?: {
      title?: string
      category?: ErrorDetails['category']
      customExplanation?: string
      customUserAction?: string
    }
  ) => {
    try {
      // Create standardized error details
      const errorDetails = createErrorDetails(error, context)
      
      // Log the error automatically
      await logError(errorDetails)
      
      // Show the error overlay
      setErrorOverlay({
        error: errorDetails,
        isOpen: true,
        onClose: () => setErrorOverlay(prev => ({ ...prev, isOpen: false })),
        onGetHelp: () => {
          // Build URL with error details for highlighting
          const params = new URLSearchParams()
          if (errorDetails.errorId) {
            params.set('errorId', errorDetails.errorId)
          }
          if (errorDetails.summary) {
            params.set('summary', errorDetails.summary)
          }
          if (errorDetails.explanation) {
            params.set('explanation', errorDetails.explanation)
          }
          if (errorDetails.userAction) {
            params.set('userAction', errorDetails.userAction)
          }
          
          const helpUrl = params.toString() ? `/help/errors?${params.toString()}` : '/help/errors'
          window.open(helpUrl, '_blank')
        }
      })
    } catch (logError) {
      console.error('Failed to show error:', logError)
    }
  }, [])

  /**
   * Show a custom error with specific details
   */
  const showCustomError = useCallback(async (errorDetails: ErrorDetails) => {
    try {
      // Log the error automatically
      await logError(errorDetails)
      
      // Show the error overlay
      setErrorOverlay({
        error: errorDetails,
        isOpen: true,
        onClose: () => setErrorOverlay(prev => ({ ...prev, isOpen: false })),
        onGetHelp: () => {
          // Build URL with error details for highlighting
          const params = new URLSearchParams()
          if (errorDetails.errorId) {
            params.set('errorId', errorDetails.errorId)
          }
          if (errorDetails.summary) {
            params.set('summary', errorDetails.summary)
          }
          if (errorDetails.explanation) {
            params.set('explanation', errorDetails.explanation)
          }
          if (errorDetails.userAction) {
            params.set('userAction', errorDetails.userAction)
          }
          
          const helpUrl = params.toString() ? `/help/errors?${params.toString()}` : '/help/errors'
          window.open(helpUrl, '_blank')
        }
      })
    } catch (logError) {
      console.error('Failed to show custom error:', logError)
    }
  }, [])

  /**
   * Hide the error overlay
   */
  const hideError = useCallback(() => {
    setErrorOverlay(prev => ({ ...prev, isOpen: false }))
  }, [])

  /**
   * Handle API errors with automatic categorization
   */
  const handleApiError = useCallback(async (
    error: any,
    context?: {
      title?: string
      customExplanation?: string
      customUserAction?: string
    }
  ) => {
    const status = error?.status || error?.response?.status
    
    let title = context?.title || `API Error (${status})`
    let explanation = context?.customExplanation
    let userAction = context?.customUserAction

    // Provide context-specific messages based on status codes
    if (status === 400) {
      title = 'Invalid Request'
      explanation = explanation || 'The request was invalid or missing required information.'
      userAction = userAction || 'Please check your input and try again.'
    } else if (status === 401) {
      title = 'Authentication Required'
      explanation = explanation || 'You need to log in to access this resource.'
      userAction = userAction || 'Please log in and try again.'
    } else if (status === 403) {
      title = 'Access Denied'
      explanation = explanation || 'You don\'t have permission to perform this action.'
      userAction = userAction || 'Contact your administrator if you believe this is an error.'
    } else if (status === 404) {
      title = 'Resource Not Found'
      explanation = explanation || 'The requested resource could not be found.'
      userAction = userAction || 'Please check the URL or contact support if you believe this is an error.'
    } else if (status === 500) {
      title = 'Server Error'
      explanation = explanation || 'The server encountered an unexpected error.'
      userAction = userAction || 'Please try again later or contact support if the issue persists.'
    } else if (status >= 500) {
      title = 'Server Error'
      explanation = explanation || 'The server is experiencing issues.'
      userAction = userAction || 'Please try again later or contact support.'
    } else {
      title = title || 'Request Failed'
      explanation = explanation || 'The request could not be completed.'
      userAction = userAction || 'Please try again or contact support if the issue persists.'
    }

    await showError(error, {
      title,
      category: 'Network',
      customExplanation: explanation,
      customUserAction: userAction
    })
  }, [showError])

  return {
    errorOverlay,
    showError,
    showCustomError,
    hideError,
    handleApiError
  }
}

export default useErrorHandler
