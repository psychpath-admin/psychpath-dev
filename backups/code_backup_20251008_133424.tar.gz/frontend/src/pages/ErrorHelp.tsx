import React from 'react'
import { ErrorHelpPage } from '@/lib/errors'

export default function ErrorHelp() {
  return <ErrorHelpPage showSupportForm={true} />
}