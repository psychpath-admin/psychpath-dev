// Role utility functions for user type checking

export type Role = 'PROVISIONAL' | 'REGISTRAR' | 'SUPERVISOR' | 'ORG_ADMIN'

export interface UserProfile {
  id?: number
  email: string
  role: Role
  first_name: string
  middle_name?: string
  last_name: string
  ahpra_registration_number: string
  intern_start_date: string
  principal_supervisor: string
  principal_supervisor_email?: string
  secondary_supervisor?: string
  secondary_supervisor_email?: string
  supervisor_emails?: string
  signature_url?: string
  prior_hours?: {
    section_a_direct_client: number
    section_a_client_related: number
    section_b_professional_development: number
    section_c_supervision: number
  }
  // Location & Contact Information
  city?: string
  state?: string
  timezone?: string
  mobile?: string
  // Role-specific program fields
  program_type?: string
  start_date?: string
  target_weeks?: number
  weekly_commitment?: number
  aope?: string
  qualification_level?: string
  // System fields
  created_at?: string
  updated_at?: string
}

// Role check utilities
export function isSupervisor(user: UserProfile): boolean {
  return user.role === 'SUPERVISOR'
}

export function isProvisional(user: UserProfile): boolean {
  return user.role === 'PROVISIONAL'
}

export function isRegistrar(user: UserProfile): boolean {
  return user.role === 'REGISTRAR'
}

export function isOrgAdmin(user: UserProfile): boolean {
  return user.role === 'ORG_ADMIN'
}

export function isProvisional(user: UserProfile): boolean {
  return user.role === 'PROVISIONAL'
}

// Get role display name
export function getRoleDisplayName(role: Role): string {
  const roleMap: Record<Role, string> = {
    'PROVISIONAL': 'Provisional Psychologist',
    'REGISTRAR': 'Psychology Registrar',
    'SUPERVISOR': 'Board-Approved Supervisor',
    'ORG_ADMIN': 'Organisation Admin'
  }
  return roleMap[role] || role
}
