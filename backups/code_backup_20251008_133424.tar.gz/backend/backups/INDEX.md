- 20250924-2115 | tag: eod-20250924-2115 | db: Local
db-20250924-211503.sqlite3 | data isolation and protection plus login screen mods
- 20250925-2328 | tag: eod-20250925-2328 | db: Local
db-20250925-232826.sqlite3 | End of day checkpoint
- 20250926-1012 | tag: eod-20250926-1012 | db: Local
db-20250925-232826.sqlite3 | End of day checkpoint
- 20250926-2320 | tag: eod-20250926-2320 | db: Local
db-20250926-101511.sqlite3 | last thing we were working on was error message consistency with simple user messages preseted. last msg is supervision registration date ...
- 20250927-0945 | tag: eod-20250927-0945 | db: Local
db-20250926-101511.sqlite3 | Checkpoint for 27092025 at 9:43 AM - Goals for today: 1. Automatic Refresh 2. Registrar registration
- 20250927-2209 | tag: eod-20250927-2209 | db: Local
db-20250926-101511.sqlite3 | End of day checkpoint
- 20250927-2210 | tag: eod-20250927-2210 | db: Local
db-20250926-101511.sqlite3 | End of day checkpoint
- 20250927-2210 | tag: eod-20250927-2210 | db: Local
db-20250926-101511.sqlite3 | End of day checkpoint
- 20250927-2212 | tag: eod-20250927-2212 | db: Local
db-20250926-101511.sqlite3 | End of day checkpoint
- 20250927-2214 | tag: eod-20250927-2214 | db: Local
db-20250926-101511.sqlite3 | calendar issues
- 20250928-2133 | tag: eod-20250928-2133 | db: Local
db-20250928-213325.sqlite3 | worked on registration and will resume calendar integration tomorrow
- 20250930-2143 | tag: eod-20250930-2143 | db: Local
db-20250930-214303.sqlite3 | working on registrar package for entering practice hours
- 20251001-2242 | tag: eod-20251001-2242 | db: Local
db-20251001-224232.sqlite3 | Trying to get the reports running for intern4
- 20251003-0722 | tag: eod-20251003-0722 | db: Local
db-20251001-224232.sqlite3 | Improve logbook display and week grouping functionality
- 20251003-0842 | tag: eod-20251003-0842 | db: Local
db-20251001-224232.sqlite3 | just completed Section A dashboard mods and also section A on the weekly report. Then updated the Section B dashboard to be the same as Section A Dashboard
- 20251004-2133 | tag: eod-20251004-2133 | db: Local
db-20251004-213351.sqlite3 | Current Status Checkpoint - Weekly Logbook Navigation Issue RESOLVED - Backend/Frontend servers running - Makefile dev-restart target added - System operational
- 20251004-2148 | tag: eod-20251004-2148 | db: Local
db-20251004-213351.sqlite3 | Complete EOD Workflow - 2025-10-04 21:48
- 20251004-2149 | tag: eod-20251004-2149 | db: Local
db-20251004-213351.sqlite3 | Complete EOD Workflow - 2025-10-04 21:49
- 20251005-1201 | tag: eod-20251005-1201 | db: Local
db-20251005-120122.sqlite3 | End of day checkpoint
- 20251006-0017 | tag: eod-20251006-0017 | db: Local
db-20251006-001758.sqlite3 | Complete EOD Workflow - 2025-10-06 00:17
