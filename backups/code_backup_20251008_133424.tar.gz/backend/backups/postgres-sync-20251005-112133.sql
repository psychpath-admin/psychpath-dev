[
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "admin",
    "model": "logentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "auth",
    "model": "permission"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "auth",
    "model": "group"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "auth",
    "model": "user"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "contenttypes",
    "model": "contenttype"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "sessions",
    "model": "session"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "epa"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "milestone"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "reflection"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "userprofile"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "organization"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "milestoneprogress"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "emailverificationcode"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervision"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "weeklylogbook"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "logbookauditlog"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "craentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "dccentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "pdentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "supentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_a",
    "model": "sectionaentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_a",
    "model": "customsessionactivitytype"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_b",
    "model": "pdcompetency"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_b",
    "model": "professionaldevelopmententry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_b",
    "model": "pdweeklysummary"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_c",
    "model": "supervisionentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "section_c",
    "model": "supervisionweeklysummary"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "supportticket"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "supportmessage"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "supportuser"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "systemalert"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "useractivity"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "support",
    "model": "weeklystats"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "internship_validation",
    "model": "internshipprogram"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "internship_validation",
    "model": "internshipprogress"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "internship_validation",
    "model": "validationalert"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "internship_validation",
    "model": "weeklysummary"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "message"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervisorrequest"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervisorinvitation"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervisorendorsement"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervisionnotification"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "logbookmessage"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "commentthread"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "commentmessage"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "unlockrequest"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "logbook_app",
    "model": "notification"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "supervisionassignment"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "meetinginvite"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "api",
    "model": "meeting"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "competencyframework"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "registrarprogram"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "registrarsupervisionentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "supervisorprofile"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "auditlog"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "progresssnapshot"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "registrarcpdentry"
  }
},
{
  "model": "contenttypes.contenttype",
  "fields": {
    "app_label": "registrar_logbook",
    "model": "registrarpracticeentry"
  }
},
{
  "model": "sessions.session",
  "pk": "1diw2r1nakip61qw59kmz37b0k2rbte1",
  "fields": {
    "session_data": ".eJxVjDsOwjAQBe_iGlm2zPpDSc8ZrPXuBgeQI8VJFXF3iJQC2jczb1MZ16XmtcucR1YXBVadfseC9JS2E35gu0-aprbMY9G7og_a9W1ieV0P9--gYq_fOhoIYSAKlmjg4s7AzjjjLVgsJpEDF7kk7yGySDEokCyGACwhIjv1_gAHQTg5:1v4CN4:4KEwbiYfdfEpx7U88PCpt15oZ8xhlXDoTiZSaBcJW3Y",
    "expire_date": "2025-10-16T06:00:54.986Z"
  }
},
{
  "model": "sessions.session",
  "pk": "kzdv5d8pbsqbzeovir7ossxli1f74uza",
  "fields": {
    "session_data": ".eJxVjEEOwiAQRe_C2hCYKQx16d4zNFMYpGpoUtqV8e7apAvd_vfef6mBt7UMW5NlmJI6K1Cn323k-JC6g3Tnept1nOu6TKPeFX3Qpq9zkuflcP8OCrfyrUPylhHZR3LWGXAZcITQdxhiAhsJHHW2D8yJHJJIZzIiQfZkvBhQ7w-0-DaB:1v4BuC:CvN5OzgpmzhYX8pw6Mq-NGSJIJfzfy4a3pnS9ZxtFgM",
    "expire_date": "2025-10-16T05:31:04.924Z"
  }
},
{
  "model": "sessions.session",
  "pk": "mrqzih44e2l3xvyy2q397j4qjod3jchb",
  "fields": {
    "session_data": ".eJxVjDsOwjAQBe_iGlmO_6ak5wzW7nqFA8iW4qRC3B0ipYD2zcx7iQzbWvM2eMlzEWehnTj9jgj04LaTcod265J6W5cZ5a7Igw557YWfl8P9O6gw6rdmz4ZdDNEDeipMVqF2TEFhCGCYUIMHBSklnqzFohkcgZ7ImEiE4v0BMUo5Rg:1v3i7b:jTq-JDTfAkkTxB9g-Iqr3rWfwdHT45ZQuWnnUWschxE",
    "expire_date": "2025-10-14T21:42:55.373Z"
  }
},
{
  "model": "sessions.session",
  "pk": "p3v9jrqurcp86nxd3rj5am95moddmadj",
  "fields": {
    "session_data": ".eJxVjEEOwiAQRe_C2hCYKQx16d4zNFMYpGpoUtqV8e7apAvd_vfef6mBt7UMW5NlmJI6K1Cn323k-JC6g3Tnept1nOu6TKPeFX3Qpq9zkuflcP8OCrfyrUPylhHZR3LWGXAZcITQdxhiAhsJHHW2D8yJHJJIZzIiQfZkvBhQ7w-0-DaB:1v4BwA:1nyqfV8l_3qVZ88WZuP2pvfaDuClJq0UZwTkOlDfyas",
    "expire_date": "2025-10-16T05:33:06.357Z"
  }
},
{
  "model": "sessions.session",
  "pk": "xmvx0sp4c0mi4xte4kunnyc5wxl4vqst",
  "fields": {
    "session_data": ".eJxVjDsOwyAQBe9CHSHD8jEp0_sMaGEhOIlAMnYV5e6xJRdJOzPvvZnHbS1-62nxM7Erk5pdfmHA-Ez1MPTAem88trouc-BHwk_b-dQovW5n-3dQsJd9PcYYUWZhAJxyItikYADIFiUhJq2ks3LUIQ3ZGEfK7STnoFFQAIuZfb4GFjg7:1v117Y:y7D69V5O2eWZ-cNKipmC85rueu48kP-i9NDpBZ0ONkc",
    "expire_date": "2025-10-07T11:23:44.430Z"
  }
},
{
  "model": "sessions.session",
  "pk": "xsj47pcgjb8okrykzssiagkvdhnw6429",
  "fields": {
    "session_data": ".eJxVjDsOwjAQBe_iGlm2zPpDSc8ZrPXuBgeQI8VJFXF3iJQC2jczb1MZ16XmtcucR1YXBVadfseC9JS2E35gu0-aprbMY9G7og_a9W1ieV0P9--gYq_fOhoIYSAKlmjg4s7AzjjjLVgsJpEDF7kk7yGySDEokCyGACwhIjv1_gAHQTg5:1v4CLs:E47EVdBf-_WY76Oa9-zD0GLOngt7YNqFRSeJ2M8Qx_Q",
    "expire_date": "2025-10-16T05:59:40.063Z"
  }
},
{
  "model": "api.organization",
  "pk": 1,
  "fields": {
    "name": "Demo Clinic"
  }
},
{
  "model": "api.organization",
  "pk": 2,
  "fields": {
    "name": "Change Your Mind Psychology"
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 2,
  "fields": {
    "email": "test@example.com",
    "code": "331703",
    "psy_number": "",
    "registration_data": {},
    "created_at": "2025-09-20T23:25:07.418Z",
    "expires_at": "2025-09-20T23:55:07.418Z",
    "is_used": false
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 3,
  "fields": {
    "email": "supervisor@example.com",
    "code": "677977",
    "psy_number": "",
    "registration_data": {},
    "created_at": "2025-09-20T23:25:11.853Z",
    "expires_at": "2025-09-20T23:55:11.853Z",
    "is_used": false
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 4,
  "fields": {
    "email": "registrar@example.com",
    "code": "307531",
    "psy_number": "",
    "registration_data": {},
    "created_at": "2025-09-20T23:25:16.357Z",
    "expires_at": "2025-09-20T23:55:16.357Z",
    "is_used": false
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 8,
  "fields": {
    "email": "test.supervisor@example.com",
    "code": "972232",
    "psy_number": "PSY123456789",
    "registration_data": {
      "city": "Sydney",
      "email": "test.supervisor@example.com",
      "mobile": "+61412345678",
      "password": "password123",
      "last_name": "Supervisor",
      "first_name": "Test",
      "designation": "SUPERVISOR",
      "ahpra_registration_number": "PSY123456789"
    },
    "created_at": "2025-09-20T23:35:48.372Z",
    "expires_at": "2025-09-21T00:05:48.372Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 10,
  "fields": {
    "email": "test.provisional@example.com",
    "code": "418918",
    "psy_number": "PSY987654321",
    "registration_data": {
      "city": "Melbourne",
      "email": "test.provisional@example.com",
      "mobile": "+61498765432",
      "password": "password123",
      "last_name": "Provisional",
      "first_name": "Test",
      "designation": "PROVISIONAL",
      "provisional_start_date": "2022-01-01",
      "ahpra_registration_number": "PSY987654321"
    },
    "created_at": "2025-09-20T23:43:33.060Z",
    "expires_at": "2025-09-21T00:13:33.060Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 11,
  "fields": {
    "email": "new.provisional@example.com",
    "code": "467391",
    "psy_number": "PSY111222333",
    "registration_data": {
      "city": "Brisbane",
      "email": "new.provisional@example.com",
      "mobile": "+61411122233",
      "password": "password123",
      "last_name": "Provisional",
      "first_name": "New",
      "designation": "PROVISIONAL",
      "provisional_start_date": "2022-06-01",
      "ahpra_registration_number": "PSY111222333"
    },
    "created_at": "2025-09-20T23:44:29.600Z",
    "expires_at": "2025-09-21T00:14:29.600Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 12,
  "fields": {
    "email": "test.cleanup@example.com",
    "code": "469894",
    "psy_number": "PSY999888777",
    "registration_data": {
      "city": "Perth",
      "email": "test.cleanup@example.com",
      "mobile": "+61499988877",
      "password": "password123",
      "last_name": "Cleanup",
      "first_name": "Test",
      "designation": "PROVISIONAL",
      "provisional_start_date": "2022-12-01",
      "ahpra_registration_number": "PSY999888777"
    },
    "created_at": "2025-09-20T23:49:04.164Z",
    "expires_at": "2025-09-21T00:19:04.164Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 14,
  "fields": {
    "email": "test.redirect@example.com",
    "code": "293758",
    "psy_number": "PSY888777666",
    "registration_data": {
      "city": "Sydney",
      "email": "test.redirect@example.com",
      "mobile": "+61488877766",
      "password": "password123",
      "last_name": "Redirect",
      "first_name": "Test",
      "designation": "PROVISIONAL",
      "provisional_start_date": "2025-01-01",
      "ahpra_registration_number": "PSY888777666"
    },
    "created_at": "2025-09-21T00:01:49.887Z",
    "expires_at": "2025-09-21T00:31:49.887Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 21,
  "fields": {
    "email": "supervisor.demo@cymp.com.au",
    "code": "775600",
    "psy_number": "PSY0000000000",
    "registration_data": {
      "city": "Coffs Harbour",
      "email": "supervisor.demo@cymp.com.au",
      "state": "Queensland",
      "mobile": "+61373033771",
      "password": "password123",
      "timezone": "Australia/Brisbane",
      "last_name": "Mackie",
      "first_name": "Brett",
      "designation": "SUPERVISOR",
      "middle_name": "",
      "confirm_password": "password123",
      "provisional_start_date": null,
      "ahpra_registration_number": "PSY0000000000"
    },
    "created_at": "2025-09-21T01:48:52.878Z",
    "expires_at": "2025-09-21T02:18:52.877Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 35,
  "fields": {
    "email": "intern1.demo@cymp.com.au",
    "code": "087177",
    "psy_number": "PSY0000000001",
    "registration_data": {
      "city": "Ballarat",
      "email": "intern1.demo@cymp.com.au",
      "state": "Victoria",
      "mobile": "+61498868921",
      "password": "password123",
      "timezone": "Australia/Melbourne",
      "last_name": "O'Brien",
      "first_name": "Phil",
      "designation": "PROVISIONAL",
      "middle_name": "",
      "confirm_password": "password123",
      "provisional_start_date": "2025-08-31T14:00:00.000Z",
      "ahpra_registration_number": "PSY0000000001"
    },
    "created_at": "2025-09-21T21:09:47.420Z",
    "expires_at": "2025-09-21T21:39:47.420Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 36,
  "fields": {
    "email": "registrar1.demo@cymp.com.au",
    "code": "290510",
    "psy_number": "PSY0000000011",
    "registration_data": {
      "city": "Brisbane",
      "email": "registrar1.demo@cymp.com.au",
      "state": "Queensland",
      "mobile": "+61498868911",
      "password": "password123",
      "timezone": "Australia/Brisbane",
      "last_name": "One",
      "first_name": "Registrar",
      "designation": "REGISTRAR",
      "middle_name": "",
      "confirm_password": "password123",
      "provisional_start_date": "2025-08-31T14:00:00.000Z",
      "ahpra_registration_number": "PSY0000000011"
    },
    "created_at": "2025-09-21T21:47:53.792Z",
    "expires_at": "2025-09-21T22:17:53.792Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 37,
  "fields": {
    "email": "intern2.demo@cymp.com.au",
    "code": "391185",
    "psy_number": "PSY0000000002",
    "registration_data": {
      "city": "Hervey Bay",
      "email": "intern2.demo@cymp.com.au",
      "state": "Queensland",
      "mobile": "+61498868928",
      "password": "password123",
      "timezone": "Australia/Brisbane",
      "last_name": "Baboli",
      "first_name": "Maryam",
      "designation": "PROVISIONAL",
      "middle_name": "",
      "confirm_password": "password123",
      "provisional_start_date": "2025-08-31T14:00:00.000Z",
      "ahpra_registration_number": "PSY0000000002"
    },
    "created_at": "2025-09-26T03:08:44.675Z",
    "expires_at": "2025-09-26T03:38:44.674Z",
    "is_used": true
  }
},
{
  "model": "api.emailverificationcode",
  "pk": 38,
  "fields": {
    "email": "supervisor2.demo@cymp.com.au",
    "code": "862268",
    "psy_number": "PSY000000020",
    "registration_data": {
      "city": "Gold Coast",
      "email": "supervisor2.demo@cymp.com.au",
      "state": "Queensland",
      "mobile": "0498868902",
      "password": "password123",
      "timezone": "Australia/Brisbane",
      "last_name": "Demo",
      "first_name": "Supervisor2",
      "designation": "SUPERVISOR",
      "middle_name": "",
      "confirm_password": "password123",
      "provisional_start_date": null,
      "ahpra_registration_number": "PSY000000020"
    },
    "created_at": "2025-09-26T08:38:40.364Z",
    "expires_at": "2025-09-26T09:08:40.364Z",
    "is_used": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 7,
  "fields": {
    "supervision": 4,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-22T12:38:02.363Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 8,
  "fields": {
    "supervision": 4,
    "notification_type": "ACCEPTED",
    "sent_at": "2025-09-22T12:38:10.443Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 9,
  "fields": {
    "supervision": 4,
    "notification_type": "REMOVED",
    "sent_at": "2025-09-25T22:24:14.990Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 10,
  "fields": {
    "supervision": 4,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T00:16:50.460Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 11,
  "fields": {
    "supervision": 4,
    "notification_type": "ACCEPTED",
    "sent_at": "2025-09-26T00:17:08.335Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 12,
  "fields": {
    "supervision": 5,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T08:26:51.621Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 13,
  "fields": {
    "supervision": 5,
    "notification_type": "REJECTED",
    "sent_at": "2025-09-26T08:27:07.406Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 14,
  "fields": {
    "supervision": 5,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T08:32:04.225Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 15,
  "fields": {
    "supervision": 5,
    "notification_type": "REJECTED",
    "sent_at": "2025-09-26T08:32:27.909Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 16,
  "fields": {
    "supervision": 5,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T08:35:12.241Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 17,
  "fields": {
    "supervision": 5,
    "notification_type": "ACCEPTED",
    "sent_at": "2025-09-26T23:43:16.189Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 18,
  "fields": {
    "supervision": 6,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T23:55:19.802Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 19,
  "fields": {
    "supervision": 7,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-26T23:55:19.806Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 20,
  "fields": {
    "supervision": 6,
    "notification_type": "REJECTED",
    "sent_at": "2025-09-27T00:29:18.584Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 21,
  "fields": {
    "supervision": 6,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-27T00:29:26.016Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 22,
  "fields": {
    "supervision": 6,
    "notification_type": "REJECTED",
    "sent_at": "2025-09-27T00:30:41.346Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 23,
  "fields": {
    "supervision": 8,
    "notification_type": "INVITE_SENT",
    "sent_at": "2025-09-27T01:37:35.813Z",
    "email_sent": true,
    "in_app_sent": true
  }
},
{
  "model": "api.supervisionnotification",
  "pk": 24,
  "fields": {
    "supervision": 8,
    "notification_type": "ACCEPTED",
    "sent_at": "2025-09-27T01:38:27.551Z",
    "email_sent": false,
    "in_app_sent": true
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 1,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-05",
    "week_starting": "2024-09-02",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.304Z",
    "updated_at": "2025-10-04T01:40:31.178Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 2,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-13",
    "week_starting": "2024-09-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.308Z",
    "updated_at": "2025-10-04T01:40:31.178Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 3,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-21",
    "week_starting": "2024-09-16",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.309Z",
    "updated_at": "2025-10-04T01:40:31.176Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 4,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-30",
    "week_starting": "2024-09-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.310Z",
    "updated_at": "2025-10-04T01:40:31.175Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 5,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-12",
    "week_starting": "2024-10-07",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.311Z",
    "updated_at": "2025-10-04T01:40:31.173Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 6,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-16",
    "week_starting": "2024-10-14",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.313Z",
    "updated_at": "2025-10-04T01:40:31.173Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 7,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-26",
    "week_starting": "2024-10-21",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.314Z",
    "updated_at": "2025-10-04T01:40:31.171Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 8,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-30",
    "week_starting": "2024-10-28",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.316Z",
    "updated_at": "2025-10-04T01:40:31.170Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 9,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-04",
    "week_starting": "2024-11-04",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.317Z",
    "updated_at": "2025-10-04T01:40:31.168Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 10,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-11",
    "week_starting": "2024-11-11",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.318Z",
    "updated_at": "2025-10-04T01:40:31.168Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 11,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-26",
    "week_starting": "2024-11-25",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.319Z",
    "updated_at": "2025-10-04T01:40:31.166Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 12,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-10",
    "week_starting": "2024-12-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.320Z",
    "updated_at": "2025-10-04T01:40:31.164Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 13,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-16",
    "week_starting": "2024-12-16",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.322Z",
    "updated_at": "2025-10-04T01:40:31.163Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 14,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-28",
    "week_starting": "2024-12-23",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.323Z",
    "updated_at": "2025-10-04T01:40:31.162Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 15,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-31",
    "week_starting": "2024-12-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.324Z",
    "updated_at": "2025-10-04T01:40:31.161Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 16,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-09",
    "week_starting": "2025-01-06",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.326Z",
    "updated_at": "2025-10-04T01:40:31.160Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 17,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-15",
    "week_starting": "2025-01-13",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.326Z",
    "updated_at": "2025-10-04T01:40:31.159Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 18,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-19",
    "week_starting": "2025-01-13",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.327Z",
    "updated_at": "2025-10-04T01:40:31.158Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 19,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-31",
    "week_starting": "2025-01-27",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.330Z",
    "updated_at": "2025-10-04T01:40:31.156Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 20,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-07",
    "week_starting": "2025-02-03",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.334Z",
    "updated_at": "2025-10-04T01:40:31.155Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 21,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-09",
    "week_starting": "2025-02-03",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.337Z",
    "updated_at": "2025-10-04T01:40:31.154Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 22,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-21",
    "week_starting": "2025-02-17",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.342Z",
    "updated_at": "2025-10-04T01:40:31.152Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 23,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-25",
    "week_starting": "2025-02-24",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.349Z",
    "updated_at": "2025-10-04T01:40:31.152Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 24,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-02",
    "week_starting": "2025-02-24",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.350Z",
    "updated_at": "2025-10-04T01:40:31.151Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 25,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-14",
    "week_starting": "2025-03-10",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.351Z",
    "updated_at": "2025-10-04T01:40:31.149Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 26,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-22",
    "week_starting": "2025-03-17",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.353Z",
    "updated_at": "2025-10-04T01:40:31.148Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 27,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-24",
    "week_starting": "2025-03-24",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.355Z",
    "updated_at": "2025-10-04T01:40:31.148Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 28,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-04",
    "week_starting": "2025-03-31",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.356Z",
    "updated_at": "2025-10-04T01:40:31.146Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 29,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-11",
    "week_starting": "2025-04-07",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.358Z",
    "updated_at": "2025-10-04T01:40:31.144Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 30,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-16",
    "week_starting": "2025-04-14",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.360Z",
    "updated_at": "2025-10-04T01:40:31.143Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 31,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-22",
    "week_starting": "2025-04-21",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.361Z",
    "updated_at": "2025-10-04T01:40:31.143Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 32,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-28",
    "week_starting": "2025-04-28",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.363Z",
    "updated_at": "2025-10-04T01:40:31.141Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 33,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-06",
    "week_starting": "2025-05-05",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.364Z",
    "updated_at": "2025-10-04T01:40:31.140Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 34,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-21",
    "week_starting": "2025-05-19",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.366Z",
    "updated_at": "2025-10-04T01:40:31.138Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 35,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-26",
    "week_starting": "2025-05-26",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.367Z",
    "updated_at": "2025-10-04T01:40:31.137Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 36,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-01",
    "week_starting": "2025-05-26",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.368Z",
    "updated_at": "2025-10-04T01:40:31.135Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 37,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-09",
    "week_starting": "2025-06-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.370Z",
    "updated_at": "2025-10-04T01:40:31.134Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 38,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-15",
    "week_starting": "2025-06-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.371Z",
    "updated_at": "2025-10-04T01:40:31.133Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 39,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-24",
    "week_starting": "2025-06-23",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.373Z",
    "updated_at": "2025-10-04T01:40:31.132Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 40,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-07-01",
    "week_starting": "2025-06-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:27.374Z",
    "updated_at": "2025-10-04T01:40:31.129Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 41,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-02",
    "week_starting": "2024-09-02",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:36.999Z",
    "updated_at": "2025-10-04T01:40:31.179Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 42,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-14",
    "week_starting": "2024-09-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.000Z",
    "updated_at": "2025-10-04T01:40:31.177Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 43,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-17",
    "week_starting": "2024-09-16",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.001Z",
    "updated_at": "2025-10-04T01:40:31.176Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 44,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-09-25",
    "week_starting": "2024-09-23",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.002Z",
    "updated_at": "2025-10-04T01:40:31.175Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 45,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-04",
    "week_starting": "2024-09-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.004Z",
    "updated_at": "2025-10-04T01:40:31.174Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 46,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-07",
    "week_starting": "2024-10-07",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.005Z",
    "updated_at": "2025-10-04T01:40:31.174Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 47,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-23",
    "week_starting": "2024-10-21",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.006Z",
    "updated_at": "2025-10-04T01:40:31.172Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 48,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-10-28",
    "week_starting": "2024-10-28",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.007Z",
    "updated_at": "2025-10-04T01:40:31.171Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 49,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-03",
    "week_starting": "2024-10-28",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.007Z",
    "updated_at": "2025-10-04T01:40:31.169Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 50,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-15",
    "week_starting": "2024-11-11",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.008Z",
    "updated_at": "2025-10-04T01:40:31.167Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 51,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-11-30",
    "week_starting": "2024-11-25",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.009Z",
    "updated_at": "2025-10-04T01:40:31.166Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 52,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-07",
    "week_starting": "2024-12-02",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.011Z",
    "updated_at": "2025-10-04T01:40:31.165Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 53,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-13",
    "week_starting": "2024-12-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.012Z",
    "updated_at": "2025-10-04T01:40:31.164Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 54,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-15",
    "week_starting": "2024-12-09",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.013Z",
    "updated_at": "2025-10-04T01:40:31.164Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 55,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-26",
    "week_starting": "2024-12-23",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.014Z",
    "updated_at": "2025-10-04T01:40:31.163Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 56,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2024-12-30",
    "week_starting": "2024-12-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.015Z",
    "updated_at": "2025-10-04T01:40:31.162Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 57,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-06",
    "week_starting": "2025-01-06",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.016Z",
    "updated_at": "2025-10-04T01:40:31.160Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 58,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-17",
    "week_starting": "2025-01-13",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.017Z",
    "updated_at": "2025-10-04T01:40:31.159Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 59,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-19",
    "week_starting": "2025-01-13",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.018Z",
    "updated_at": "2025-10-04T01:40:31.157Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 60,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-01-30",
    "week_starting": "2025-01-27",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.019Z",
    "updated_at": "2025-10-04T01:40:31.157Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 61,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-05",
    "week_starting": "2025-02-03",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.020Z",
    "updated_at": "2025-10-04T01:40:31.156Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 62,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-12",
    "week_starting": "2025-02-10",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.021Z",
    "updated_at": "2025-10-04T01:40:31.154Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 63,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-02-17",
    "week_starting": "2025-02-17",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.022Z",
    "updated_at": "2025-10-04T01:40:31.153Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 64,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-06",
    "week_starting": "2025-03-03",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.023Z",
    "updated_at": "2025-10-04T01:40:31.150Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 65,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-13",
    "week_starting": "2025-03-10",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.024Z",
    "updated_at": "2025-10-04T01:40:31.150Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 66,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-19",
    "week_starting": "2025-03-17",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.025Z",
    "updated_at": "2025-10-04T01:40:31.149Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 67,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-28",
    "week_starting": "2025-03-24",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on individual supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.026Z",
    "updated_at": "2025-10-04T01:40:31.147Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 68,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-03-30",
    "week_starting": "2025-03-24",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.027Z",
    "updated_at": "2025-10-04T01:40:31.146Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 69,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-10",
    "week_starting": "2025-04-07",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.028Z",
    "updated_at": "2025-10-04T01:40:31.145Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 70,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-24",
    "week_starting": "2025-04-21",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.029Z",
    "updated_at": "2025-10-04T01:40:31.142Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 71,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-04-29",
    "week_starting": "2025-04-28",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.030Z",
    "updated_at": "2025-10-04T01:40:31.140Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 72,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-10",
    "week_starting": "2025-05-05",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.031Z",
    "updated_at": "2025-10-04T01:40:31.139Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 73,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-15",
    "week_starting": "2025-05-12",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.032Z",
    "updated_at": "2025-10-04T01:40:31.138Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 74,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-24",
    "week_starting": "2025-05-19",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "SECONDARY",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on peer supervision session.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.032Z",
    "updated_at": "2025-10-04T01:40:31.137Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 75,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-05-31",
    "week_starting": "2025-05-26",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.033Z",
    "updated_at": "2025-10-04T01:40:31.136Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 76,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-02",
    "week_starting": "2025-06-02",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 90,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.034Z",
    "updated_at": "2025-10-04T01:40:31.135Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 77,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-20",
    "week_starting": "2025-06-16",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "OTHER",
    "duration_minutes": 120,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on live supervision observation.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.035Z",
    "updated_at": "2025-10-04T01:40:31.133Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 78,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-06-28",
    "week_starting": "2025-06-23",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "INDIVIDUAL",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on case consultation with supervisor.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.036Z",
    "updated_at": "2025-10-04T01:40:31.131Z"
  }
},
{
  "model": "section_c.supervisionentry",
  "pk": 79,
  "fields": {
    "trainee": 50,
    "date_of_supervision": "2025-07-04",
    "week_starting": "2025-06-30",
    "supervisor_name": "Demo Supervisor",
    "supervisor_type": "PRINCIPAL",
    "supervision_type": "GROUP",
    "duration_minutes": 60,
    "summary": "Supervision session completed. Discussed case conceptualization, treatment planning, and professional development goals. Focus on group supervision meeting.",
    "locked": false,
    "supervisor_comment": "",
    "trainee_response": "",
    "created_at": "2025-10-02T10:13:37.037Z",
    "updated_at": "2025-10-04T01:40:31.125Z"
  }
},
{
  "model": "internship_validation.internshipprogram",
  "pk": 2,
  "fields": {
    "name": "5+1 Internship Program",
    "program_type": "5+1",
    "version": "1.0",
    "is_active": true,
    "total_hours_required": 1500,
    "practice_hours_required": 1360,
    "dcc_hours_minimum": 500,
    "dcc_simulated_maximum": 60,
    "supervision_hours_minimum": 80,
    "pd_hours_required": 60,
    "minimum_weeks": 44,
    "minimum_weekly_hours": 17.5,
    "supervision_ratio": 17.0,
    "created_at": "2025-09-20T06:30:26.642Z",
    "updated_at": "2025-09-20T06:30:26.642Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 1,
  "fields": {
    "user_profile": 2,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-09-20",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T06:30:26.645Z",
    "updated_at": "2025-09-20T06:30:26.645Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 2,
  "fields": {
    "user_profile": 4,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-09-20",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T06:31:05.136Z",
    "updated_at": "2025-09-20T06:31:05.136Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 3,
  "fields": {
    "user_profile": 5,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-09-20",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T06:31:05.318Z",
    "updated_at": "2025-09-20T06:31:05.318Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 4,
  "fields": {
    "user_profile": 6,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-09-20",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T06:31:05.580Z",
    "updated_at": "2025-09-20T06:31:05.580Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 5,
  "fields": {
    "user_profile": 9,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2022-01-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T23:43:43.133Z",
    "updated_at": "2025-09-20T23:43:43.133Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 6,
  "fields": {
    "user_profile": 11,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2022-06-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T23:44:32.971Z",
    "updated_at": "2025-09-20T23:44:32.971Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 7,
  "fields": {
    "user_profile": 12,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2022-12-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T23:49:08.164Z",
    "updated_at": "2025-09-20T23:49:08.164Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 9,
  "fields": {
    "user_profile": 17,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-01-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-20T23:57:09.716Z",
    "updated_at": "2025-09-20T23:57:09.716Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 10,
  "fields": {
    "user_profile": 18,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-01-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-21T00:01:53.124Z",
    "updated_at": "2025-09-21T00:01:53.124Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 25,
  "fields": {
    "user_profile": 39,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-08-31",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-21T21:09:56.783Z",
    "updated_at": "2025-09-21T21:09:56.783Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 26,
  "fields": {
    "user_profile": 42,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-09-23",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-23T12:04:26.515Z",
    "updated_at": "2025-09-23T12:04:26.515Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 27,
  "fields": {
    "user_profile": 43,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2025-08-31",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-09-26T03:08:55.887Z",
    "updated_at": "2025-09-26T03:08:55.887Z"
  }
},
{
  "model": "internship_validation.internshipprogress",
  "pk": 28,
  "fields": {
    "user_profile": 50,
    "program": 2,
    "target_completion_weeks": 52,
    "start_date": "2024-09-01",
    "expected_end_date": null,
    "actual_end_date": null,
    "current_week": 1,
    "is_completed": false,
    "weekly_validation_passed": true,
    "category_validation_passed": true,
    "created_at": "2025-10-01T10:52:39.734Z",
    "updated_at": "2025-10-01T10:52:39.734Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1,
  "fields": {
    "user_profile": 2,
    "week_number": 1,
    "week_start": "2025-09-20",
    "week_end": "2025-09-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.648Z",
    "updated_at": "2025-09-20T06:30:26.648Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 2,
  "fields": {
    "user_profile": 2,
    "week_number": 2,
    "week_start": "2025-09-27",
    "week_end": "2025-10-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.651Z",
    "updated_at": "2025-09-20T06:30:26.651Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 3,
  "fields": {
    "user_profile": 2,
    "week_number": 3,
    "week_start": "2025-10-04",
    "week_end": "2025-10-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.653Z",
    "updated_at": "2025-09-20T06:30:26.653Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 4,
  "fields": {
    "user_profile": 2,
    "week_number": 4,
    "week_start": "2025-10-11",
    "week_end": "2025-10-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.654Z",
    "updated_at": "2025-09-20T06:30:26.654Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 5,
  "fields": {
    "user_profile": 2,
    "week_number": 5,
    "week_start": "2025-10-18",
    "week_end": "2025-10-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.655Z",
    "updated_at": "2025-09-20T06:30:26.655Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 6,
  "fields": {
    "user_profile": 2,
    "week_number": 6,
    "week_start": "2025-10-25",
    "week_end": "2025-10-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.657Z",
    "updated_at": "2025-09-20T06:30:26.657Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 7,
  "fields": {
    "user_profile": 2,
    "week_number": 7,
    "week_start": "2025-11-01",
    "week_end": "2025-11-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.658Z",
    "updated_at": "2025-09-20T06:30:26.658Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 8,
  "fields": {
    "user_profile": 2,
    "week_number": 8,
    "week_start": "2025-11-08",
    "week_end": "2025-11-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.659Z",
    "updated_at": "2025-09-20T06:30:26.659Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 9,
  "fields": {
    "user_profile": 2,
    "week_number": 9,
    "week_start": "2025-11-15",
    "week_end": "2025-11-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.661Z",
    "updated_at": "2025-09-20T06:30:26.661Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 10,
  "fields": {
    "user_profile": 2,
    "week_number": 10,
    "week_start": "2025-11-22",
    "week_end": "2025-11-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.663Z",
    "updated_at": "2025-09-20T06:30:26.663Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 11,
  "fields": {
    "user_profile": 2,
    "week_number": 11,
    "week_start": "2025-11-29",
    "week_end": "2025-12-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.664Z",
    "updated_at": "2025-09-20T06:30:26.664Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 12,
  "fields": {
    "user_profile": 2,
    "week_number": 12,
    "week_start": "2025-12-06",
    "week_end": "2025-12-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.665Z",
    "updated_at": "2025-09-20T06:30:26.665Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 13,
  "fields": {
    "user_profile": 2,
    "week_number": 13,
    "week_start": "2025-12-13",
    "week_end": "2025-12-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.667Z",
    "updated_at": "2025-09-20T06:30:26.667Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 14,
  "fields": {
    "user_profile": 2,
    "week_number": 14,
    "week_start": "2025-12-20",
    "week_end": "2025-12-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.669Z",
    "updated_at": "2025-09-20T06:30:26.669Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 15,
  "fields": {
    "user_profile": 2,
    "week_number": 15,
    "week_start": "2025-12-27",
    "week_end": "2026-01-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.671Z",
    "updated_at": "2025-09-20T06:30:26.671Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 16,
  "fields": {
    "user_profile": 2,
    "week_number": 16,
    "week_start": "2026-01-03",
    "week_end": "2026-01-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.672Z",
    "updated_at": "2025-09-20T06:30:26.672Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 17,
  "fields": {
    "user_profile": 2,
    "week_number": 17,
    "week_start": "2026-01-10",
    "week_end": "2026-01-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.673Z",
    "updated_at": "2025-09-20T06:30:26.673Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 18,
  "fields": {
    "user_profile": 2,
    "week_number": 18,
    "week_start": "2026-01-17",
    "week_end": "2026-01-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.674Z",
    "updated_at": "2025-09-20T06:30:26.674Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 19,
  "fields": {
    "user_profile": 2,
    "week_number": 19,
    "week_start": "2026-01-24",
    "week_end": "2026-01-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.676Z",
    "updated_at": "2025-09-20T06:30:26.676Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 20,
  "fields": {
    "user_profile": 2,
    "week_number": 20,
    "week_start": "2026-01-31",
    "week_end": "2026-02-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.677Z",
    "updated_at": "2025-09-20T06:30:26.677Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 21,
  "fields": {
    "user_profile": 2,
    "week_number": 21,
    "week_start": "2026-02-07",
    "week_end": "2026-02-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.679Z",
    "updated_at": "2025-09-20T06:30:26.679Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 22,
  "fields": {
    "user_profile": 2,
    "week_number": 22,
    "week_start": "2026-02-14",
    "week_end": "2026-02-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.680Z",
    "updated_at": "2025-09-20T06:30:26.680Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 23,
  "fields": {
    "user_profile": 2,
    "week_number": 23,
    "week_start": "2026-02-21",
    "week_end": "2026-02-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.681Z",
    "updated_at": "2025-09-20T06:30:26.681Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 24,
  "fields": {
    "user_profile": 2,
    "week_number": 24,
    "week_start": "2026-02-28",
    "week_end": "2026-03-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.682Z",
    "updated_at": "2025-09-20T06:30:26.682Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 25,
  "fields": {
    "user_profile": 2,
    "week_number": 25,
    "week_start": "2026-03-07",
    "week_end": "2026-03-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.683Z",
    "updated_at": "2025-09-20T06:30:26.683Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 26,
  "fields": {
    "user_profile": 2,
    "week_number": 26,
    "week_start": "2026-03-14",
    "week_end": "2026-03-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.685Z",
    "updated_at": "2025-09-20T06:30:26.685Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 27,
  "fields": {
    "user_profile": 2,
    "week_number": 27,
    "week_start": "2026-03-21",
    "week_end": "2026-03-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.686Z",
    "updated_at": "2025-09-20T06:30:26.686Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 28,
  "fields": {
    "user_profile": 2,
    "week_number": 28,
    "week_start": "2026-03-28",
    "week_end": "2026-04-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.687Z",
    "updated_at": "2025-09-20T06:30:26.687Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 29,
  "fields": {
    "user_profile": 2,
    "week_number": 29,
    "week_start": "2026-04-04",
    "week_end": "2026-04-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.688Z",
    "updated_at": "2025-09-20T06:30:26.688Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 30,
  "fields": {
    "user_profile": 2,
    "week_number": 30,
    "week_start": "2026-04-11",
    "week_end": "2026-04-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.689Z",
    "updated_at": "2025-09-20T06:30:26.689Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 31,
  "fields": {
    "user_profile": 2,
    "week_number": 31,
    "week_start": "2026-04-18",
    "week_end": "2026-04-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.690Z",
    "updated_at": "2025-09-20T06:30:26.690Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 32,
  "fields": {
    "user_profile": 2,
    "week_number": 32,
    "week_start": "2026-04-25",
    "week_end": "2026-05-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.691Z",
    "updated_at": "2025-09-20T06:30:26.691Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 33,
  "fields": {
    "user_profile": 2,
    "week_number": 33,
    "week_start": "2026-05-02",
    "week_end": "2026-05-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.693Z",
    "updated_at": "2025-09-20T06:30:26.693Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 34,
  "fields": {
    "user_profile": 2,
    "week_number": 34,
    "week_start": "2026-05-09",
    "week_end": "2026-05-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.694Z",
    "updated_at": "2025-09-20T06:30:26.694Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 35,
  "fields": {
    "user_profile": 2,
    "week_number": 35,
    "week_start": "2026-05-16",
    "week_end": "2026-05-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.695Z",
    "updated_at": "2025-09-20T06:30:26.695Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 36,
  "fields": {
    "user_profile": 2,
    "week_number": 36,
    "week_start": "2026-05-23",
    "week_end": "2026-05-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.696Z",
    "updated_at": "2025-09-20T06:30:26.696Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 37,
  "fields": {
    "user_profile": 2,
    "week_number": 37,
    "week_start": "2026-05-30",
    "week_end": "2026-06-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.698Z",
    "updated_at": "2025-09-20T06:30:26.698Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 38,
  "fields": {
    "user_profile": 2,
    "week_number": 38,
    "week_start": "2026-06-06",
    "week_end": "2026-06-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.699Z",
    "updated_at": "2025-09-20T06:30:26.699Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 39,
  "fields": {
    "user_profile": 2,
    "week_number": 39,
    "week_start": "2026-06-13",
    "week_end": "2026-06-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.700Z",
    "updated_at": "2025-09-20T06:30:26.700Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 40,
  "fields": {
    "user_profile": 2,
    "week_number": 40,
    "week_start": "2026-06-20",
    "week_end": "2026-06-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.701Z",
    "updated_at": "2025-09-20T06:30:26.701Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 41,
  "fields": {
    "user_profile": 2,
    "week_number": 41,
    "week_start": "2026-06-27",
    "week_end": "2026-07-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.702Z",
    "updated_at": "2025-09-20T06:30:26.702Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 42,
  "fields": {
    "user_profile": 2,
    "week_number": 42,
    "week_start": "2026-07-04",
    "week_end": "2026-07-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.704Z",
    "updated_at": "2025-09-20T06:30:26.704Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 43,
  "fields": {
    "user_profile": 2,
    "week_number": 43,
    "week_start": "2026-07-11",
    "week_end": "2026-07-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.705Z",
    "updated_at": "2025-09-20T06:30:26.705Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 44,
  "fields": {
    "user_profile": 2,
    "week_number": 44,
    "week_start": "2026-07-18",
    "week_end": "2026-07-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.706Z",
    "updated_at": "2025-09-20T06:30:26.706Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 45,
  "fields": {
    "user_profile": 2,
    "week_number": 45,
    "week_start": "2026-07-25",
    "week_end": "2026-07-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.708Z",
    "updated_at": "2025-09-20T06:30:26.708Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 46,
  "fields": {
    "user_profile": 2,
    "week_number": 46,
    "week_start": "2026-08-01",
    "week_end": "2026-08-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.710Z",
    "updated_at": "2025-09-20T06:30:26.710Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 47,
  "fields": {
    "user_profile": 2,
    "week_number": 47,
    "week_start": "2026-08-08",
    "week_end": "2026-08-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.711Z",
    "updated_at": "2025-09-20T06:30:26.711Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 48,
  "fields": {
    "user_profile": 2,
    "week_number": 48,
    "week_start": "2026-08-15",
    "week_end": "2026-08-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.712Z",
    "updated_at": "2025-09-20T06:30:26.712Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 49,
  "fields": {
    "user_profile": 2,
    "week_number": 49,
    "week_start": "2026-08-22",
    "week_end": "2026-08-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.713Z",
    "updated_at": "2025-09-20T06:30:26.713Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 50,
  "fields": {
    "user_profile": 2,
    "week_number": 50,
    "week_start": "2026-08-29",
    "week_end": "2026-09-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.715Z",
    "updated_at": "2025-09-20T06:30:26.715Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 51,
  "fields": {
    "user_profile": 2,
    "week_number": 51,
    "week_start": "2026-09-05",
    "week_end": "2026-09-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.716Z",
    "updated_at": "2025-09-20T06:30:26.716Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 52,
  "fields": {
    "user_profile": 2,
    "week_number": 52,
    "week_start": "2026-09-12",
    "week_end": "2026-09-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:30:26.717Z",
    "updated_at": "2025-09-20T06:30:26.717Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 53,
  "fields": {
    "user_profile": 4,
    "week_number": 1,
    "week_start": "2025-09-20",
    "week_end": "2025-09-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.139Z",
    "updated_at": "2025-09-20T06:31:05.139Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 54,
  "fields": {
    "user_profile": 4,
    "week_number": 2,
    "week_start": "2025-09-27",
    "week_end": "2025-10-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.141Z",
    "updated_at": "2025-09-20T06:31:05.141Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 55,
  "fields": {
    "user_profile": 4,
    "week_number": 3,
    "week_start": "2025-10-04",
    "week_end": "2025-10-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.143Z",
    "updated_at": "2025-09-20T06:31:05.143Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 56,
  "fields": {
    "user_profile": 4,
    "week_number": 4,
    "week_start": "2025-10-11",
    "week_end": "2025-10-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.144Z",
    "updated_at": "2025-09-20T06:31:05.144Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 57,
  "fields": {
    "user_profile": 4,
    "week_number": 5,
    "week_start": "2025-10-18",
    "week_end": "2025-10-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.146Z",
    "updated_at": "2025-09-20T06:31:05.146Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 58,
  "fields": {
    "user_profile": 4,
    "week_number": 6,
    "week_start": "2025-10-25",
    "week_end": "2025-10-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.147Z",
    "updated_at": "2025-09-20T06:31:05.147Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 59,
  "fields": {
    "user_profile": 4,
    "week_number": 7,
    "week_start": "2025-11-01",
    "week_end": "2025-11-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.149Z",
    "updated_at": "2025-09-20T06:31:05.149Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 60,
  "fields": {
    "user_profile": 4,
    "week_number": 8,
    "week_start": "2025-11-08",
    "week_end": "2025-11-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.151Z",
    "updated_at": "2025-09-20T06:31:05.151Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 61,
  "fields": {
    "user_profile": 4,
    "week_number": 9,
    "week_start": "2025-11-15",
    "week_end": "2025-11-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.152Z",
    "updated_at": "2025-09-20T06:31:05.152Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 62,
  "fields": {
    "user_profile": 4,
    "week_number": 10,
    "week_start": "2025-11-22",
    "week_end": "2025-11-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.154Z",
    "updated_at": "2025-09-20T06:31:05.154Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 63,
  "fields": {
    "user_profile": 4,
    "week_number": 11,
    "week_start": "2025-11-29",
    "week_end": "2025-12-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.155Z",
    "updated_at": "2025-09-20T06:31:05.155Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 64,
  "fields": {
    "user_profile": 4,
    "week_number": 12,
    "week_start": "2025-12-06",
    "week_end": "2025-12-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.157Z",
    "updated_at": "2025-09-20T06:31:05.157Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 65,
  "fields": {
    "user_profile": 4,
    "week_number": 13,
    "week_start": "2025-12-13",
    "week_end": "2025-12-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.158Z",
    "updated_at": "2025-09-20T06:31:05.158Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 66,
  "fields": {
    "user_profile": 4,
    "week_number": 14,
    "week_start": "2025-12-20",
    "week_end": "2025-12-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.160Z",
    "updated_at": "2025-09-20T06:31:05.160Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 67,
  "fields": {
    "user_profile": 4,
    "week_number": 15,
    "week_start": "2025-12-27",
    "week_end": "2026-01-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.162Z",
    "updated_at": "2025-09-20T06:31:05.162Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 68,
  "fields": {
    "user_profile": 4,
    "week_number": 16,
    "week_start": "2026-01-03",
    "week_end": "2026-01-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.163Z",
    "updated_at": "2025-09-20T06:31:05.163Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 69,
  "fields": {
    "user_profile": 4,
    "week_number": 17,
    "week_start": "2026-01-10",
    "week_end": "2026-01-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.164Z",
    "updated_at": "2025-09-20T06:31:05.164Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 70,
  "fields": {
    "user_profile": 4,
    "week_number": 18,
    "week_start": "2026-01-17",
    "week_end": "2026-01-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.165Z",
    "updated_at": "2025-09-20T06:31:05.165Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 71,
  "fields": {
    "user_profile": 4,
    "week_number": 19,
    "week_start": "2026-01-24",
    "week_end": "2026-01-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.167Z",
    "updated_at": "2025-09-20T06:31:05.167Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 72,
  "fields": {
    "user_profile": 4,
    "week_number": 20,
    "week_start": "2026-01-31",
    "week_end": "2026-02-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.168Z",
    "updated_at": "2025-09-20T06:31:05.168Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 73,
  "fields": {
    "user_profile": 4,
    "week_number": 21,
    "week_start": "2026-02-07",
    "week_end": "2026-02-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.169Z",
    "updated_at": "2025-09-20T06:31:05.169Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 74,
  "fields": {
    "user_profile": 4,
    "week_number": 22,
    "week_start": "2026-02-14",
    "week_end": "2026-02-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.171Z",
    "updated_at": "2025-09-20T06:31:05.171Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 75,
  "fields": {
    "user_profile": 4,
    "week_number": 23,
    "week_start": "2026-02-21",
    "week_end": "2026-02-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.172Z",
    "updated_at": "2025-09-20T06:31:05.172Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 76,
  "fields": {
    "user_profile": 4,
    "week_number": 24,
    "week_start": "2026-02-28",
    "week_end": "2026-03-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.173Z",
    "updated_at": "2025-09-20T06:31:05.173Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 77,
  "fields": {
    "user_profile": 4,
    "week_number": 25,
    "week_start": "2026-03-07",
    "week_end": "2026-03-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.175Z",
    "updated_at": "2025-09-20T06:31:05.175Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 78,
  "fields": {
    "user_profile": 4,
    "week_number": 26,
    "week_start": "2026-03-14",
    "week_end": "2026-03-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.176Z",
    "updated_at": "2025-09-20T06:31:05.176Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 79,
  "fields": {
    "user_profile": 4,
    "week_number": 27,
    "week_start": "2026-03-21",
    "week_end": "2026-03-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.177Z",
    "updated_at": "2025-09-20T06:31:05.177Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 80,
  "fields": {
    "user_profile": 4,
    "week_number": 28,
    "week_start": "2026-03-28",
    "week_end": "2026-04-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.178Z",
    "updated_at": "2025-09-20T06:31:05.178Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 81,
  "fields": {
    "user_profile": 4,
    "week_number": 29,
    "week_start": "2026-04-04",
    "week_end": "2026-04-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.180Z",
    "updated_at": "2025-09-20T06:31:05.180Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 82,
  "fields": {
    "user_profile": 4,
    "week_number": 30,
    "week_start": "2026-04-11",
    "week_end": "2026-04-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.181Z",
    "updated_at": "2025-09-20T06:31:05.181Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 83,
  "fields": {
    "user_profile": 4,
    "week_number": 31,
    "week_start": "2026-04-18",
    "week_end": "2026-04-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.182Z",
    "updated_at": "2025-09-20T06:31:05.182Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 84,
  "fields": {
    "user_profile": 4,
    "week_number": 32,
    "week_start": "2026-04-25",
    "week_end": "2026-05-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.183Z",
    "updated_at": "2025-09-20T06:31:05.183Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 85,
  "fields": {
    "user_profile": 4,
    "week_number": 33,
    "week_start": "2026-05-02",
    "week_end": "2026-05-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.185Z",
    "updated_at": "2025-09-20T06:31:05.185Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 86,
  "fields": {
    "user_profile": 4,
    "week_number": 34,
    "week_start": "2026-05-09",
    "week_end": "2026-05-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.186Z",
    "updated_at": "2025-09-20T06:31:05.186Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 87,
  "fields": {
    "user_profile": 4,
    "week_number": 35,
    "week_start": "2026-05-16",
    "week_end": "2026-05-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.187Z",
    "updated_at": "2025-09-20T06:31:05.187Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 88,
  "fields": {
    "user_profile": 4,
    "week_number": 36,
    "week_start": "2026-05-23",
    "week_end": "2026-05-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.188Z",
    "updated_at": "2025-09-20T06:31:05.188Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 89,
  "fields": {
    "user_profile": 4,
    "week_number": 37,
    "week_start": "2026-05-30",
    "week_end": "2026-06-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.190Z",
    "updated_at": "2025-09-20T06:31:05.190Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 90,
  "fields": {
    "user_profile": 4,
    "week_number": 38,
    "week_start": "2026-06-06",
    "week_end": "2026-06-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.191Z",
    "updated_at": "2025-09-20T06:31:05.191Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 91,
  "fields": {
    "user_profile": 4,
    "week_number": 39,
    "week_start": "2026-06-13",
    "week_end": "2026-06-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.193Z",
    "updated_at": "2025-09-20T06:31:05.193Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 92,
  "fields": {
    "user_profile": 4,
    "week_number": 40,
    "week_start": "2026-06-20",
    "week_end": "2026-06-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.194Z",
    "updated_at": "2025-09-20T06:31:05.194Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 93,
  "fields": {
    "user_profile": 4,
    "week_number": 41,
    "week_start": "2026-06-27",
    "week_end": "2026-07-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.195Z",
    "updated_at": "2025-09-20T06:31:05.195Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 94,
  "fields": {
    "user_profile": 4,
    "week_number": 42,
    "week_start": "2026-07-04",
    "week_end": "2026-07-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.197Z",
    "updated_at": "2025-09-20T06:31:05.197Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 95,
  "fields": {
    "user_profile": 4,
    "week_number": 43,
    "week_start": "2026-07-11",
    "week_end": "2026-07-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.198Z",
    "updated_at": "2025-09-20T06:31:05.198Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 96,
  "fields": {
    "user_profile": 4,
    "week_number": 44,
    "week_start": "2026-07-18",
    "week_end": "2026-07-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.199Z",
    "updated_at": "2025-09-20T06:31:05.199Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 97,
  "fields": {
    "user_profile": 4,
    "week_number": 45,
    "week_start": "2026-07-25",
    "week_end": "2026-07-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.201Z",
    "updated_at": "2025-09-20T06:31:05.201Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 98,
  "fields": {
    "user_profile": 4,
    "week_number": 46,
    "week_start": "2026-08-01",
    "week_end": "2026-08-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.202Z",
    "updated_at": "2025-09-20T06:31:05.202Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 99,
  "fields": {
    "user_profile": 4,
    "week_number": 47,
    "week_start": "2026-08-08",
    "week_end": "2026-08-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.203Z",
    "updated_at": "2025-09-20T06:31:05.203Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 100,
  "fields": {
    "user_profile": 4,
    "week_number": 48,
    "week_start": "2026-08-15",
    "week_end": "2026-08-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.204Z",
    "updated_at": "2025-09-20T06:31:05.204Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 101,
  "fields": {
    "user_profile": 4,
    "week_number": 49,
    "week_start": "2026-08-22",
    "week_end": "2026-08-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.206Z",
    "updated_at": "2025-09-20T06:31:05.206Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 102,
  "fields": {
    "user_profile": 4,
    "week_number": 50,
    "week_start": "2026-08-29",
    "week_end": "2026-09-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.207Z",
    "updated_at": "2025-09-20T06:31:05.207Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 103,
  "fields": {
    "user_profile": 4,
    "week_number": 51,
    "week_start": "2026-09-05",
    "week_end": "2026-09-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.208Z",
    "updated_at": "2025-09-20T06:31:05.208Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 104,
  "fields": {
    "user_profile": 4,
    "week_number": 52,
    "week_start": "2026-09-12",
    "week_end": "2026-09-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.209Z",
    "updated_at": "2025-09-20T06:31:05.209Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 105,
  "fields": {
    "user_profile": 5,
    "week_number": 1,
    "week_start": "2025-09-20",
    "week_end": "2025-09-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.320Z",
    "updated_at": "2025-09-20T06:31:05.320Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 106,
  "fields": {
    "user_profile": 5,
    "week_number": 2,
    "week_start": "2025-09-27",
    "week_end": "2025-10-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.322Z",
    "updated_at": "2025-09-20T06:31:05.322Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 107,
  "fields": {
    "user_profile": 5,
    "week_number": 3,
    "week_start": "2025-10-04",
    "week_end": "2025-10-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.324Z",
    "updated_at": "2025-09-20T06:31:05.324Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 108,
  "fields": {
    "user_profile": 5,
    "week_number": 4,
    "week_start": "2025-10-11",
    "week_end": "2025-10-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.326Z",
    "updated_at": "2025-09-20T06:31:05.326Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 109,
  "fields": {
    "user_profile": 5,
    "week_number": 5,
    "week_start": "2025-10-18",
    "week_end": "2025-10-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.328Z",
    "updated_at": "2025-09-20T06:31:05.328Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 110,
  "fields": {
    "user_profile": 5,
    "week_number": 6,
    "week_start": "2025-10-25",
    "week_end": "2025-10-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.330Z",
    "updated_at": "2025-09-20T06:31:05.330Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 111,
  "fields": {
    "user_profile": 5,
    "week_number": 7,
    "week_start": "2025-11-01",
    "week_end": "2025-11-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.331Z",
    "updated_at": "2025-09-20T06:31:05.331Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 112,
  "fields": {
    "user_profile": 5,
    "week_number": 8,
    "week_start": "2025-11-08",
    "week_end": "2025-11-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.333Z",
    "updated_at": "2025-09-20T06:31:05.333Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 113,
  "fields": {
    "user_profile": 5,
    "week_number": 9,
    "week_start": "2025-11-15",
    "week_end": "2025-11-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.334Z",
    "updated_at": "2025-09-20T06:31:05.334Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 114,
  "fields": {
    "user_profile": 5,
    "week_number": 10,
    "week_start": "2025-11-22",
    "week_end": "2025-11-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.336Z",
    "updated_at": "2025-09-20T06:31:05.336Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 115,
  "fields": {
    "user_profile": 5,
    "week_number": 11,
    "week_start": "2025-11-29",
    "week_end": "2025-12-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.337Z",
    "updated_at": "2025-09-20T06:31:05.337Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 116,
  "fields": {
    "user_profile": 5,
    "week_number": 12,
    "week_start": "2025-12-06",
    "week_end": "2025-12-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.340Z",
    "updated_at": "2025-09-20T06:31:05.340Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 117,
  "fields": {
    "user_profile": 5,
    "week_number": 13,
    "week_start": "2025-12-13",
    "week_end": "2025-12-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.342Z",
    "updated_at": "2025-09-20T06:31:05.342Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 118,
  "fields": {
    "user_profile": 5,
    "week_number": 14,
    "week_start": "2025-12-20",
    "week_end": "2025-12-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.344Z",
    "updated_at": "2025-09-20T06:31:05.344Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 119,
  "fields": {
    "user_profile": 5,
    "week_number": 15,
    "week_start": "2025-12-27",
    "week_end": "2026-01-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.345Z",
    "updated_at": "2025-09-20T06:31:05.345Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 120,
  "fields": {
    "user_profile": 5,
    "week_number": 16,
    "week_start": "2026-01-03",
    "week_end": "2026-01-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.347Z",
    "updated_at": "2025-09-20T06:31:05.347Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 121,
  "fields": {
    "user_profile": 5,
    "week_number": 17,
    "week_start": "2026-01-10",
    "week_end": "2026-01-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.349Z",
    "updated_at": "2025-09-20T06:31:05.349Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 122,
  "fields": {
    "user_profile": 5,
    "week_number": 18,
    "week_start": "2026-01-17",
    "week_end": "2026-01-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.351Z",
    "updated_at": "2025-09-20T06:31:05.351Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 123,
  "fields": {
    "user_profile": 5,
    "week_number": 19,
    "week_start": "2026-01-24",
    "week_end": "2026-01-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.353Z",
    "updated_at": "2025-09-20T06:31:05.353Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 124,
  "fields": {
    "user_profile": 5,
    "week_number": 20,
    "week_start": "2026-01-31",
    "week_end": "2026-02-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.355Z",
    "updated_at": "2025-09-20T06:31:05.355Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 125,
  "fields": {
    "user_profile": 5,
    "week_number": 21,
    "week_start": "2026-02-07",
    "week_end": "2026-02-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.356Z",
    "updated_at": "2025-09-20T06:31:05.356Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 126,
  "fields": {
    "user_profile": 5,
    "week_number": 22,
    "week_start": "2026-02-14",
    "week_end": "2026-02-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.358Z",
    "updated_at": "2025-09-20T06:31:05.358Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 127,
  "fields": {
    "user_profile": 5,
    "week_number": 23,
    "week_start": "2026-02-21",
    "week_end": "2026-02-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.361Z",
    "updated_at": "2025-09-20T06:31:05.361Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 128,
  "fields": {
    "user_profile": 5,
    "week_number": 24,
    "week_start": "2026-02-28",
    "week_end": "2026-03-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.362Z",
    "updated_at": "2025-09-20T06:31:05.362Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 129,
  "fields": {
    "user_profile": 5,
    "week_number": 25,
    "week_start": "2026-03-07",
    "week_end": "2026-03-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.364Z",
    "updated_at": "2025-09-20T06:31:05.364Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 130,
  "fields": {
    "user_profile": 5,
    "week_number": 26,
    "week_start": "2026-03-14",
    "week_end": "2026-03-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.366Z",
    "updated_at": "2025-09-20T06:31:05.366Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 131,
  "fields": {
    "user_profile": 5,
    "week_number": 27,
    "week_start": "2026-03-21",
    "week_end": "2026-03-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.368Z",
    "updated_at": "2025-09-20T06:31:05.368Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 132,
  "fields": {
    "user_profile": 5,
    "week_number": 28,
    "week_start": "2026-03-28",
    "week_end": "2026-04-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.370Z",
    "updated_at": "2025-09-20T06:31:05.370Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 133,
  "fields": {
    "user_profile": 5,
    "week_number": 29,
    "week_start": "2026-04-04",
    "week_end": "2026-04-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.372Z",
    "updated_at": "2025-09-20T06:31:05.372Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 134,
  "fields": {
    "user_profile": 5,
    "week_number": 30,
    "week_start": "2026-04-11",
    "week_end": "2026-04-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.374Z",
    "updated_at": "2025-09-20T06:31:05.374Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 135,
  "fields": {
    "user_profile": 5,
    "week_number": 31,
    "week_start": "2026-04-18",
    "week_end": "2026-04-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.376Z",
    "updated_at": "2025-09-20T06:31:05.376Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 136,
  "fields": {
    "user_profile": 5,
    "week_number": 32,
    "week_start": "2026-04-25",
    "week_end": "2026-05-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.378Z",
    "updated_at": "2025-09-20T06:31:05.378Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 137,
  "fields": {
    "user_profile": 5,
    "week_number": 33,
    "week_start": "2026-05-02",
    "week_end": "2026-05-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.381Z",
    "updated_at": "2025-09-20T06:31:05.381Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 138,
  "fields": {
    "user_profile": 5,
    "week_number": 34,
    "week_start": "2026-05-09",
    "week_end": "2026-05-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.383Z",
    "updated_at": "2025-09-20T06:31:05.383Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 139,
  "fields": {
    "user_profile": 5,
    "week_number": 35,
    "week_start": "2026-05-16",
    "week_end": "2026-05-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.385Z",
    "updated_at": "2025-09-20T06:31:05.385Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 140,
  "fields": {
    "user_profile": 5,
    "week_number": 36,
    "week_start": "2026-05-23",
    "week_end": "2026-05-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.387Z",
    "updated_at": "2025-09-20T06:31:05.387Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 141,
  "fields": {
    "user_profile": 5,
    "week_number": 37,
    "week_start": "2026-05-30",
    "week_end": "2026-06-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.389Z",
    "updated_at": "2025-09-20T06:31:05.389Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 142,
  "fields": {
    "user_profile": 5,
    "week_number": 38,
    "week_start": "2026-06-06",
    "week_end": "2026-06-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.391Z",
    "updated_at": "2025-09-20T06:31:05.391Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 143,
  "fields": {
    "user_profile": 5,
    "week_number": 39,
    "week_start": "2026-06-13",
    "week_end": "2026-06-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.393Z",
    "updated_at": "2025-09-20T06:31:05.393Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 144,
  "fields": {
    "user_profile": 5,
    "week_number": 40,
    "week_start": "2026-06-20",
    "week_end": "2026-06-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.396Z",
    "updated_at": "2025-09-20T06:31:05.396Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 145,
  "fields": {
    "user_profile": 5,
    "week_number": 41,
    "week_start": "2026-06-27",
    "week_end": "2026-07-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.398Z",
    "updated_at": "2025-09-20T06:31:05.398Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 146,
  "fields": {
    "user_profile": 5,
    "week_number": 42,
    "week_start": "2026-07-04",
    "week_end": "2026-07-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.400Z",
    "updated_at": "2025-09-20T06:31:05.400Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 147,
  "fields": {
    "user_profile": 5,
    "week_number": 43,
    "week_start": "2026-07-11",
    "week_end": "2026-07-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.403Z",
    "updated_at": "2025-09-20T06:31:05.403Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 148,
  "fields": {
    "user_profile": 5,
    "week_number": 44,
    "week_start": "2026-07-18",
    "week_end": "2026-07-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.405Z",
    "updated_at": "2025-09-20T06:31:05.405Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 149,
  "fields": {
    "user_profile": 5,
    "week_number": 45,
    "week_start": "2026-07-25",
    "week_end": "2026-07-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.407Z",
    "updated_at": "2025-09-20T06:31:05.407Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 150,
  "fields": {
    "user_profile": 5,
    "week_number": 46,
    "week_start": "2026-08-01",
    "week_end": "2026-08-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.409Z",
    "updated_at": "2025-09-20T06:31:05.409Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 151,
  "fields": {
    "user_profile": 5,
    "week_number": 47,
    "week_start": "2026-08-08",
    "week_end": "2026-08-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.412Z",
    "updated_at": "2025-09-20T06:31:05.412Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 152,
  "fields": {
    "user_profile": 5,
    "week_number": 48,
    "week_start": "2026-08-15",
    "week_end": "2026-08-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.414Z",
    "updated_at": "2025-09-20T06:31:05.414Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 153,
  "fields": {
    "user_profile": 5,
    "week_number": 49,
    "week_start": "2026-08-22",
    "week_end": "2026-08-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.416Z",
    "updated_at": "2025-09-20T06:31:05.416Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 154,
  "fields": {
    "user_profile": 5,
    "week_number": 50,
    "week_start": "2026-08-29",
    "week_end": "2026-09-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.418Z",
    "updated_at": "2025-09-20T06:31:05.418Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 155,
  "fields": {
    "user_profile": 5,
    "week_number": 51,
    "week_start": "2026-09-05",
    "week_end": "2026-09-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.420Z",
    "updated_at": "2025-09-20T06:31:05.420Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 156,
  "fields": {
    "user_profile": 5,
    "week_number": 52,
    "week_start": "2026-09-12",
    "week_end": "2026-09-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.423Z",
    "updated_at": "2025-09-20T06:31:05.423Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 157,
  "fields": {
    "user_profile": 6,
    "week_number": 1,
    "week_start": "2025-09-20",
    "week_end": "2025-09-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.583Z",
    "updated_at": "2025-09-20T06:31:05.583Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 158,
  "fields": {
    "user_profile": 6,
    "week_number": 2,
    "week_start": "2025-09-27",
    "week_end": "2025-10-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.585Z",
    "updated_at": "2025-09-20T06:31:05.585Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 159,
  "fields": {
    "user_profile": 6,
    "week_number": 3,
    "week_start": "2025-10-04",
    "week_end": "2025-10-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.588Z",
    "updated_at": "2025-09-20T06:31:05.588Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 160,
  "fields": {
    "user_profile": 6,
    "week_number": 4,
    "week_start": "2025-10-11",
    "week_end": "2025-10-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.590Z",
    "updated_at": "2025-09-20T06:31:05.590Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 161,
  "fields": {
    "user_profile": 6,
    "week_number": 5,
    "week_start": "2025-10-18",
    "week_end": "2025-10-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.595Z",
    "updated_at": "2025-09-20T06:31:05.595Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 162,
  "fields": {
    "user_profile": 6,
    "week_number": 6,
    "week_start": "2025-10-25",
    "week_end": "2025-10-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.597Z",
    "updated_at": "2025-09-20T06:31:05.597Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 163,
  "fields": {
    "user_profile": 6,
    "week_number": 7,
    "week_start": "2025-11-01",
    "week_end": "2025-11-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.599Z",
    "updated_at": "2025-09-20T06:31:05.599Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 164,
  "fields": {
    "user_profile": 6,
    "week_number": 8,
    "week_start": "2025-11-08",
    "week_end": "2025-11-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.601Z",
    "updated_at": "2025-09-20T06:31:05.601Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 165,
  "fields": {
    "user_profile": 6,
    "week_number": 9,
    "week_start": "2025-11-15",
    "week_end": "2025-11-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.603Z",
    "updated_at": "2025-09-20T06:31:05.603Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 166,
  "fields": {
    "user_profile": 6,
    "week_number": 10,
    "week_start": "2025-11-22",
    "week_end": "2025-11-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.606Z",
    "updated_at": "2025-09-20T06:31:05.606Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 167,
  "fields": {
    "user_profile": 6,
    "week_number": 11,
    "week_start": "2025-11-29",
    "week_end": "2025-12-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.609Z",
    "updated_at": "2025-09-20T06:31:05.609Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 168,
  "fields": {
    "user_profile": 6,
    "week_number": 12,
    "week_start": "2025-12-06",
    "week_end": "2025-12-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.612Z",
    "updated_at": "2025-09-20T06:31:05.612Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 169,
  "fields": {
    "user_profile": 6,
    "week_number": 13,
    "week_start": "2025-12-13",
    "week_end": "2025-12-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.614Z",
    "updated_at": "2025-09-20T06:31:05.614Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 170,
  "fields": {
    "user_profile": 6,
    "week_number": 14,
    "week_start": "2025-12-20",
    "week_end": "2025-12-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.616Z",
    "updated_at": "2025-09-20T06:31:05.616Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 171,
  "fields": {
    "user_profile": 6,
    "week_number": 15,
    "week_start": "2025-12-27",
    "week_end": "2026-01-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.618Z",
    "updated_at": "2025-09-20T06:31:05.618Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 172,
  "fields": {
    "user_profile": 6,
    "week_number": 16,
    "week_start": "2026-01-03",
    "week_end": "2026-01-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.620Z",
    "updated_at": "2025-09-20T06:31:05.620Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 173,
  "fields": {
    "user_profile": 6,
    "week_number": 17,
    "week_start": "2026-01-10",
    "week_end": "2026-01-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.623Z",
    "updated_at": "2025-09-20T06:31:05.623Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 174,
  "fields": {
    "user_profile": 6,
    "week_number": 18,
    "week_start": "2026-01-17",
    "week_end": "2026-01-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.627Z",
    "updated_at": "2025-09-20T06:31:05.627Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 175,
  "fields": {
    "user_profile": 6,
    "week_number": 19,
    "week_start": "2026-01-24",
    "week_end": "2026-01-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.629Z",
    "updated_at": "2025-09-20T06:31:05.629Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 176,
  "fields": {
    "user_profile": 6,
    "week_number": 20,
    "week_start": "2026-01-31",
    "week_end": "2026-02-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.631Z",
    "updated_at": "2025-09-20T06:31:05.631Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 177,
  "fields": {
    "user_profile": 6,
    "week_number": 21,
    "week_start": "2026-02-07",
    "week_end": "2026-02-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.633Z",
    "updated_at": "2025-09-20T06:31:05.633Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 178,
  "fields": {
    "user_profile": 6,
    "week_number": 22,
    "week_start": "2026-02-14",
    "week_end": "2026-02-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.634Z",
    "updated_at": "2025-09-20T06:31:05.634Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 179,
  "fields": {
    "user_profile": 6,
    "week_number": 23,
    "week_start": "2026-02-21",
    "week_end": "2026-02-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.637Z",
    "updated_at": "2025-09-20T06:31:05.637Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 180,
  "fields": {
    "user_profile": 6,
    "week_number": 24,
    "week_start": "2026-02-28",
    "week_end": "2026-03-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.639Z",
    "updated_at": "2025-09-20T06:31:05.639Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 181,
  "fields": {
    "user_profile": 6,
    "week_number": 25,
    "week_start": "2026-03-07",
    "week_end": "2026-03-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.642Z",
    "updated_at": "2025-09-20T06:31:05.642Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 182,
  "fields": {
    "user_profile": 6,
    "week_number": 26,
    "week_start": "2026-03-14",
    "week_end": "2026-03-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.644Z",
    "updated_at": "2025-09-20T06:31:05.644Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 183,
  "fields": {
    "user_profile": 6,
    "week_number": 27,
    "week_start": "2026-03-21",
    "week_end": "2026-03-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.647Z",
    "updated_at": "2025-09-20T06:31:05.647Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 184,
  "fields": {
    "user_profile": 6,
    "week_number": 28,
    "week_start": "2026-03-28",
    "week_end": "2026-04-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.649Z",
    "updated_at": "2025-09-20T06:31:05.649Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 185,
  "fields": {
    "user_profile": 6,
    "week_number": 29,
    "week_start": "2026-04-04",
    "week_end": "2026-04-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.651Z",
    "updated_at": "2025-09-20T06:31:05.651Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 186,
  "fields": {
    "user_profile": 6,
    "week_number": 30,
    "week_start": "2026-04-11",
    "week_end": "2026-04-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.653Z",
    "updated_at": "2025-09-20T06:31:05.653Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 187,
  "fields": {
    "user_profile": 6,
    "week_number": 31,
    "week_start": "2026-04-18",
    "week_end": "2026-04-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.656Z",
    "updated_at": "2025-09-20T06:31:05.656Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 188,
  "fields": {
    "user_profile": 6,
    "week_number": 32,
    "week_start": "2026-04-25",
    "week_end": "2026-05-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.658Z",
    "updated_at": "2025-09-20T06:31:05.658Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 189,
  "fields": {
    "user_profile": 6,
    "week_number": 33,
    "week_start": "2026-05-02",
    "week_end": "2026-05-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.661Z",
    "updated_at": "2025-09-20T06:31:05.661Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 190,
  "fields": {
    "user_profile": 6,
    "week_number": 34,
    "week_start": "2026-05-09",
    "week_end": "2026-05-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.663Z",
    "updated_at": "2025-09-20T06:31:05.663Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 191,
  "fields": {
    "user_profile": 6,
    "week_number": 35,
    "week_start": "2026-05-16",
    "week_end": "2026-05-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.665Z",
    "updated_at": "2025-09-20T06:31:05.665Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 192,
  "fields": {
    "user_profile": 6,
    "week_number": 36,
    "week_start": "2026-05-23",
    "week_end": "2026-05-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.667Z",
    "updated_at": "2025-09-20T06:31:05.667Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 193,
  "fields": {
    "user_profile": 6,
    "week_number": 37,
    "week_start": "2026-05-30",
    "week_end": "2026-06-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.669Z",
    "updated_at": "2025-09-20T06:31:05.669Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 194,
  "fields": {
    "user_profile": 6,
    "week_number": 38,
    "week_start": "2026-06-06",
    "week_end": "2026-06-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.672Z",
    "updated_at": "2025-09-20T06:31:05.672Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 195,
  "fields": {
    "user_profile": 6,
    "week_number": 39,
    "week_start": "2026-06-13",
    "week_end": "2026-06-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.675Z",
    "updated_at": "2025-09-20T06:31:05.675Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 196,
  "fields": {
    "user_profile": 6,
    "week_number": 40,
    "week_start": "2026-06-20",
    "week_end": "2026-06-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.677Z",
    "updated_at": "2025-09-20T06:31:05.677Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 197,
  "fields": {
    "user_profile": 6,
    "week_number": 41,
    "week_start": "2026-06-27",
    "week_end": "2026-07-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.680Z",
    "updated_at": "2025-09-20T06:31:05.680Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 198,
  "fields": {
    "user_profile": 6,
    "week_number": 42,
    "week_start": "2026-07-04",
    "week_end": "2026-07-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.682Z",
    "updated_at": "2025-09-20T06:31:05.682Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 199,
  "fields": {
    "user_profile": 6,
    "week_number": 43,
    "week_start": "2026-07-11",
    "week_end": "2026-07-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.684Z",
    "updated_at": "2025-09-20T06:31:05.684Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 200,
  "fields": {
    "user_profile": 6,
    "week_number": 44,
    "week_start": "2026-07-18",
    "week_end": "2026-07-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.686Z",
    "updated_at": "2025-09-20T06:31:05.686Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 201,
  "fields": {
    "user_profile": 6,
    "week_number": 45,
    "week_start": "2026-07-25",
    "week_end": "2026-07-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.689Z",
    "updated_at": "2025-09-20T06:31:05.689Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 202,
  "fields": {
    "user_profile": 6,
    "week_number": 46,
    "week_start": "2026-08-01",
    "week_end": "2026-08-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.692Z",
    "updated_at": "2025-09-20T06:31:05.692Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 203,
  "fields": {
    "user_profile": 6,
    "week_number": 47,
    "week_start": "2026-08-08",
    "week_end": "2026-08-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.694Z",
    "updated_at": "2025-09-20T06:31:05.694Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 204,
  "fields": {
    "user_profile": 6,
    "week_number": 48,
    "week_start": "2026-08-15",
    "week_end": "2026-08-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.696Z",
    "updated_at": "2025-09-20T06:31:05.696Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 205,
  "fields": {
    "user_profile": 6,
    "week_number": 49,
    "week_start": "2026-08-22",
    "week_end": "2026-08-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.699Z",
    "updated_at": "2025-09-20T06:31:05.699Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 206,
  "fields": {
    "user_profile": 6,
    "week_number": 50,
    "week_start": "2026-08-29",
    "week_end": "2026-09-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.701Z",
    "updated_at": "2025-09-20T06:31:05.701Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 207,
  "fields": {
    "user_profile": 6,
    "week_number": 51,
    "week_start": "2026-09-05",
    "week_end": "2026-09-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.703Z",
    "updated_at": "2025-09-20T06:31:05.703Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 208,
  "fields": {
    "user_profile": 6,
    "week_number": 52,
    "week_start": "2026-09-12",
    "week_end": "2026-09-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T06:31:05.705Z",
    "updated_at": "2025-09-20T06:31:05.705Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 209,
  "fields": {
    "user_profile": 12,
    "week_number": 1,
    "week_start": "2022-12-01",
    "week_end": "2022-12-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.166Z",
    "updated_at": "2025-09-20T23:49:08.166Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 210,
  "fields": {
    "user_profile": 12,
    "week_number": 2,
    "week_start": "2022-12-08",
    "week_end": "2022-12-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.169Z",
    "updated_at": "2025-09-20T23:49:08.169Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 211,
  "fields": {
    "user_profile": 12,
    "week_number": 3,
    "week_start": "2022-12-15",
    "week_end": "2022-12-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.171Z",
    "updated_at": "2025-09-20T23:49:08.171Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 212,
  "fields": {
    "user_profile": 12,
    "week_number": 4,
    "week_start": "2022-12-22",
    "week_end": "2022-12-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.172Z",
    "updated_at": "2025-09-20T23:49:08.172Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 213,
  "fields": {
    "user_profile": 12,
    "week_number": 5,
    "week_start": "2022-12-29",
    "week_end": "2023-01-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.172Z",
    "updated_at": "2025-09-20T23:49:08.172Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 214,
  "fields": {
    "user_profile": 12,
    "week_number": 6,
    "week_start": "2023-01-05",
    "week_end": "2023-01-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.173Z",
    "updated_at": "2025-09-20T23:49:08.173Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 215,
  "fields": {
    "user_profile": 12,
    "week_number": 7,
    "week_start": "2023-01-12",
    "week_end": "2023-01-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.174Z",
    "updated_at": "2025-09-20T23:49:08.174Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 216,
  "fields": {
    "user_profile": 12,
    "week_number": 8,
    "week_start": "2023-01-19",
    "week_end": "2023-01-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.176Z",
    "updated_at": "2025-09-20T23:49:08.176Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 217,
  "fields": {
    "user_profile": 12,
    "week_number": 9,
    "week_start": "2023-01-26",
    "week_end": "2023-02-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.177Z",
    "updated_at": "2025-09-20T23:49:08.177Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 218,
  "fields": {
    "user_profile": 12,
    "week_number": 10,
    "week_start": "2023-02-02",
    "week_end": "2023-02-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.178Z",
    "updated_at": "2025-09-20T23:49:08.178Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 219,
  "fields": {
    "user_profile": 12,
    "week_number": 11,
    "week_start": "2023-02-09",
    "week_end": "2023-02-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.179Z",
    "updated_at": "2025-09-20T23:49:08.179Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 220,
  "fields": {
    "user_profile": 12,
    "week_number": 12,
    "week_start": "2023-02-16",
    "week_end": "2023-02-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.180Z",
    "updated_at": "2025-09-20T23:49:08.180Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 221,
  "fields": {
    "user_profile": 12,
    "week_number": 13,
    "week_start": "2023-02-23",
    "week_end": "2023-03-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.181Z",
    "updated_at": "2025-09-20T23:49:08.181Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 222,
  "fields": {
    "user_profile": 12,
    "week_number": 14,
    "week_start": "2023-03-02",
    "week_end": "2023-03-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.182Z",
    "updated_at": "2025-09-20T23:49:08.182Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 223,
  "fields": {
    "user_profile": 12,
    "week_number": 15,
    "week_start": "2023-03-09",
    "week_end": "2023-03-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.183Z",
    "updated_at": "2025-09-20T23:49:08.183Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 224,
  "fields": {
    "user_profile": 12,
    "week_number": 16,
    "week_start": "2023-03-16",
    "week_end": "2023-03-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.184Z",
    "updated_at": "2025-09-20T23:49:08.184Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 225,
  "fields": {
    "user_profile": 12,
    "week_number": 17,
    "week_start": "2023-03-23",
    "week_end": "2023-03-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.185Z",
    "updated_at": "2025-09-20T23:49:08.185Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 226,
  "fields": {
    "user_profile": 12,
    "week_number": 18,
    "week_start": "2023-03-30",
    "week_end": "2023-04-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.186Z",
    "updated_at": "2025-09-20T23:49:08.186Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 227,
  "fields": {
    "user_profile": 12,
    "week_number": 19,
    "week_start": "2023-04-06",
    "week_end": "2023-04-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.187Z",
    "updated_at": "2025-09-20T23:49:08.187Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 228,
  "fields": {
    "user_profile": 12,
    "week_number": 20,
    "week_start": "2023-04-13",
    "week_end": "2023-04-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.188Z",
    "updated_at": "2025-09-20T23:49:08.188Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 229,
  "fields": {
    "user_profile": 12,
    "week_number": 21,
    "week_start": "2023-04-20",
    "week_end": "2023-04-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.189Z",
    "updated_at": "2025-09-20T23:49:08.189Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 230,
  "fields": {
    "user_profile": 12,
    "week_number": 22,
    "week_start": "2023-04-27",
    "week_end": "2023-05-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.190Z",
    "updated_at": "2025-09-20T23:49:08.190Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 231,
  "fields": {
    "user_profile": 12,
    "week_number": 23,
    "week_start": "2023-05-04",
    "week_end": "2023-05-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.191Z",
    "updated_at": "2025-09-20T23:49:08.191Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 232,
  "fields": {
    "user_profile": 12,
    "week_number": 24,
    "week_start": "2023-05-11",
    "week_end": "2023-05-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.192Z",
    "updated_at": "2025-09-20T23:49:08.192Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 233,
  "fields": {
    "user_profile": 12,
    "week_number": 25,
    "week_start": "2023-05-18",
    "week_end": "2023-05-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.193Z",
    "updated_at": "2025-09-20T23:49:08.193Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 234,
  "fields": {
    "user_profile": 12,
    "week_number": 26,
    "week_start": "2023-05-25",
    "week_end": "2023-05-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.193Z",
    "updated_at": "2025-09-20T23:49:08.193Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 235,
  "fields": {
    "user_profile": 12,
    "week_number": 27,
    "week_start": "2023-06-01",
    "week_end": "2023-06-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.194Z",
    "updated_at": "2025-09-20T23:49:08.194Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 236,
  "fields": {
    "user_profile": 12,
    "week_number": 28,
    "week_start": "2023-06-08",
    "week_end": "2023-06-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.195Z",
    "updated_at": "2025-09-20T23:49:08.195Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 237,
  "fields": {
    "user_profile": 12,
    "week_number": 29,
    "week_start": "2023-06-15",
    "week_end": "2023-06-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.196Z",
    "updated_at": "2025-09-20T23:49:08.196Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 238,
  "fields": {
    "user_profile": 12,
    "week_number": 30,
    "week_start": "2023-06-22",
    "week_end": "2023-06-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.197Z",
    "updated_at": "2025-09-20T23:49:08.197Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 239,
  "fields": {
    "user_profile": 12,
    "week_number": 31,
    "week_start": "2023-06-29",
    "week_end": "2023-07-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.197Z",
    "updated_at": "2025-09-20T23:49:08.197Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 240,
  "fields": {
    "user_profile": 12,
    "week_number": 32,
    "week_start": "2023-07-06",
    "week_end": "2023-07-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.198Z",
    "updated_at": "2025-09-20T23:49:08.198Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 241,
  "fields": {
    "user_profile": 12,
    "week_number": 33,
    "week_start": "2023-07-13",
    "week_end": "2023-07-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.199Z",
    "updated_at": "2025-09-20T23:49:08.199Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 242,
  "fields": {
    "user_profile": 12,
    "week_number": 34,
    "week_start": "2023-07-20",
    "week_end": "2023-07-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.200Z",
    "updated_at": "2025-09-20T23:49:08.200Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 243,
  "fields": {
    "user_profile": 12,
    "week_number": 35,
    "week_start": "2023-07-27",
    "week_end": "2023-08-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.201Z",
    "updated_at": "2025-09-20T23:49:08.201Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 244,
  "fields": {
    "user_profile": 12,
    "week_number": 36,
    "week_start": "2023-08-03",
    "week_end": "2023-08-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.201Z",
    "updated_at": "2025-09-20T23:49:08.201Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 245,
  "fields": {
    "user_profile": 12,
    "week_number": 37,
    "week_start": "2023-08-10",
    "week_end": "2023-08-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.202Z",
    "updated_at": "2025-09-20T23:49:08.202Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 246,
  "fields": {
    "user_profile": 12,
    "week_number": 38,
    "week_start": "2023-08-17",
    "week_end": "2023-08-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.203Z",
    "updated_at": "2025-09-20T23:49:08.203Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 247,
  "fields": {
    "user_profile": 12,
    "week_number": 39,
    "week_start": "2023-08-24",
    "week_end": "2023-08-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.203Z",
    "updated_at": "2025-09-20T23:49:08.203Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 248,
  "fields": {
    "user_profile": 12,
    "week_number": 40,
    "week_start": "2023-08-31",
    "week_end": "2023-09-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.204Z",
    "updated_at": "2025-09-20T23:49:08.204Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 249,
  "fields": {
    "user_profile": 12,
    "week_number": 41,
    "week_start": "2023-09-07",
    "week_end": "2023-09-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.205Z",
    "updated_at": "2025-09-20T23:49:08.205Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 250,
  "fields": {
    "user_profile": 12,
    "week_number": 42,
    "week_start": "2023-09-14",
    "week_end": "2023-09-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.205Z",
    "updated_at": "2025-09-20T23:49:08.205Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 251,
  "fields": {
    "user_profile": 12,
    "week_number": 43,
    "week_start": "2023-09-21",
    "week_end": "2023-09-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.206Z",
    "updated_at": "2025-09-20T23:49:08.206Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 252,
  "fields": {
    "user_profile": 12,
    "week_number": 44,
    "week_start": "2023-09-28",
    "week_end": "2023-10-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.207Z",
    "updated_at": "2025-09-20T23:49:08.207Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 253,
  "fields": {
    "user_profile": 12,
    "week_number": 45,
    "week_start": "2023-10-05",
    "week_end": "2023-10-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.208Z",
    "updated_at": "2025-09-20T23:49:08.208Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 254,
  "fields": {
    "user_profile": 12,
    "week_number": 46,
    "week_start": "2023-10-12",
    "week_end": "2023-10-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.209Z",
    "updated_at": "2025-09-20T23:49:08.209Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 255,
  "fields": {
    "user_profile": 12,
    "week_number": 47,
    "week_start": "2023-10-19",
    "week_end": "2023-10-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.210Z",
    "updated_at": "2025-09-20T23:49:08.210Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 256,
  "fields": {
    "user_profile": 12,
    "week_number": 48,
    "week_start": "2023-10-26",
    "week_end": "2023-11-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.211Z",
    "updated_at": "2025-09-20T23:49:08.211Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 257,
  "fields": {
    "user_profile": 12,
    "week_number": 49,
    "week_start": "2023-11-02",
    "week_end": "2023-11-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.211Z",
    "updated_at": "2025-09-20T23:49:08.211Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 258,
  "fields": {
    "user_profile": 12,
    "week_number": 50,
    "week_start": "2023-11-09",
    "week_end": "2023-11-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.213Z",
    "updated_at": "2025-09-20T23:49:08.213Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 259,
  "fields": {
    "user_profile": 12,
    "week_number": 51,
    "week_start": "2023-11-16",
    "week_end": "2023-11-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.213Z",
    "updated_at": "2025-09-20T23:49:08.213Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 260,
  "fields": {
    "user_profile": 12,
    "week_number": 52,
    "week_start": "2023-11-23",
    "week_end": "2023-11-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-20T23:49:08.214Z",
    "updated_at": "2025-09-20T23:49:08.214Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 313,
  "fields": {
    "user_profile": 18,
    "week_number": 1,
    "week_start": "2025-01-01",
    "week_end": "2025-01-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.127Z",
    "updated_at": "2025-09-21T00:01:53.127Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 314,
  "fields": {
    "user_profile": 18,
    "week_number": 2,
    "week_start": "2025-01-08",
    "week_end": "2025-01-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.129Z",
    "updated_at": "2025-09-21T00:01:53.129Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 315,
  "fields": {
    "user_profile": 18,
    "week_number": 3,
    "week_start": "2025-01-15",
    "week_end": "2025-01-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.130Z",
    "updated_at": "2025-09-21T00:01:53.130Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 316,
  "fields": {
    "user_profile": 18,
    "week_number": 4,
    "week_start": "2025-01-22",
    "week_end": "2025-01-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.131Z",
    "updated_at": "2025-09-21T00:01:53.131Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 317,
  "fields": {
    "user_profile": 18,
    "week_number": 5,
    "week_start": "2025-01-29",
    "week_end": "2025-02-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.132Z",
    "updated_at": "2025-09-21T00:01:53.132Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 318,
  "fields": {
    "user_profile": 18,
    "week_number": 6,
    "week_start": "2025-02-05",
    "week_end": "2025-02-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.133Z",
    "updated_at": "2025-09-21T00:01:53.133Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 319,
  "fields": {
    "user_profile": 18,
    "week_number": 7,
    "week_start": "2025-02-12",
    "week_end": "2025-02-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.134Z",
    "updated_at": "2025-09-21T00:01:53.134Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 320,
  "fields": {
    "user_profile": 18,
    "week_number": 8,
    "week_start": "2025-02-19",
    "week_end": "2025-02-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.135Z",
    "updated_at": "2025-09-21T00:01:53.135Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 321,
  "fields": {
    "user_profile": 18,
    "week_number": 9,
    "week_start": "2025-02-26",
    "week_end": "2025-03-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.136Z",
    "updated_at": "2025-09-21T00:01:53.136Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 322,
  "fields": {
    "user_profile": 18,
    "week_number": 10,
    "week_start": "2025-03-05",
    "week_end": "2025-03-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.137Z",
    "updated_at": "2025-09-21T00:01:53.137Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 323,
  "fields": {
    "user_profile": 18,
    "week_number": 11,
    "week_start": "2025-03-12",
    "week_end": "2025-03-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.138Z",
    "updated_at": "2025-09-21T00:01:53.138Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 324,
  "fields": {
    "user_profile": 18,
    "week_number": 12,
    "week_start": "2025-03-19",
    "week_end": "2025-03-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.139Z",
    "updated_at": "2025-09-21T00:01:53.139Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 325,
  "fields": {
    "user_profile": 18,
    "week_number": 13,
    "week_start": "2025-03-26",
    "week_end": "2025-04-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.140Z",
    "updated_at": "2025-09-21T00:01:53.140Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 326,
  "fields": {
    "user_profile": 18,
    "week_number": 14,
    "week_start": "2025-04-02",
    "week_end": "2025-04-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.141Z",
    "updated_at": "2025-09-21T00:01:53.141Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 327,
  "fields": {
    "user_profile": 18,
    "week_number": 15,
    "week_start": "2025-04-09",
    "week_end": "2025-04-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.144Z",
    "updated_at": "2025-09-21T00:01:53.144Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 328,
  "fields": {
    "user_profile": 18,
    "week_number": 16,
    "week_start": "2025-04-16",
    "week_end": "2025-04-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.145Z",
    "updated_at": "2025-09-21T00:01:53.145Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 329,
  "fields": {
    "user_profile": 18,
    "week_number": 17,
    "week_start": "2025-04-23",
    "week_end": "2025-04-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.145Z",
    "updated_at": "2025-09-21T00:01:53.145Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 330,
  "fields": {
    "user_profile": 18,
    "week_number": 18,
    "week_start": "2025-04-30",
    "week_end": "2025-05-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.147Z",
    "updated_at": "2025-09-21T00:01:53.147Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 331,
  "fields": {
    "user_profile": 18,
    "week_number": 19,
    "week_start": "2025-05-07",
    "week_end": "2025-05-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.148Z",
    "updated_at": "2025-09-21T00:01:53.148Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 332,
  "fields": {
    "user_profile": 18,
    "week_number": 20,
    "week_start": "2025-05-14",
    "week_end": "2025-05-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.149Z",
    "updated_at": "2025-09-21T00:01:53.149Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 333,
  "fields": {
    "user_profile": 18,
    "week_number": 21,
    "week_start": "2025-05-21",
    "week_end": "2025-05-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.150Z",
    "updated_at": "2025-09-21T00:01:53.150Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 334,
  "fields": {
    "user_profile": 18,
    "week_number": 22,
    "week_start": "2025-05-28",
    "week_end": "2025-06-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.151Z",
    "updated_at": "2025-09-21T00:01:53.151Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 335,
  "fields": {
    "user_profile": 18,
    "week_number": 23,
    "week_start": "2025-06-04",
    "week_end": "2025-06-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.151Z",
    "updated_at": "2025-09-21T00:01:53.151Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 336,
  "fields": {
    "user_profile": 18,
    "week_number": 24,
    "week_start": "2025-06-11",
    "week_end": "2025-06-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.152Z",
    "updated_at": "2025-09-21T00:01:53.152Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 337,
  "fields": {
    "user_profile": 18,
    "week_number": 25,
    "week_start": "2025-06-18",
    "week_end": "2025-06-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.153Z",
    "updated_at": "2025-09-21T00:01:53.153Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 338,
  "fields": {
    "user_profile": 18,
    "week_number": 26,
    "week_start": "2025-06-25",
    "week_end": "2025-07-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.154Z",
    "updated_at": "2025-09-21T00:01:53.154Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 339,
  "fields": {
    "user_profile": 18,
    "week_number": 27,
    "week_start": "2025-07-02",
    "week_end": "2025-07-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.155Z",
    "updated_at": "2025-09-21T00:01:53.155Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 340,
  "fields": {
    "user_profile": 18,
    "week_number": 28,
    "week_start": "2025-07-09",
    "week_end": "2025-07-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.156Z",
    "updated_at": "2025-09-21T00:01:53.156Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 341,
  "fields": {
    "user_profile": 18,
    "week_number": 29,
    "week_start": "2025-07-16",
    "week_end": "2025-07-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.157Z",
    "updated_at": "2025-09-21T00:01:53.157Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 342,
  "fields": {
    "user_profile": 18,
    "week_number": 30,
    "week_start": "2025-07-23",
    "week_end": "2025-07-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.158Z",
    "updated_at": "2025-09-21T00:01:53.158Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 343,
  "fields": {
    "user_profile": 18,
    "week_number": 31,
    "week_start": "2025-07-30",
    "week_end": "2025-08-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.159Z",
    "updated_at": "2025-09-21T00:01:53.159Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 344,
  "fields": {
    "user_profile": 18,
    "week_number": 32,
    "week_start": "2025-08-06",
    "week_end": "2025-08-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.160Z",
    "updated_at": "2025-09-21T00:01:53.160Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 345,
  "fields": {
    "user_profile": 18,
    "week_number": 33,
    "week_start": "2025-08-13",
    "week_end": "2025-08-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.161Z",
    "updated_at": "2025-09-21T00:01:53.161Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 346,
  "fields": {
    "user_profile": 18,
    "week_number": 34,
    "week_start": "2025-08-20",
    "week_end": "2025-08-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.161Z",
    "updated_at": "2025-09-21T00:01:53.161Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 347,
  "fields": {
    "user_profile": 18,
    "week_number": 35,
    "week_start": "2025-08-27",
    "week_end": "2025-09-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.162Z",
    "updated_at": "2025-09-21T00:01:53.162Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 348,
  "fields": {
    "user_profile": 18,
    "week_number": 36,
    "week_start": "2025-09-03",
    "week_end": "2025-09-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.163Z",
    "updated_at": "2025-09-21T00:01:53.163Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 349,
  "fields": {
    "user_profile": 18,
    "week_number": 37,
    "week_start": "2025-09-10",
    "week_end": "2025-09-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.164Z",
    "updated_at": "2025-09-21T00:01:53.164Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 350,
  "fields": {
    "user_profile": 18,
    "week_number": 38,
    "week_start": "2025-09-17",
    "week_end": "2025-09-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.164Z",
    "updated_at": "2025-09-21T00:01:53.164Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 351,
  "fields": {
    "user_profile": 18,
    "week_number": 39,
    "week_start": "2025-09-24",
    "week_end": "2025-09-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.165Z",
    "updated_at": "2025-09-21T00:01:53.165Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 352,
  "fields": {
    "user_profile": 18,
    "week_number": 40,
    "week_start": "2025-10-01",
    "week_end": "2025-10-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.166Z",
    "updated_at": "2025-09-21T00:01:53.166Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 353,
  "fields": {
    "user_profile": 18,
    "week_number": 41,
    "week_start": "2025-10-08",
    "week_end": "2025-10-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.167Z",
    "updated_at": "2025-09-21T00:01:53.167Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 354,
  "fields": {
    "user_profile": 18,
    "week_number": 42,
    "week_start": "2025-10-15",
    "week_end": "2025-10-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.167Z",
    "updated_at": "2025-09-21T00:01:53.167Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 355,
  "fields": {
    "user_profile": 18,
    "week_number": 43,
    "week_start": "2025-10-22",
    "week_end": "2025-10-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.168Z",
    "updated_at": "2025-09-21T00:01:53.168Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 356,
  "fields": {
    "user_profile": 18,
    "week_number": 44,
    "week_start": "2025-10-29",
    "week_end": "2025-11-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.169Z",
    "updated_at": "2025-09-21T00:01:53.169Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 357,
  "fields": {
    "user_profile": 18,
    "week_number": 45,
    "week_start": "2025-11-05",
    "week_end": "2025-11-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.170Z",
    "updated_at": "2025-09-21T00:01:53.170Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 358,
  "fields": {
    "user_profile": 18,
    "week_number": 46,
    "week_start": "2025-11-12",
    "week_end": "2025-11-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.171Z",
    "updated_at": "2025-09-21T00:01:53.171Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 359,
  "fields": {
    "user_profile": 18,
    "week_number": 47,
    "week_start": "2025-11-19",
    "week_end": "2025-11-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.172Z",
    "updated_at": "2025-09-21T00:01:53.172Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 360,
  "fields": {
    "user_profile": 18,
    "week_number": 48,
    "week_start": "2025-11-26",
    "week_end": "2025-12-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.173Z",
    "updated_at": "2025-09-21T00:01:53.173Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 361,
  "fields": {
    "user_profile": 18,
    "week_number": 49,
    "week_start": "2025-12-03",
    "week_end": "2025-12-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.174Z",
    "updated_at": "2025-09-21T00:01:53.174Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 362,
  "fields": {
    "user_profile": 18,
    "week_number": 50,
    "week_start": "2025-12-10",
    "week_end": "2025-12-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.175Z",
    "updated_at": "2025-09-21T00:01:53.175Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 363,
  "fields": {
    "user_profile": 18,
    "week_number": 51,
    "week_start": "2025-12-17",
    "week_end": "2025-12-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.176Z",
    "updated_at": "2025-09-21T00:01:53.176Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 364,
  "fields": {
    "user_profile": 18,
    "week_number": 52,
    "week_start": "2025-12-24",
    "week_end": "2025-12-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T00:01:53.177Z",
    "updated_at": "2025-09-21T00:01:53.177Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1093,
  "fields": {
    "user_profile": 39,
    "week_number": 1,
    "week_start": "2025-08-31",
    "week_end": "2025-09-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.788Z",
    "updated_at": "2025-09-21T21:09:56.788Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1094,
  "fields": {
    "user_profile": 39,
    "week_number": 2,
    "week_start": "2025-09-07",
    "week_end": "2025-09-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.790Z",
    "updated_at": "2025-09-21T21:09:56.790Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1095,
  "fields": {
    "user_profile": 39,
    "week_number": 3,
    "week_start": "2025-09-14",
    "week_end": "2025-09-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.791Z",
    "updated_at": "2025-09-21T21:09:56.791Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1096,
  "fields": {
    "user_profile": 39,
    "week_number": 4,
    "week_start": "2025-09-21",
    "week_end": "2025-09-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.793Z",
    "updated_at": "2025-09-21T21:09:56.793Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1097,
  "fields": {
    "user_profile": 39,
    "week_number": 5,
    "week_start": "2025-09-28",
    "week_end": "2025-10-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.794Z",
    "updated_at": "2025-09-21T21:09:56.794Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1098,
  "fields": {
    "user_profile": 39,
    "week_number": 6,
    "week_start": "2025-10-05",
    "week_end": "2025-10-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.795Z",
    "updated_at": "2025-09-21T21:09:56.795Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1099,
  "fields": {
    "user_profile": 39,
    "week_number": 7,
    "week_start": "2025-10-12",
    "week_end": "2025-10-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.796Z",
    "updated_at": "2025-09-21T21:09:56.796Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1100,
  "fields": {
    "user_profile": 39,
    "week_number": 8,
    "week_start": "2025-10-19",
    "week_end": "2025-10-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.797Z",
    "updated_at": "2025-09-21T21:09:56.797Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1101,
  "fields": {
    "user_profile": 39,
    "week_number": 9,
    "week_start": "2025-10-26",
    "week_end": "2025-11-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.798Z",
    "updated_at": "2025-09-21T21:09:56.798Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1102,
  "fields": {
    "user_profile": 39,
    "week_number": 10,
    "week_start": "2025-11-02",
    "week_end": "2025-11-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.799Z",
    "updated_at": "2025-09-21T21:09:56.799Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1103,
  "fields": {
    "user_profile": 39,
    "week_number": 11,
    "week_start": "2025-11-09",
    "week_end": "2025-11-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.801Z",
    "updated_at": "2025-09-21T21:09:56.801Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1104,
  "fields": {
    "user_profile": 39,
    "week_number": 12,
    "week_start": "2025-11-16",
    "week_end": "2025-11-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.802Z",
    "updated_at": "2025-09-21T21:09:56.802Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1105,
  "fields": {
    "user_profile": 39,
    "week_number": 13,
    "week_start": "2025-11-23",
    "week_end": "2025-11-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.803Z",
    "updated_at": "2025-09-21T21:09:56.803Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1106,
  "fields": {
    "user_profile": 39,
    "week_number": 14,
    "week_start": "2025-11-30",
    "week_end": "2025-12-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.805Z",
    "updated_at": "2025-09-21T21:09:56.805Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1107,
  "fields": {
    "user_profile": 39,
    "week_number": 15,
    "week_start": "2025-12-07",
    "week_end": "2025-12-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.806Z",
    "updated_at": "2025-09-21T21:09:56.806Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1108,
  "fields": {
    "user_profile": 39,
    "week_number": 16,
    "week_start": "2025-12-14",
    "week_end": "2025-12-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.807Z",
    "updated_at": "2025-09-21T21:09:56.807Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1109,
  "fields": {
    "user_profile": 39,
    "week_number": 17,
    "week_start": "2025-12-21",
    "week_end": "2025-12-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.808Z",
    "updated_at": "2025-09-21T21:09:56.808Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1110,
  "fields": {
    "user_profile": 39,
    "week_number": 18,
    "week_start": "2025-12-28",
    "week_end": "2026-01-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.809Z",
    "updated_at": "2025-09-21T21:09:56.809Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1111,
  "fields": {
    "user_profile": 39,
    "week_number": 19,
    "week_start": "2026-01-04",
    "week_end": "2026-01-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.810Z",
    "updated_at": "2025-09-21T21:09:56.810Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1112,
  "fields": {
    "user_profile": 39,
    "week_number": 20,
    "week_start": "2026-01-11",
    "week_end": "2026-01-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.812Z",
    "updated_at": "2025-09-21T21:09:56.812Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1113,
  "fields": {
    "user_profile": 39,
    "week_number": 21,
    "week_start": "2026-01-18",
    "week_end": "2026-01-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.813Z",
    "updated_at": "2025-09-21T21:09:56.813Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1114,
  "fields": {
    "user_profile": 39,
    "week_number": 22,
    "week_start": "2026-01-25",
    "week_end": "2026-01-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.814Z",
    "updated_at": "2025-09-21T21:09:56.814Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1115,
  "fields": {
    "user_profile": 39,
    "week_number": 23,
    "week_start": "2026-02-01",
    "week_end": "2026-02-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.815Z",
    "updated_at": "2025-09-21T21:09:56.815Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1116,
  "fields": {
    "user_profile": 39,
    "week_number": 24,
    "week_start": "2026-02-08",
    "week_end": "2026-02-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.816Z",
    "updated_at": "2025-09-21T21:09:56.816Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1117,
  "fields": {
    "user_profile": 39,
    "week_number": 25,
    "week_start": "2026-02-15",
    "week_end": "2026-02-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.817Z",
    "updated_at": "2025-09-21T21:09:56.817Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1118,
  "fields": {
    "user_profile": 39,
    "week_number": 26,
    "week_start": "2026-02-22",
    "week_end": "2026-02-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.833Z",
    "updated_at": "2025-09-21T21:09:56.833Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1119,
  "fields": {
    "user_profile": 39,
    "week_number": 27,
    "week_start": "2026-03-01",
    "week_end": "2026-03-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.835Z",
    "updated_at": "2025-09-21T21:09:56.835Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1120,
  "fields": {
    "user_profile": 39,
    "week_number": 28,
    "week_start": "2026-03-08",
    "week_end": "2026-03-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.837Z",
    "updated_at": "2025-09-21T21:09:56.837Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1121,
  "fields": {
    "user_profile": 39,
    "week_number": 29,
    "week_start": "2026-03-15",
    "week_end": "2026-03-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.837Z",
    "updated_at": "2025-09-21T21:09:56.837Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1122,
  "fields": {
    "user_profile": 39,
    "week_number": 30,
    "week_start": "2026-03-22",
    "week_end": "2026-03-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.838Z",
    "updated_at": "2025-09-21T21:09:56.838Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1123,
  "fields": {
    "user_profile": 39,
    "week_number": 31,
    "week_start": "2026-03-29",
    "week_end": "2026-04-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.840Z",
    "updated_at": "2025-09-21T21:09:56.840Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1124,
  "fields": {
    "user_profile": 39,
    "week_number": 32,
    "week_start": "2026-04-05",
    "week_end": "2026-04-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.841Z",
    "updated_at": "2025-09-21T21:09:56.841Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1125,
  "fields": {
    "user_profile": 39,
    "week_number": 33,
    "week_start": "2026-04-12",
    "week_end": "2026-04-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.842Z",
    "updated_at": "2025-09-21T21:09:56.842Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1126,
  "fields": {
    "user_profile": 39,
    "week_number": 34,
    "week_start": "2026-04-19",
    "week_end": "2026-04-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.843Z",
    "updated_at": "2025-09-21T21:09:56.843Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1127,
  "fields": {
    "user_profile": 39,
    "week_number": 35,
    "week_start": "2026-04-26",
    "week_end": "2026-05-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.844Z",
    "updated_at": "2025-09-21T21:09:56.844Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1128,
  "fields": {
    "user_profile": 39,
    "week_number": 36,
    "week_start": "2026-05-03",
    "week_end": "2026-05-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.846Z",
    "updated_at": "2025-09-21T21:09:56.846Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1129,
  "fields": {
    "user_profile": 39,
    "week_number": 37,
    "week_start": "2026-05-10",
    "week_end": "2026-05-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.847Z",
    "updated_at": "2025-09-21T21:09:56.847Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1130,
  "fields": {
    "user_profile": 39,
    "week_number": 38,
    "week_start": "2026-05-17",
    "week_end": "2026-05-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.848Z",
    "updated_at": "2025-09-21T21:09:56.848Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1131,
  "fields": {
    "user_profile": 39,
    "week_number": 39,
    "week_start": "2026-05-24",
    "week_end": "2026-05-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.849Z",
    "updated_at": "2025-09-21T21:09:56.849Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1132,
  "fields": {
    "user_profile": 39,
    "week_number": 40,
    "week_start": "2026-05-31",
    "week_end": "2026-06-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.850Z",
    "updated_at": "2025-09-21T21:09:56.850Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1133,
  "fields": {
    "user_profile": 39,
    "week_number": 41,
    "week_start": "2026-06-07",
    "week_end": "2026-06-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.851Z",
    "updated_at": "2025-09-21T21:09:56.851Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1134,
  "fields": {
    "user_profile": 39,
    "week_number": 42,
    "week_start": "2026-06-14",
    "week_end": "2026-06-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.852Z",
    "updated_at": "2025-09-21T21:09:56.852Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1135,
  "fields": {
    "user_profile": 39,
    "week_number": 43,
    "week_start": "2026-06-21",
    "week_end": "2026-06-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.853Z",
    "updated_at": "2025-09-21T21:09:56.853Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1136,
  "fields": {
    "user_profile": 39,
    "week_number": 44,
    "week_start": "2026-06-28",
    "week_end": "2026-07-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.854Z",
    "updated_at": "2025-09-21T21:09:56.854Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1137,
  "fields": {
    "user_profile": 39,
    "week_number": 45,
    "week_start": "2026-07-05",
    "week_end": "2026-07-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.856Z",
    "updated_at": "2025-09-21T21:09:56.856Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1138,
  "fields": {
    "user_profile": 39,
    "week_number": 46,
    "week_start": "2026-07-12",
    "week_end": "2026-07-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.857Z",
    "updated_at": "2025-09-21T21:09:56.857Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1139,
  "fields": {
    "user_profile": 39,
    "week_number": 47,
    "week_start": "2026-07-19",
    "week_end": "2026-07-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.858Z",
    "updated_at": "2025-09-21T21:09:56.858Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1140,
  "fields": {
    "user_profile": 39,
    "week_number": 48,
    "week_start": "2026-07-26",
    "week_end": "2026-08-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.859Z",
    "updated_at": "2025-09-21T21:09:56.859Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1141,
  "fields": {
    "user_profile": 39,
    "week_number": 49,
    "week_start": "2026-08-02",
    "week_end": "2026-08-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.860Z",
    "updated_at": "2025-09-21T21:09:56.860Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1142,
  "fields": {
    "user_profile": 39,
    "week_number": 50,
    "week_start": "2026-08-09",
    "week_end": "2026-08-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.861Z",
    "updated_at": "2025-09-21T21:09:56.861Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1143,
  "fields": {
    "user_profile": 39,
    "week_number": 51,
    "week_start": "2026-08-16",
    "week_end": "2026-08-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.862Z",
    "updated_at": "2025-09-21T21:09:56.862Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1144,
  "fields": {
    "user_profile": 39,
    "week_number": 52,
    "week_start": "2026-08-23",
    "week_end": "2026-08-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-21T21:09:56.863Z",
    "updated_at": "2025-09-21T21:09:56.863Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1145,
  "fields": {
    "user_profile": 42,
    "week_number": 1,
    "week_start": "2025-09-23",
    "week_end": "2025-09-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.519Z",
    "updated_at": "2025-09-23T12:04:26.519Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1146,
  "fields": {
    "user_profile": 42,
    "week_number": 2,
    "week_start": "2025-09-30",
    "week_end": "2025-10-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.523Z",
    "updated_at": "2025-09-23T12:04:26.523Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1147,
  "fields": {
    "user_profile": 42,
    "week_number": 3,
    "week_start": "2025-10-07",
    "week_end": "2025-10-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.524Z",
    "updated_at": "2025-09-23T12:04:26.524Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1148,
  "fields": {
    "user_profile": 42,
    "week_number": 4,
    "week_start": "2025-10-14",
    "week_end": "2025-10-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.526Z",
    "updated_at": "2025-09-23T12:04:26.526Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1149,
  "fields": {
    "user_profile": 42,
    "week_number": 5,
    "week_start": "2025-10-21",
    "week_end": "2025-10-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.527Z",
    "updated_at": "2025-09-23T12:04:26.527Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1150,
  "fields": {
    "user_profile": 42,
    "week_number": 6,
    "week_start": "2025-10-28",
    "week_end": "2025-11-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.528Z",
    "updated_at": "2025-09-23T12:04:26.528Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1151,
  "fields": {
    "user_profile": 42,
    "week_number": 7,
    "week_start": "2025-11-04",
    "week_end": "2025-11-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.529Z",
    "updated_at": "2025-09-23T12:04:26.529Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1152,
  "fields": {
    "user_profile": 42,
    "week_number": 8,
    "week_start": "2025-11-11",
    "week_end": "2025-11-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.530Z",
    "updated_at": "2025-09-23T12:04:26.530Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1153,
  "fields": {
    "user_profile": 42,
    "week_number": 9,
    "week_start": "2025-11-18",
    "week_end": "2025-11-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.531Z",
    "updated_at": "2025-09-23T12:04:26.531Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1154,
  "fields": {
    "user_profile": 42,
    "week_number": 10,
    "week_start": "2025-11-25",
    "week_end": "2025-12-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.532Z",
    "updated_at": "2025-09-23T12:04:26.532Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1155,
  "fields": {
    "user_profile": 42,
    "week_number": 11,
    "week_start": "2025-12-02",
    "week_end": "2025-12-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.533Z",
    "updated_at": "2025-09-23T12:04:26.533Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1156,
  "fields": {
    "user_profile": 42,
    "week_number": 12,
    "week_start": "2025-12-09",
    "week_end": "2025-12-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.534Z",
    "updated_at": "2025-09-23T12:04:26.534Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1157,
  "fields": {
    "user_profile": 42,
    "week_number": 13,
    "week_start": "2025-12-16",
    "week_end": "2025-12-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.535Z",
    "updated_at": "2025-09-23T12:04:26.535Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1158,
  "fields": {
    "user_profile": 42,
    "week_number": 14,
    "week_start": "2025-12-23",
    "week_end": "2025-12-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.536Z",
    "updated_at": "2025-09-23T12:04:26.536Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1159,
  "fields": {
    "user_profile": 42,
    "week_number": 15,
    "week_start": "2025-12-30",
    "week_end": "2026-01-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.537Z",
    "updated_at": "2025-09-23T12:04:26.537Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1160,
  "fields": {
    "user_profile": 42,
    "week_number": 16,
    "week_start": "2026-01-06",
    "week_end": "2026-01-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.538Z",
    "updated_at": "2025-09-23T12:04:26.538Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1161,
  "fields": {
    "user_profile": 42,
    "week_number": 17,
    "week_start": "2026-01-13",
    "week_end": "2026-01-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.539Z",
    "updated_at": "2025-09-23T12:04:26.539Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1162,
  "fields": {
    "user_profile": 42,
    "week_number": 18,
    "week_start": "2026-01-20",
    "week_end": "2026-01-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.540Z",
    "updated_at": "2025-09-23T12:04:26.540Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1163,
  "fields": {
    "user_profile": 42,
    "week_number": 19,
    "week_start": "2026-01-27",
    "week_end": "2026-02-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.541Z",
    "updated_at": "2025-09-23T12:04:26.541Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1164,
  "fields": {
    "user_profile": 42,
    "week_number": 20,
    "week_start": "2026-02-03",
    "week_end": "2026-02-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.542Z",
    "updated_at": "2025-09-23T12:04:26.542Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1165,
  "fields": {
    "user_profile": 42,
    "week_number": 21,
    "week_start": "2026-02-10",
    "week_end": "2026-02-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.543Z",
    "updated_at": "2025-09-23T12:04:26.543Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1166,
  "fields": {
    "user_profile": 42,
    "week_number": 22,
    "week_start": "2026-02-17",
    "week_end": "2026-02-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.544Z",
    "updated_at": "2025-09-23T12:04:26.544Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1167,
  "fields": {
    "user_profile": 42,
    "week_number": 23,
    "week_start": "2026-02-24",
    "week_end": "2026-03-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.545Z",
    "updated_at": "2025-09-23T12:04:26.545Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1168,
  "fields": {
    "user_profile": 42,
    "week_number": 24,
    "week_start": "2026-03-03",
    "week_end": "2026-03-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.546Z",
    "updated_at": "2025-09-23T12:04:26.546Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1169,
  "fields": {
    "user_profile": 42,
    "week_number": 25,
    "week_start": "2026-03-10",
    "week_end": "2026-03-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.547Z",
    "updated_at": "2025-09-23T12:04:26.547Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1170,
  "fields": {
    "user_profile": 42,
    "week_number": 26,
    "week_start": "2026-03-17",
    "week_end": "2026-03-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.548Z",
    "updated_at": "2025-09-23T12:04:26.548Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1171,
  "fields": {
    "user_profile": 42,
    "week_number": 27,
    "week_start": "2026-03-24",
    "week_end": "2026-03-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.549Z",
    "updated_at": "2025-09-23T12:04:26.549Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1172,
  "fields": {
    "user_profile": 42,
    "week_number": 28,
    "week_start": "2026-03-31",
    "week_end": "2026-04-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.551Z",
    "updated_at": "2025-09-23T12:04:26.551Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1173,
  "fields": {
    "user_profile": 42,
    "week_number": 29,
    "week_start": "2026-04-07",
    "week_end": "2026-04-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.552Z",
    "updated_at": "2025-09-23T12:04:26.552Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1174,
  "fields": {
    "user_profile": 42,
    "week_number": 30,
    "week_start": "2026-04-14",
    "week_end": "2026-04-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.553Z",
    "updated_at": "2025-09-23T12:04:26.553Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1175,
  "fields": {
    "user_profile": 42,
    "week_number": 31,
    "week_start": "2026-04-21",
    "week_end": "2026-04-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.555Z",
    "updated_at": "2025-09-23T12:04:26.555Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1176,
  "fields": {
    "user_profile": 42,
    "week_number": 32,
    "week_start": "2026-04-28",
    "week_end": "2026-05-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.556Z",
    "updated_at": "2025-09-23T12:04:26.556Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1177,
  "fields": {
    "user_profile": 42,
    "week_number": 33,
    "week_start": "2026-05-05",
    "week_end": "2026-05-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.557Z",
    "updated_at": "2025-09-23T12:04:26.557Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1178,
  "fields": {
    "user_profile": 42,
    "week_number": 34,
    "week_start": "2026-05-12",
    "week_end": "2026-05-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.558Z",
    "updated_at": "2025-09-23T12:04:26.558Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1179,
  "fields": {
    "user_profile": 42,
    "week_number": 35,
    "week_start": "2026-05-19",
    "week_end": "2026-05-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.559Z",
    "updated_at": "2025-09-23T12:04:26.559Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1180,
  "fields": {
    "user_profile": 42,
    "week_number": 36,
    "week_start": "2026-05-26",
    "week_end": "2026-06-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.560Z",
    "updated_at": "2025-09-23T12:04:26.560Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1181,
  "fields": {
    "user_profile": 42,
    "week_number": 37,
    "week_start": "2026-06-02",
    "week_end": "2026-06-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.561Z",
    "updated_at": "2025-09-23T12:04:26.561Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1182,
  "fields": {
    "user_profile": 42,
    "week_number": 38,
    "week_start": "2026-06-09",
    "week_end": "2026-06-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.562Z",
    "updated_at": "2025-09-23T12:04:26.562Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1183,
  "fields": {
    "user_profile": 42,
    "week_number": 39,
    "week_start": "2026-06-16",
    "week_end": "2026-06-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.563Z",
    "updated_at": "2025-09-23T12:04:26.563Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1184,
  "fields": {
    "user_profile": 42,
    "week_number": 40,
    "week_start": "2026-06-23",
    "week_end": "2026-06-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.565Z",
    "updated_at": "2025-09-23T12:04:26.565Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1185,
  "fields": {
    "user_profile": 42,
    "week_number": 41,
    "week_start": "2026-06-30",
    "week_end": "2026-07-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.566Z",
    "updated_at": "2025-09-23T12:04:26.566Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1186,
  "fields": {
    "user_profile": 42,
    "week_number": 42,
    "week_start": "2026-07-07",
    "week_end": "2026-07-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.567Z",
    "updated_at": "2025-09-23T12:04:26.567Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1187,
  "fields": {
    "user_profile": 42,
    "week_number": 43,
    "week_start": "2026-07-14",
    "week_end": "2026-07-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.570Z",
    "updated_at": "2025-09-23T12:04:26.570Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1188,
  "fields": {
    "user_profile": 42,
    "week_number": 44,
    "week_start": "2026-07-21",
    "week_end": "2026-07-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.572Z",
    "updated_at": "2025-09-23T12:04:26.572Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1189,
  "fields": {
    "user_profile": 42,
    "week_number": 45,
    "week_start": "2026-07-28",
    "week_end": "2026-08-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.573Z",
    "updated_at": "2025-09-23T12:04:26.573Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1190,
  "fields": {
    "user_profile": 42,
    "week_number": 46,
    "week_start": "2026-08-04",
    "week_end": "2026-08-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.574Z",
    "updated_at": "2025-09-23T12:04:26.574Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1191,
  "fields": {
    "user_profile": 42,
    "week_number": 47,
    "week_start": "2026-08-11",
    "week_end": "2026-08-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.575Z",
    "updated_at": "2025-09-23T12:04:26.575Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1192,
  "fields": {
    "user_profile": 42,
    "week_number": 48,
    "week_start": "2026-08-18",
    "week_end": "2026-08-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.576Z",
    "updated_at": "2025-09-23T12:04:26.576Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1193,
  "fields": {
    "user_profile": 42,
    "week_number": 49,
    "week_start": "2026-08-25",
    "week_end": "2026-08-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.577Z",
    "updated_at": "2025-09-23T12:04:26.577Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1194,
  "fields": {
    "user_profile": 42,
    "week_number": 50,
    "week_start": "2026-09-01",
    "week_end": "2026-09-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.578Z",
    "updated_at": "2025-09-23T12:04:26.578Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1195,
  "fields": {
    "user_profile": 42,
    "week_number": 51,
    "week_start": "2026-09-08",
    "week_end": "2026-09-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.579Z",
    "updated_at": "2025-09-23T12:04:26.579Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1196,
  "fields": {
    "user_profile": 42,
    "week_number": 52,
    "week_start": "2026-09-15",
    "week_end": "2026-09-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-23T12:04:26.580Z",
    "updated_at": "2025-09-23T12:04:26.580Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1197,
  "fields": {
    "user_profile": 43,
    "week_number": 1,
    "week_start": "2025-08-31",
    "week_end": "2025-09-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.892Z",
    "updated_at": "2025-09-26T03:08:55.892Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1198,
  "fields": {
    "user_profile": 43,
    "week_number": 2,
    "week_start": "2025-09-07",
    "week_end": "2025-09-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.897Z",
    "updated_at": "2025-09-26T03:08:55.897Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1199,
  "fields": {
    "user_profile": 43,
    "week_number": 3,
    "week_start": "2025-09-14",
    "week_end": "2025-09-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.898Z",
    "updated_at": "2025-09-26T03:08:55.898Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1200,
  "fields": {
    "user_profile": 43,
    "week_number": 4,
    "week_start": "2025-09-21",
    "week_end": "2025-09-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.900Z",
    "updated_at": "2025-09-26T03:08:55.900Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1201,
  "fields": {
    "user_profile": 43,
    "week_number": 5,
    "week_start": "2025-09-28",
    "week_end": "2025-10-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.901Z",
    "updated_at": "2025-09-26T03:08:55.901Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1202,
  "fields": {
    "user_profile": 43,
    "week_number": 6,
    "week_start": "2025-10-05",
    "week_end": "2025-10-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.902Z",
    "updated_at": "2025-09-26T03:08:55.902Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1203,
  "fields": {
    "user_profile": 43,
    "week_number": 7,
    "week_start": "2025-10-12",
    "week_end": "2025-10-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.904Z",
    "updated_at": "2025-09-26T03:08:55.904Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1204,
  "fields": {
    "user_profile": 43,
    "week_number": 8,
    "week_start": "2025-10-19",
    "week_end": "2025-10-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.905Z",
    "updated_at": "2025-09-26T03:08:55.905Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1205,
  "fields": {
    "user_profile": 43,
    "week_number": 9,
    "week_start": "2025-10-26",
    "week_end": "2025-11-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.906Z",
    "updated_at": "2025-09-26T03:08:55.906Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1206,
  "fields": {
    "user_profile": 43,
    "week_number": 10,
    "week_start": "2025-11-02",
    "week_end": "2025-11-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.907Z",
    "updated_at": "2025-09-26T03:08:55.907Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1207,
  "fields": {
    "user_profile": 43,
    "week_number": 11,
    "week_start": "2025-11-09",
    "week_end": "2025-11-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.908Z",
    "updated_at": "2025-09-26T03:08:55.908Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1208,
  "fields": {
    "user_profile": 43,
    "week_number": 12,
    "week_start": "2025-11-16",
    "week_end": "2025-11-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.909Z",
    "updated_at": "2025-09-26T03:08:55.909Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1209,
  "fields": {
    "user_profile": 43,
    "week_number": 13,
    "week_start": "2025-11-23",
    "week_end": "2025-11-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.910Z",
    "updated_at": "2025-09-26T03:08:55.910Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1210,
  "fields": {
    "user_profile": 43,
    "week_number": 14,
    "week_start": "2025-11-30",
    "week_end": "2025-12-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.911Z",
    "updated_at": "2025-09-26T03:08:55.911Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1211,
  "fields": {
    "user_profile": 43,
    "week_number": 15,
    "week_start": "2025-12-07",
    "week_end": "2025-12-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.913Z",
    "updated_at": "2025-09-26T03:08:55.913Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1212,
  "fields": {
    "user_profile": 43,
    "week_number": 16,
    "week_start": "2025-12-14",
    "week_end": "2025-12-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.914Z",
    "updated_at": "2025-09-26T03:08:55.914Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1213,
  "fields": {
    "user_profile": 43,
    "week_number": 17,
    "week_start": "2025-12-21",
    "week_end": "2025-12-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.915Z",
    "updated_at": "2025-09-26T03:08:55.915Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1214,
  "fields": {
    "user_profile": 43,
    "week_number": 18,
    "week_start": "2025-12-28",
    "week_end": "2026-01-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.916Z",
    "updated_at": "2025-09-26T03:08:55.916Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1215,
  "fields": {
    "user_profile": 43,
    "week_number": 19,
    "week_start": "2026-01-04",
    "week_end": "2026-01-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.917Z",
    "updated_at": "2025-09-26T03:08:55.917Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1216,
  "fields": {
    "user_profile": 43,
    "week_number": 20,
    "week_start": "2026-01-11",
    "week_end": "2026-01-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.918Z",
    "updated_at": "2025-09-26T03:08:55.918Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1217,
  "fields": {
    "user_profile": 43,
    "week_number": 21,
    "week_start": "2026-01-18",
    "week_end": "2026-01-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.919Z",
    "updated_at": "2025-09-26T03:08:55.919Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1218,
  "fields": {
    "user_profile": 43,
    "week_number": 22,
    "week_start": "2026-01-25",
    "week_end": "2026-01-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.920Z",
    "updated_at": "2025-09-26T03:08:55.920Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1219,
  "fields": {
    "user_profile": 43,
    "week_number": 23,
    "week_start": "2026-02-01",
    "week_end": "2026-02-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.921Z",
    "updated_at": "2025-09-26T03:08:55.921Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1220,
  "fields": {
    "user_profile": 43,
    "week_number": 24,
    "week_start": "2026-02-08",
    "week_end": "2026-02-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.922Z",
    "updated_at": "2025-09-26T03:08:55.922Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1221,
  "fields": {
    "user_profile": 43,
    "week_number": 25,
    "week_start": "2026-02-15",
    "week_end": "2026-02-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.924Z",
    "updated_at": "2025-09-26T03:08:55.924Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1222,
  "fields": {
    "user_profile": 43,
    "week_number": 26,
    "week_start": "2026-02-22",
    "week_end": "2026-02-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.925Z",
    "updated_at": "2025-09-26T03:08:55.925Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1223,
  "fields": {
    "user_profile": 43,
    "week_number": 27,
    "week_start": "2026-03-01",
    "week_end": "2026-03-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.926Z",
    "updated_at": "2025-09-26T03:08:55.926Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1224,
  "fields": {
    "user_profile": 43,
    "week_number": 28,
    "week_start": "2026-03-08",
    "week_end": "2026-03-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.927Z",
    "updated_at": "2025-09-26T03:08:55.927Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1225,
  "fields": {
    "user_profile": 43,
    "week_number": 29,
    "week_start": "2026-03-15",
    "week_end": "2026-03-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.928Z",
    "updated_at": "2025-09-26T03:08:55.928Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1226,
  "fields": {
    "user_profile": 43,
    "week_number": 30,
    "week_start": "2026-03-22",
    "week_end": "2026-03-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.929Z",
    "updated_at": "2025-09-26T03:08:55.929Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1227,
  "fields": {
    "user_profile": 43,
    "week_number": 31,
    "week_start": "2026-03-29",
    "week_end": "2026-04-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.930Z",
    "updated_at": "2025-09-26T03:08:55.930Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1228,
  "fields": {
    "user_profile": 43,
    "week_number": 32,
    "week_start": "2026-04-05",
    "week_end": "2026-04-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.931Z",
    "updated_at": "2025-09-26T03:08:55.931Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1229,
  "fields": {
    "user_profile": 43,
    "week_number": 33,
    "week_start": "2026-04-12",
    "week_end": "2026-04-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.932Z",
    "updated_at": "2025-09-26T03:08:55.932Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1230,
  "fields": {
    "user_profile": 43,
    "week_number": 34,
    "week_start": "2026-04-19",
    "week_end": "2026-04-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.933Z",
    "updated_at": "2025-09-26T03:08:55.933Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1231,
  "fields": {
    "user_profile": 43,
    "week_number": 35,
    "week_start": "2026-04-26",
    "week_end": "2026-05-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.934Z",
    "updated_at": "2025-09-26T03:08:55.934Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1232,
  "fields": {
    "user_profile": 43,
    "week_number": 36,
    "week_start": "2026-05-03",
    "week_end": "2026-05-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.936Z",
    "updated_at": "2025-09-26T03:08:55.936Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1233,
  "fields": {
    "user_profile": 43,
    "week_number": 37,
    "week_start": "2026-05-10",
    "week_end": "2026-05-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.937Z",
    "updated_at": "2025-09-26T03:08:55.937Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1234,
  "fields": {
    "user_profile": 43,
    "week_number": 38,
    "week_start": "2026-05-17",
    "week_end": "2026-05-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.938Z",
    "updated_at": "2025-09-26T03:08:55.938Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1235,
  "fields": {
    "user_profile": 43,
    "week_number": 39,
    "week_start": "2026-05-24",
    "week_end": "2026-05-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.939Z",
    "updated_at": "2025-09-26T03:08:55.939Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1236,
  "fields": {
    "user_profile": 43,
    "week_number": 40,
    "week_start": "2026-05-31",
    "week_end": "2026-06-06",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.940Z",
    "updated_at": "2025-09-26T03:08:55.940Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1237,
  "fields": {
    "user_profile": 43,
    "week_number": 41,
    "week_start": "2026-06-07",
    "week_end": "2026-06-13",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.941Z",
    "updated_at": "2025-09-26T03:08:55.941Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1238,
  "fields": {
    "user_profile": 43,
    "week_number": 42,
    "week_start": "2026-06-14",
    "week_end": "2026-06-20",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.942Z",
    "updated_at": "2025-09-26T03:08:55.942Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1239,
  "fields": {
    "user_profile": 43,
    "week_number": 43,
    "week_start": "2026-06-21",
    "week_end": "2026-06-27",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.944Z",
    "updated_at": "2025-09-26T03:08:55.944Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1240,
  "fields": {
    "user_profile": 43,
    "week_number": 44,
    "week_start": "2026-06-28",
    "week_end": "2026-07-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.945Z",
    "updated_at": "2025-09-26T03:08:55.945Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1241,
  "fields": {
    "user_profile": 43,
    "week_number": 45,
    "week_start": "2026-07-05",
    "week_end": "2026-07-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.946Z",
    "updated_at": "2025-09-26T03:08:55.946Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1242,
  "fields": {
    "user_profile": 43,
    "week_number": 46,
    "week_start": "2026-07-12",
    "week_end": "2026-07-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.947Z",
    "updated_at": "2025-09-26T03:08:55.947Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1243,
  "fields": {
    "user_profile": 43,
    "week_number": 47,
    "week_start": "2026-07-19",
    "week_end": "2026-07-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.948Z",
    "updated_at": "2025-09-26T03:08:55.948Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1244,
  "fields": {
    "user_profile": 43,
    "week_number": 48,
    "week_start": "2026-07-26",
    "week_end": "2026-08-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.949Z",
    "updated_at": "2025-09-26T03:08:55.949Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1245,
  "fields": {
    "user_profile": 43,
    "week_number": 49,
    "week_start": "2026-08-02",
    "week_end": "2026-08-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.950Z",
    "updated_at": "2025-09-26T03:08:55.950Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1246,
  "fields": {
    "user_profile": 43,
    "week_number": 50,
    "week_start": "2026-08-09",
    "week_end": "2026-08-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.952Z",
    "updated_at": "2025-09-26T03:08:55.952Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1247,
  "fields": {
    "user_profile": 43,
    "week_number": 51,
    "week_start": "2026-08-16",
    "week_end": "2026-08-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.953Z",
    "updated_at": "2025-09-26T03:08:55.953Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1248,
  "fields": {
    "user_profile": 43,
    "week_number": 52,
    "week_start": "2026-08-23",
    "week_end": "2026-08-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-09-26T03:08:55.954Z",
    "updated_at": "2025-09-26T03:08:55.954Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1249,
  "fields": {
    "user_profile": 50,
    "week_number": 1,
    "week_start": "2024-09-01",
    "week_end": "2024-09-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.741Z",
    "updated_at": "2025-10-01T10:52:39.741Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1250,
  "fields": {
    "user_profile": 50,
    "week_number": 2,
    "week_start": "2024-09-08",
    "week_end": "2024-09-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.746Z",
    "updated_at": "2025-10-01T10:52:39.746Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1251,
  "fields": {
    "user_profile": 50,
    "week_number": 3,
    "week_start": "2024-09-15",
    "week_end": "2024-09-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.748Z",
    "updated_at": "2025-10-01T10:52:39.748Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1252,
  "fields": {
    "user_profile": 50,
    "week_number": 4,
    "week_start": "2024-09-22",
    "week_end": "2024-09-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.749Z",
    "updated_at": "2025-10-01T10:52:39.749Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1253,
  "fields": {
    "user_profile": 50,
    "week_number": 5,
    "week_start": "2024-09-29",
    "week_end": "2024-10-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.751Z",
    "updated_at": "2025-10-01T10:52:39.751Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1254,
  "fields": {
    "user_profile": 50,
    "week_number": 6,
    "week_start": "2024-10-06",
    "week_end": "2024-10-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.753Z",
    "updated_at": "2025-10-01T10:52:39.753Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1255,
  "fields": {
    "user_profile": 50,
    "week_number": 7,
    "week_start": "2024-10-13",
    "week_end": "2024-10-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.754Z",
    "updated_at": "2025-10-01T10:52:39.754Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1256,
  "fields": {
    "user_profile": 50,
    "week_number": 8,
    "week_start": "2024-10-20",
    "week_end": "2024-10-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.756Z",
    "updated_at": "2025-10-01T10:52:39.756Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1257,
  "fields": {
    "user_profile": 50,
    "week_number": 9,
    "week_start": "2024-10-27",
    "week_end": "2024-11-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.757Z",
    "updated_at": "2025-10-01T10:52:39.757Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1258,
  "fields": {
    "user_profile": 50,
    "week_number": 10,
    "week_start": "2024-11-03",
    "week_end": "2024-11-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.758Z",
    "updated_at": "2025-10-01T10:52:39.758Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1259,
  "fields": {
    "user_profile": 50,
    "week_number": 11,
    "week_start": "2024-11-10",
    "week_end": "2024-11-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.760Z",
    "updated_at": "2025-10-01T10:52:39.760Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1260,
  "fields": {
    "user_profile": 50,
    "week_number": 12,
    "week_start": "2024-11-17",
    "week_end": "2024-11-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.761Z",
    "updated_at": "2025-10-01T10:52:39.761Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1261,
  "fields": {
    "user_profile": 50,
    "week_number": 13,
    "week_start": "2024-11-24",
    "week_end": "2024-11-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.763Z",
    "updated_at": "2025-10-01T10:52:39.763Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1262,
  "fields": {
    "user_profile": 50,
    "week_number": 14,
    "week_start": "2024-12-01",
    "week_end": "2024-12-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.764Z",
    "updated_at": "2025-10-01T10:52:39.764Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1263,
  "fields": {
    "user_profile": 50,
    "week_number": 15,
    "week_start": "2024-12-08",
    "week_end": "2024-12-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.765Z",
    "updated_at": "2025-10-01T10:52:39.765Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1264,
  "fields": {
    "user_profile": 50,
    "week_number": 16,
    "week_start": "2024-12-15",
    "week_end": "2024-12-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.767Z",
    "updated_at": "2025-10-01T10:52:39.767Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1265,
  "fields": {
    "user_profile": 50,
    "week_number": 17,
    "week_start": "2024-12-22",
    "week_end": "2024-12-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.768Z",
    "updated_at": "2025-10-01T10:52:39.768Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1266,
  "fields": {
    "user_profile": 50,
    "week_number": 18,
    "week_start": "2024-12-29",
    "week_end": "2025-01-04",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.769Z",
    "updated_at": "2025-10-01T10:52:39.769Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1267,
  "fields": {
    "user_profile": 50,
    "week_number": 19,
    "week_start": "2025-01-05",
    "week_end": "2025-01-11",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.771Z",
    "updated_at": "2025-10-01T10:52:39.771Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1268,
  "fields": {
    "user_profile": 50,
    "week_number": 20,
    "week_start": "2025-01-12",
    "week_end": "2025-01-18",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.772Z",
    "updated_at": "2025-10-01T10:52:39.772Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1269,
  "fields": {
    "user_profile": 50,
    "week_number": 21,
    "week_start": "2025-01-19",
    "week_end": "2025-01-25",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.773Z",
    "updated_at": "2025-10-01T10:52:39.773Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1270,
  "fields": {
    "user_profile": 50,
    "week_number": 22,
    "week_start": "2025-01-26",
    "week_end": "2025-02-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.775Z",
    "updated_at": "2025-10-01T10:52:39.775Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1271,
  "fields": {
    "user_profile": 50,
    "week_number": 23,
    "week_start": "2025-02-02",
    "week_end": "2025-02-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.777Z",
    "updated_at": "2025-10-01T10:52:39.777Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1272,
  "fields": {
    "user_profile": 50,
    "week_number": 24,
    "week_start": "2025-02-09",
    "week_end": "2025-02-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.778Z",
    "updated_at": "2025-10-01T10:52:39.778Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1273,
  "fields": {
    "user_profile": 50,
    "week_number": 25,
    "week_start": "2025-02-16",
    "week_end": "2025-02-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.780Z",
    "updated_at": "2025-10-01T10:52:39.780Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1274,
  "fields": {
    "user_profile": 50,
    "week_number": 26,
    "week_start": "2025-02-23",
    "week_end": "2025-03-01",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.781Z",
    "updated_at": "2025-10-01T10:52:39.781Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1275,
  "fields": {
    "user_profile": 50,
    "week_number": 27,
    "week_start": "2025-03-02",
    "week_end": "2025-03-08",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.782Z",
    "updated_at": "2025-10-01T10:52:39.782Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1276,
  "fields": {
    "user_profile": 50,
    "week_number": 28,
    "week_start": "2025-03-09",
    "week_end": "2025-03-15",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.783Z",
    "updated_at": "2025-10-01T10:52:39.783Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1277,
  "fields": {
    "user_profile": 50,
    "week_number": 29,
    "week_start": "2025-03-16",
    "week_end": "2025-03-22",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.785Z",
    "updated_at": "2025-10-01T10:52:39.785Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1278,
  "fields": {
    "user_profile": 50,
    "week_number": 30,
    "week_start": "2025-03-23",
    "week_end": "2025-03-29",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.786Z",
    "updated_at": "2025-10-01T10:52:39.786Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1279,
  "fields": {
    "user_profile": 50,
    "week_number": 31,
    "week_start": "2025-03-30",
    "week_end": "2025-04-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.788Z",
    "updated_at": "2025-10-01T10:52:39.788Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1280,
  "fields": {
    "user_profile": 50,
    "week_number": 32,
    "week_start": "2025-04-06",
    "week_end": "2025-04-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.789Z",
    "updated_at": "2025-10-01T10:52:39.789Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1281,
  "fields": {
    "user_profile": 50,
    "week_number": 33,
    "week_start": "2025-04-13",
    "week_end": "2025-04-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.790Z",
    "updated_at": "2025-10-01T10:52:39.790Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1282,
  "fields": {
    "user_profile": 50,
    "week_number": 34,
    "week_start": "2025-04-20",
    "week_end": "2025-04-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.791Z",
    "updated_at": "2025-10-01T10:52:39.791Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1283,
  "fields": {
    "user_profile": 50,
    "week_number": 35,
    "week_start": "2025-04-27",
    "week_end": "2025-05-03",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.793Z",
    "updated_at": "2025-10-01T10:52:39.793Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1284,
  "fields": {
    "user_profile": 50,
    "week_number": 36,
    "week_start": "2025-05-04",
    "week_end": "2025-05-10",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.795Z",
    "updated_at": "2025-10-01T10:52:39.795Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1285,
  "fields": {
    "user_profile": 50,
    "week_number": 37,
    "week_start": "2025-05-11",
    "week_end": "2025-05-17",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.796Z",
    "updated_at": "2025-10-01T10:52:39.796Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1286,
  "fields": {
    "user_profile": 50,
    "week_number": 38,
    "week_start": "2025-05-18",
    "week_end": "2025-05-24",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.797Z",
    "updated_at": "2025-10-01T10:52:39.797Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1287,
  "fields": {
    "user_profile": 50,
    "week_number": 39,
    "week_start": "2025-05-25",
    "week_end": "2025-05-31",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.798Z",
    "updated_at": "2025-10-01T10:52:39.798Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1288,
  "fields": {
    "user_profile": 50,
    "week_number": 40,
    "week_start": "2025-06-01",
    "week_end": "2025-06-07",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.800Z",
    "updated_at": "2025-10-01T10:52:39.800Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1289,
  "fields": {
    "user_profile": 50,
    "week_number": 41,
    "week_start": "2025-06-08",
    "week_end": "2025-06-14",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.801Z",
    "updated_at": "2025-10-01T10:52:39.801Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1290,
  "fields": {
    "user_profile": 50,
    "week_number": 42,
    "week_start": "2025-06-15",
    "week_end": "2025-06-21",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.802Z",
    "updated_at": "2025-10-01T10:52:39.802Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1291,
  "fields": {
    "user_profile": 50,
    "week_number": 43,
    "week_start": "2025-06-22",
    "week_end": "2025-06-28",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.803Z",
    "updated_at": "2025-10-01T10:52:39.803Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1292,
  "fields": {
    "user_profile": 50,
    "week_number": 44,
    "week_start": "2025-06-29",
    "week_end": "2025-07-05",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.804Z",
    "updated_at": "2025-10-01T10:52:39.804Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1293,
  "fields": {
    "user_profile": 50,
    "week_number": 45,
    "week_start": "2025-07-06",
    "week_end": "2025-07-12",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.806Z",
    "updated_at": "2025-10-01T10:52:39.806Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1294,
  "fields": {
    "user_profile": 50,
    "week_number": 46,
    "week_start": "2025-07-13",
    "week_end": "2025-07-19",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.807Z",
    "updated_at": "2025-10-01T10:52:39.807Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1295,
  "fields": {
    "user_profile": 50,
    "week_number": 47,
    "week_start": "2025-07-20",
    "week_end": "2025-07-26",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.809Z",
    "updated_at": "2025-10-01T10:52:39.809Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1296,
  "fields": {
    "user_profile": 50,
    "week_number": 48,
    "week_start": "2025-07-27",
    "week_end": "2025-08-02",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.810Z",
    "updated_at": "2025-10-01T10:52:39.810Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1297,
  "fields": {
    "user_profile": 50,
    "week_number": 49,
    "week_start": "2025-08-03",
    "week_end": "2025-08-09",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.812Z",
    "updated_at": "2025-10-01T10:52:39.812Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1298,
  "fields": {
    "user_profile": 50,
    "week_number": 50,
    "week_start": "2025-08-10",
    "week_end": "2025-08-16",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.813Z",
    "updated_at": "2025-10-01T10:52:39.813Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1299,
  "fields": {
    "user_profile": 50,
    "week_number": 51,
    "week_start": "2025-08-17",
    "week_end": "2025-08-23",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.815Z",
    "updated_at": "2025-10-01T10:52:39.815Z"
  }
},
{
  "model": "internship_validation.weeklysummary",
  "pk": 1300,
  "fields": {
    "user_profile": 50,
    "week_number": 52,
    "week_start": "2025-08-24",
    "week_end": "2025-08-30",
    "dcc_hours": 0.0,
    "dcc_simulated_hours": 0.0,
    "cra_hours": 0.0,
    "pd_hours": 0.0,
    "supervision_hours": 0.0,
    "meets_weekly_minimum": false,
    "validation_errors": [],
    "created_at": "2025-10-01T10:52:39.816Z",
    "updated_at": "2025-10-01T10:52:39.816Z"
  }
},
{
  "model": "registrar_logbook.registrarcpdentry",
  "pk": 1,
  "fields": {
    "program": 1,
    "date": "2024-01-20",
    "provider": "Australian Psychological Society",
    "title": "Trauma-Informed Practice Workshop",
    "hours": "6.00",
    "is_active_cpd": true,
    "learning_goal": "Develop skills in trauma-informed assessment and intervention",
    "reflection": "Excellent workshop providing practical tools for working with trauma survivors.",
    "evidence_files": {},
    "created_at": "2025-09-30T04:51:26.477Z",
    "updated_at": "2025-09-30T04:51:26.477Z"
  }
},
{
  "model": "registrar_logbook.registrarcpdentry",
  "pk": 2,
  "fields": {
    "program": 1,
    "date": "2024-02-10",
    "provider": "Clinical Psychology Interest Group",
    "title": "Cognitive Behavioral Therapy Updates",
    "hours": "3.00",
    "is_active_cpd": true,
    "learning_goal": "Stay current with CBT research and techniques",
    "reflection": "Informative session on recent developments in CBT protocols.",
    "evidence_files": {},
    "created_at": "2025-09-30T04:51:26.479Z",
    "updated_at": "2025-09-30T04:51:26.479Z"
  }
},
{
  "model": "registrar_logbook.registrarcpdentry",
  "pk": 3,
  "fields": {
    "program": 1,
    "date": "2024-02-15",
    "provider": "Internal Training",
    "title": "Ethics and Professional Practice",
    "hours": "2.00",
    "is_active_cpd": false,
    "learning_goal": "Review ethical guidelines and professional standards",
    "reflection": "Important refresher on ethical decision-making frameworks.",
    "evidence_files": {},
    "created_at": "2025-09-30T04:51:26.480Z",
    "updated_at": "2025-09-30T04:51:26.480Z"
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 1,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "ASSESSMENT",
    "label": "Psychological Assessment",
    "description": "Conduct comprehensive psychological assessments including cognitive, personality, and diagnostic evaluations."
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 2,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "INTERVENTION",
    "label": "Psychological Intervention",
    "description": "Deliver evidence-based psychological interventions for various mental health conditions."
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 3,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "CONSULTATION",
    "label": "Consultation and Communication",
    "description": "Provide consultation to other professionals and communicate effectively with stakeholders."
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 4,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "RESEARCH",
    "label": "Research and Evaluation",
    "description": "Apply research skills to evaluate practice and contribute to knowledge base."
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 5,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "COMMUNICATION",
    "label": "Communication",
    "description": ""
  }
},
{
  "model": "registrar_logbook.competencyframework",
  "pk": 6,
  "fields": {
    "aope": "CLINICAL",
    "category_code": "PROFESSIONAL",
    "label": "Professional practice",
    "description": ""
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "add_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "change_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "delete_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view log entry",
    "content_type": [
      "admin",
      "logentry"
    ],
    "codename": "view_logentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "add_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "change_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "delete_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view permission",
    "content_type": [
      "auth",
      "permission"
    ],
    "codename": "view_permission"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "add_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "change_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "delete_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view group",
    "content_type": [
      "auth",
      "group"
    ],
    "codename": "view_group"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add user",
    "content_type": [
      "auth",
      "user"
    ],
    "codename": "add_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change user",
    "content_type": [
      "auth",
      "user"
    ],
    "codename": "change_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete user",
    "content_type": [
      "auth",
      "user"
    ],
    "codename": "delete_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view user",
    "content_type": [
      "auth",
      "user"
    ],
    "codename": "view_user"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "add_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "change_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "delete_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view content type",
    "content_type": [
      "contenttypes",
      "contenttype"
    ],
    "codename": "view_contenttype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "add_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "change_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "delete_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view session",
    "content_type": [
      "sessions",
      "session"
    ],
    "codename": "view_session"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add epa",
    "content_type": [
      "api",
      "epa"
    ],
    "codename": "add_epa"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change epa",
    "content_type": [
      "api",
      "epa"
    ],
    "codename": "change_epa"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete epa",
    "content_type": [
      "api",
      "epa"
    ],
    "codename": "delete_epa"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view epa",
    "content_type": [
      "api",
      "epa"
    ],
    "codename": "view_epa"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add milestone",
    "content_type": [
      "api",
      "milestone"
    ],
    "codename": "add_milestone"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change milestone",
    "content_type": [
      "api",
      "milestone"
    ],
    "codename": "change_milestone"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete milestone",
    "content_type": [
      "api",
      "milestone"
    ],
    "codename": "delete_milestone"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view milestone",
    "content_type": [
      "api",
      "milestone"
    ],
    "codename": "view_milestone"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add reflection",
    "content_type": [
      "api",
      "reflection"
    ],
    "codename": "add_reflection"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change reflection",
    "content_type": [
      "api",
      "reflection"
    ],
    "codename": "change_reflection"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete reflection",
    "content_type": [
      "api",
      "reflection"
    ],
    "codename": "delete_reflection"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view reflection",
    "content_type": [
      "api",
      "reflection"
    ],
    "codename": "view_reflection"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add user profile",
    "content_type": [
      "api",
      "userprofile"
    ],
    "codename": "add_userprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change user profile",
    "content_type": [
      "api",
      "userprofile"
    ],
    "codename": "change_userprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete user profile",
    "content_type": [
      "api",
      "userprofile"
    ],
    "codename": "delete_userprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view user profile",
    "content_type": [
      "api",
      "userprofile"
    ],
    "codename": "view_userprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add organization",
    "content_type": [
      "api",
      "organization"
    ],
    "codename": "add_organization"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change organization",
    "content_type": [
      "api",
      "organization"
    ],
    "codename": "change_organization"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete organization",
    "content_type": [
      "api",
      "organization"
    ],
    "codename": "delete_organization"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view organization",
    "content_type": [
      "api",
      "organization"
    ],
    "codename": "view_organization"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add milestone progress",
    "content_type": [
      "api",
      "milestoneprogress"
    ],
    "codename": "add_milestoneprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change milestone progress",
    "content_type": [
      "api",
      "milestoneprogress"
    ],
    "codename": "change_milestoneprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete milestone progress",
    "content_type": [
      "api",
      "milestoneprogress"
    ],
    "codename": "delete_milestoneprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view milestone progress",
    "content_type": [
      "api",
      "milestoneprogress"
    ],
    "codename": "view_milestoneprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add email verification code",
    "content_type": [
      "api",
      "emailverificationcode"
    ],
    "codename": "add_emailverificationcode"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change email verification code",
    "content_type": [
      "api",
      "emailverificationcode"
    ],
    "codename": "change_emailverificationcode"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete email verification code",
    "content_type": [
      "api",
      "emailverificationcode"
    ],
    "codename": "delete_emailverificationcode"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view email verification code",
    "content_type": [
      "api",
      "emailverificationcode"
    ],
    "codename": "view_emailverificationcode"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervision",
    "content_type": [
      "api",
      "supervision"
    ],
    "codename": "add_supervision"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervision",
    "content_type": [
      "api",
      "supervision"
    ],
    "codename": "change_supervision"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervision",
    "content_type": [
      "api",
      "supervision"
    ],
    "codename": "delete_supervision"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervision",
    "content_type": [
      "api",
      "supervision"
    ],
    "codename": "view_supervision"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add weekly logbook",
    "content_type": [
      "logbook_app",
      "weeklylogbook"
    ],
    "codename": "add_weeklylogbook"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change weekly logbook",
    "content_type": [
      "logbook_app",
      "weeklylogbook"
    ],
    "codename": "change_weeklylogbook"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete weekly logbook",
    "content_type": [
      "logbook_app",
      "weeklylogbook"
    ],
    "codename": "delete_weeklylogbook"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view weekly logbook",
    "content_type": [
      "logbook_app",
      "weeklylogbook"
    ],
    "codename": "view_weeklylogbook"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add logbook audit log",
    "content_type": [
      "logbook_app",
      "logbookauditlog"
    ],
    "codename": "add_logbookauditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change logbook audit log",
    "content_type": [
      "logbook_app",
      "logbookauditlog"
    ],
    "codename": "change_logbookauditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete logbook audit log",
    "content_type": [
      "logbook_app",
      "logbookauditlog"
    ],
    "codename": "delete_logbookauditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view logbook audit log",
    "content_type": [
      "logbook_app",
      "logbookauditlog"
    ],
    "codename": "view_logbookauditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add cra entry",
    "content_type": [
      "logbook_app",
      "craentry"
    ],
    "codename": "add_craentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change cra entry",
    "content_type": [
      "logbook_app",
      "craentry"
    ],
    "codename": "change_craentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete cra entry",
    "content_type": [
      "logbook_app",
      "craentry"
    ],
    "codename": "delete_craentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view cra entry",
    "content_type": [
      "logbook_app",
      "craentry"
    ],
    "codename": "view_craentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add dcc entry",
    "content_type": [
      "logbook_app",
      "dccentry"
    ],
    "codename": "add_dccentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change dcc entry",
    "content_type": [
      "logbook_app",
      "dccentry"
    ],
    "codename": "change_dccentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete dcc entry",
    "content_type": [
      "logbook_app",
      "dccentry"
    ],
    "codename": "delete_dccentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view dcc entry",
    "content_type": [
      "logbook_app",
      "dccentry"
    ],
    "codename": "view_dccentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add pd entry",
    "content_type": [
      "logbook_app",
      "pdentry"
    ],
    "codename": "add_pdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change pd entry",
    "content_type": [
      "logbook_app",
      "pdentry"
    ],
    "codename": "change_pdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete pd entry",
    "content_type": [
      "logbook_app",
      "pdentry"
    ],
    "codename": "delete_pdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view pd entry",
    "content_type": [
      "logbook_app",
      "pdentry"
    ],
    "codename": "view_pdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add sup entry",
    "content_type": [
      "logbook_app",
      "supentry"
    ],
    "codename": "add_supentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change sup entry",
    "content_type": [
      "logbook_app",
      "supentry"
    ],
    "codename": "change_supentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete sup entry",
    "content_type": [
      "logbook_app",
      "supentry"
    ],
    "codename": "delete_supentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view sup entry",
    "content_type": [
      "logbook_app",
      "supentry"
    ],
    "codename": "view_supentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Section A Entry",
    "content_type": [
      "section_a",
      "sectionaentry"
    ],
    "codename": "add_sectionaentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Section A Entry",
    "content_type": [
      "section_a",
      "sectionaentry"
    ],
    "codename": "change_sectionaentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Section A Entry",
    "content_type": [
      "section_a",
      "sectionaentry"
    ],
    "codename": "delete_sectionaentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Section A Entry",
    "content_type": [
      "section_a",
      "sectionaentry"
    ],
    "codename": "view_sectionaentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add custom session activity type",
    "content_type": [
      "section_a",
      "customsessionactivitytype"
    ],
    "codename": "add_customsessionactivitytype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change custom session activity type",
    "content_type": [
      "section_a",
      "customsessionactivitytype"
    ],
    "codename": "change_customsessionactivitytype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete custom session activity type",
    "content_type": [
      "section_a",
      "customsessionactivitytype"
    ],
    "codename": "delete_customsessionactivitytype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view custom session activity type",
    "content_type": [
      "section_a",
      "customsessionactivitytype"
    ],
    "codename": "view_customsessionactivitytype"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add PD Competency",
    "content_type": [
      "section_b",
      "pdcompetency"
    ],
    "codename": "add_pdcompetency"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change PD Competency",
    "content_type": [
      "section_b",
      "pdcompetency"
    ],
    "codename": "change_pdcompetency"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete PD Competency",
    "content_type": [
      "section_b",
      "pdcompetency"
    ],
    "codename": "delete_pdcompetency"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view PD Competency",
    "content_type": [
      "section_b",
      "pdcompetency"
    ],
    "codename": "view_pdcompetency"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Professional Development Entry",
    "content_type": [
      "section_b",
      "professionaldevelopmententry"
    ],
    "codename": "add_professionaldevelopmententry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Professional Development Entry",
    "content_type": [
      "section_b",
      "professionaldevelopmententry"
    ],
    "codename": "change_professionaldevelopmententry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Professional Development Entry",
    "content_type": [
      "section_b",
      "professionaldevelopmententry"
    ],
    "codename": "delete_professionaldevelopmententry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Professional Development Entry",
    "content_type": [
      "section_b",
      "professionaldevelopmententry"
    ],
    "codename": "view_professionaldevelopmententry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add PD Weekly Summary",
    "content_type": [
      "section_b",
      "pdweeklysummary"
    ],
    "codename": "add_pdweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change PD Weekly Summary",
    "content_type": [
      "section_b",
      "pdweeklysummary"
    ],
    "codename": "change_pdweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete PD Weekly Summary",
    "content_type": [
      "section_b",
      "pdweeklysummary"
    ],
    "codename": "delete_pdweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view PD Weekly Summary",
    "content_type": [
      "section_b",
      "pdweeklysummary"
    ],
    "codename": "view_pdweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Supervision Entry",
    "content_type": [
      "section_c",
      "supervisionentry"
    ],
    "codename": "add_supervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Supervision Entry",
    "content_type": [
      "section_c",
      "supervisionentry"
    ],
    "codename": "change_supervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Supervision Entry",
    "content_type": [
      "section_c",
      "supervisionentry"
    ],
    "codename": "delete_supervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Supervision Entry",
    "content_type": [
      "section_c",
      "supervisionentry"
    ],
    "codename": "view_supervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add Supervision Weekly Summary",
    "content_type": [
      "section_c",
      "supervisionweeklysummary"
    ],
    "codename": "add_supervisionweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change Supervision Weekly Summary",
    "content_type": [
      "section_c",
      "supervisionweeklysummary"
    ],
    "codename": "change_supervisionweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete Supervision Weekly Summary",
    "content_type": [
      "section_c",
      "supervisionweeklysummary"
    ],
    "codename": "delete_supervisionweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view Supervision Weekly Summary",
    "content_type": [
      "section_c",
      "supervisionweeklysummary"
    ],
    "codename": "view_supervisionweeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add support ticket",
    "content_type": [
      "support",
      "supportticket"
    ],
    "codename": "add_supportticket"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change support ticket",
    "content_type": [
      "support",
      "supportticket"
    ],
    "codename": "change_supportticket"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete support ticket",
    "content_type": [
      "support",
      "supportticket"
    ],
    "codename": "delete_supportticket"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view support ticket",
    "content_type": [
      "support",
      "supportticket"
    ],
    "codename": "view_supportticket"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add support message",
    "content_type": [
      "support",
      "supportmessage"
    ],
    "codename": "add_supportmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change support message",
    "content_type": [
      "support",
      "supportmessage"
    ],
    "codename": "change_supportmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete support message",
    "content_type": [
      "support",
      "supportmessage"
    ],
    "codename": "delete_supportmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view support message",
    "content_type": [
      "support",
      "supportmessage"
    ],
    "codename": "view_supportmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add support user",
    "content_type": [
      "support",
      "supportuser"
    ],
    "codename": "add_supportuser"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change support user",
    "content_type": [
      "support",
      "supportuser"
    ],
    "codename": "change_supportuser"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete support user",
    "content_type": [
      "support",
      "supportuser"
    ],
    "codename": "delete_supportuser"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view support user",
    "content_type": [
      "support",
      "supportuser"
    ],
    "codename": "view_supportuser"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add system alert",
    "content_type": [
      "support",
      "systemalert"
    ],
    "codename": "add_systemalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change system alert",
    "content_type": [
      "support",
      "systemalert"
    ],
    "codename": "change_systemalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete system alert",
    "content_type": [
      "support",
      "systemalert"
    ],
    "codename": "delete_systemalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view system alert",
    "content_type": [
      "support",
      "systemalert"
    ],
    "codename": "view_systemalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add user activity",
    "content_type": [
      "support",
      "useractivity"
    ],
    "codename": "add_useractivity"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change user activity",
    "content_type": [
      "support",
      "useractivity"
    ],
    "codename": "change_useractivity"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete user activity",
    "content_type": [
      "support",
      "useractivity"
    ],
    "codename": "delete_useractivity"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view user activity",
    "content_type": [
      "support",
      "useractivity"
    ],
    "codename": "view_useractivity"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add weekly stats",
    "content_type": [
      "support",
      "weeklystats"
    ],
    "codename": "add_weeklystats"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change weekly stats",
    "content_type": [
      "support",
      "weeklystats"
    ],
    "codename": "change_weeklystats"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete weekly stats",
    "content_type": [
      "support",
      "weeklystats"
    ],
    "codename": "delete_weeklystats"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view weekly stats",
    "content_type": [
      "support",
      "weeklystats"
    ],
    "codename": "view_weeklystats"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add internship program",
    "content_type": [
      "internship_validation",
      "internshipprogram"
    ],
    "codename": "add_internshipprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change internship program",
    "content_type": [
      "internship_validation",
      "internshipprogram"
    ],
    "codename": "change_internshipprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete internship program",
    "content_type": [
      "internship_validation",
      "internshipprogram"
    ],
    "codename": "delete_internshipprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view internship program",
    "content_type": [
      "internship_validation",
      "internshipprogram"
    ],
    "codename": "view_internshipprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add internship progress",
    "content_type": [
      "internship_validation",
      "internshipprogress"
    ],
    "codename": "add_internshipprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change internship progress",
    "content_type": [
      "internship_validation",
      "internshipprogress"
    ],
    "codename": "change_internshipprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete internship progress",
    "content_type": [
      "internship_validation",
      "internshipprogress"
    ],
    "codename": "delete_internshipprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view internship progress",
    "content_type": [
      "internship_validation",
      "internshipprogress"
    ],
    "codename": "view_internshipprogress"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add validation alert",
    "content_type": [
      "internship_validation",
      "validationalert"
    ],
    "codename": "add_validationalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change validation alert",
    "content_type": [
      "internship_validation",
      "validationalert"
    ],
    "codename": "change_validationalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete validation alert",
    "content_type": [
      "internship_validation",
      "validationalert"
    ],
    "codename": "delete_validationalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view validation alert",
    "content_type": [
      "internship_validation",
      "validationalert"
    ],
    "codename": "view_validationalert"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add weekly summary",
    "content_type": [
      "internship_validation",
      "weeklysummary"
    ],
    "codename": "add_weeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change weekly summary",
    "content_type": [
      "internship_validation",
      "weeklysummary"
    ],
    "codename": "change_weeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete weekly summary",
    "content_type": [
      "internship_validation",
      "weeklysummary"
    ],
    "codename": "delete_weeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view weekly summary",
    "content_type": [
      "internship_validation",
      "weeklysummary"
    ],
    "codename": "view_weeklysummary"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add message",
    "content_type": [
      "api",
      "message"
    ],
    "codename": "add_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change message",
    "content_type": [
      "api",
      "message"
    ],
    "codename": "change_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete message",
    "content_type": [
      "api",
      "message"
    ],
    "codename": "delete_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view message",
    "content_type": [
      "api",
      "message"
    ],
    "codename": "view_message"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervisor request",
    "content_type": [
      "api",
      "supervisorrequest"
    ],
    "codename": "add_supervisorrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervisor request",
    "content_type": [
      "api",
      "supervisorrequest"
    ],
    "codename": "change_supervisorrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervisor request",
    "content_type": [
      "api",
      "supervisorrequest"
    ],
    "codename": "delete_supervisorrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervisor request",
    "content_type": [
      "api",
      "supervisorrequest"
    ],
    "codename": "view_supervisorrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervisor invitation",
    "content_type": [
      "api",
      "supervisorinvitation"
    ],
    "codename": "add_supervisorinvitation"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervisor invitation",
    "content_type": [
      "api",
      "supervisorinvitation"
    ],
    "codename": "change_supervisorinvitation"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervisor invitation",
    "content_type": [
      "api",
      "supervisorinvitation"
    ],
    "codename": "delete_supervisorinvitation"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervisor invitation",
    "content_type": [
      "api",
      "supervisorinvitation"
    ],
    "codename": "view_supervisorinvitation"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervisor endorsement",
    "content_type": [
      "api",
      "supervisorendorsement"
    ],
    "codename": "add_supervisorendorsement"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervisor endorsement",
    "content_type": [
      "api",
      "supervisorendorsement"
    ],
    "codename": "change_supervisorendorsement"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervisor endorsement",
    "content_type": [
      "api",
      "supervisorendorsement"
    ],
    "codename": "delete_supervisorendorsement"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervisor endorsement",
    "content_type": [
      "api",
      "supervisorendorsement"
    ],
    "codename": "view_supervisorendorsement"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervision notification",
    "content_type": [
      "api",
      "supervisionnotification"
    ],
    "codename": "add_supervisionnotification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervision notification",
    "content_type": [
      "api",
      "supervisionnotification"
    ],
    "codename": "change_supervisionnotification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervision notification",
    "content_type": [
      "api",
      "supervisionnotification"
    ],
    "codename": "delete_supervisionnotification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervision notification",
    "content_type": [
      "api",
      "supervisionnotification"
    ],
    "codename": "view_supervisionnotification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add logbook message",
    "content_type": [
      "logbook_app",
      "logbookmessage"
    ],
    "codename": "add_logbookmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change logbook message",
    "content_type": [
      "logbook_app",
      "logbookmessage"
    ],
    "codename": "change_logbookmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete logbook message",
    "content_type": [
      "logbook_app",
      "logbookmessage"
    ],
    "codename": "delete_logbookmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view logbook message",
    "content_type": [
      "logbook_app",
      "logbookmessage"
    ],
    "codename": "view_logbookmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add comment thread",
    "content_type": [
      "logbook_app",
      "commentthread"
    ],
    "codename": "add_commentthread"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change comment thread",
    "content_type": [
      "logbook_app",
      "commentthread"
    ],
    "codename": "change_commentthread"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete comment thread",
    "content_type": [
      "logbook_app",
      "commentthread"
    ],
    "codename": "delete_commentthread"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view comment thread",
    "content_type": [
      "logbook_app",
      "commentthread"
    ],
    "codename": "view_commentthread"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add comment message",
    "content_type": [
      "logbook_app",
      "commentmessage"
    ],
    "codename": "add_commentmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change comment message",
    "content_type": [
      "logbook_app",
      "commentmessage"
    ],
    "codename": "change_commentmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete comment message",
    "content_type": [
      "logbook_app",
      "commentmessage"
    ],
    "codename": "delete_commentmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view comment message",
    "content_type": [
      "logbook_app",
      "commentmessage"
    ],
    "codename": "view_commentmessage"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add unlock request",
    "content_type": [
      "logbook_app",
      "unlockrequest"
    ],
    "codename": "add_unlockrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change unlock request",
    "content_type": [
      "logbook_app",
      "unlockrequest"
    ],
    "codename": "change_unlockrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete unlock request",
    "content_type": [
      "logbook_app",
      "unlockrequest"
    ],
    "codename": "delete_unlockrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view unlock request",
    "content_type": [
      "logbook_app",
      "unlockrequest"
    ],
    "codename": "view_unlockrequest"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add notification",
    "content_type": [
      "logbook_app",
      "notification"
    ],
    "codename": "add_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change notification",
    "content_type": [
      "logbook_app",
      "notification"
    ],
    "codename": "change_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete notification",
    "content_type": [
      "logbook_app",
      "notification"
    ],
    "codename": "delete_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view notification",
    "content_type": [
      "logbook_app",
      "notification"
    ],
    "codename": "view_notification"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervision assignment",
    "content_type": [
      "api",
      "supervisionassignment"
    ],
    "codename": "add_supervisionassignment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervision assignment",
    "content_type": [
      "api",
      "supervisionassignment"
    ],
    "codename": "change_supervisionassignment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervision assignment",
    "content_type": [
      "api",
      "supervisionassignment"
    ],
    "codename": "delete_supervisionassignment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervision assignment",
    "content_type": [
      "api",
      "supervisionassignment"
    ],
    "codename": "view_supervisionassignment"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add meeting invite",
    "content_type": [
      "api",
      "meetinginvite"
    ],
    "codename": "add_meetinginvite"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change meeting invite",
    "content_type": [
      "api",
      "meetinginvite"
    ],
    "codename": "change_meetinginvite"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete meeting invite",
    "content_type": [
      "api",
      "meetinginvite"
    ],
    "codename": "delete_meetinginvite"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view meeting invite",
    "content_type": [
      "api",
      "meetinginvite"
    ],
    "codename": "view_meetinginvite"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add meeting",
    "content_type": [
      "api",
      "meeting"
    ],
    "codename": "add_meeting"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change meeting",
    "content_type": [
      "api",
      "meeting"
    ],
    "codename": "change_meeting"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete meeting",
    "content_type": [
      "api",
      "meeting"
    ],
    "codename": "delete_meeting"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view meeting",
    "content_type": [
      "api",
      "meeting"
    ],
    "codename": "view_meeting"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add competency framework",
    "content_type": [
      "registrar_logbook",
      "competencyframework"
    ],
    "codename": "add_competencyframework"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change competency framework",
    "content_type": [
      "registrar_logbook",
      "competencyframework"
    ],
    "codename": "change_competencyframework"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete competency framework",
    "content_type": [
      "registrar_logbook",
      "competencyframework"
    ],
    "codename": "delete_competencyframework"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view competency framework",
    "content_type": [
      "registrar_logbook",
      "competencyframework"
    ],
    "codename": "view_competencyframework"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add registrar program",
    "content_type": [
      "registrar_logbook",
      "registrarprogram"
    ],
    "codename": "add_registrarprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change registrar program",
    "content_type": [
      "registrar_logbook",
      "registrarprogram"
    ],
    "codename": "change_registrarprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete registrar program",
    "content_type": [
      "registrar_logbook",
      "registrarprogram"
    ],
    "codename": "delete_registrarprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view registrar program",
    "content_type": [
      "registrar_logbook",
      "registrarprogram"
    ],
    "codename": "view_registrarprogram"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add registrar supervision entry",
    "content_type": [
      "registrar_logbook",
      "registrarsupervisionentry"
    ],
    "codename": "add_registrarsupervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change registrar supervision entry",
    "content_type": [
      "registrar_logbook",
      "registrarsupervisionentry"
    ],
    "codename": "change_registrarsupervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete registrar supervision entry",
    "content_type": [
      "registrar_logbook",
      "registrarsupervisionentry"
    ],
    "codename": "delete_registrarsupervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view registrar supervision entry",
    "content_type": [
      "registrar_logbook",
      "registrarsupervisionentry"
    ],
    "codename": "view_registrarsupervisionentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add supervisor profile",
    "content_type": [
      "registrar_logbook",
      "supervisorprofile"
    ],
    "codename": "add_supervisorprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change supervisor profile",
    "content_type": [
      "registrar_logbook",
      "supervisorprofile"
    ],
    "codename": "change_supervisorprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete supervisor profile",
    "content_type": [
      "registrar_logbook",
      "supervisorprofile"
    ],
    "codename": "delete_supervisorprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view supervisor profile",
    "content_type": [
      "registrar_logbook",
      "supervisorprofile"
    ],
    "codename": "view_supervisorprofile"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add audit log",
    "content_type": [
      "registrar_logbook",
      "auditlog"
    ],
    "codename": "add_auditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change audit log",
    "content_type": [
      "registrar_logbook",
      "auditlog"
    ],
    "codename": "change_auditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete audit log",
    "content_type": [
      "registrar_logbook",
      "auditlog"
    ],
    "codename": "delete_auditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view audit log",
    "content_type": [
      "registrar_logbook",
      "auditlog"
    ],
    "codename": "view_auditlog"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add progress snapshot",
    "content_type": [
      "registrar_logbook",
      "progresssnapshot"
    ],
    "codename": "add_progresssnapshot"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change progress snapshot",
    "content_type": [
      "registrar_logbook",
      "progresssnapshot"
    ],
    "codename": "change_progresssnapshot"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete progress snapshot",
    "content_type": [
      "registrar_logbook",
      "progresssnapshot"
    ],
    "codename": "delete_progresssnapshot"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view progress snapshot",
    "content_type": [
      "registrar_logbook",
      "progresssnapshot"
    ],
    "codename": "view_progresssnapshot"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add registrar cpd entry",
    "content_type": [
      "registrar_logbook",
      "registrarcpdentry"
    ],
    "codename": "add_registrarcpdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change registrar cpd entry",
    "content_type": [
      "registrar_logbook",
      "registrarcpdentry"
    ],
    "codename": "change_registrarcpdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete registrar cpd entry",
    "content_type": [
      "registrar_logbook",
      "registrarcpdentry"
    ],
    "codename": "delete_registrarcpdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view registrar cpd entry",
    "content_type": [
      "registrar_logbook",
      "registrarcpdentry"
    ],
    "codename": "view_registrarcpdentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can add registrar practice entry",
    "content_type": [
      "registrar_logbook",
      "registrarpracticeentry"
    ],
    "codename": "add_registrarpracticeentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can change registrar practice entry",
    "content_type": [
      "registrar_logbook",
      "registrarpracticeentry"
    ],
    "codename": "change_registrarpracticeentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can delete registrar practice entry",
    "content_type": [
      "registrar_logbook",
      "registrarpracticeentry"
    ],
    "codename": "delete_registrarpracticeentry"
  }
},
{
  "model": "auth.permission",
  "fields": {
    "name": "Can view registrar practice entry",
    "content_type": [
      "registrar_logbook",
      "registrarpracticeentry"
    ],
    "codename": "view_registrarpracticeentry"
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$TVdERXlhRXJRNXhmQ1kzMmc0NHBSeQ$HZTLY4TICX3slZK/oN4esk6IgUnBnVE5HCHBiUrxOPw",
    "last_login": null,
    "is_superuser": false,
    "username": "supervisor@demo.test",
    "first_name": "",
    "last_name": "",
    "email": "supervisor@demo.test",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T06:30:10.301Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$Z2lrWDdyYkk5akR1MVQ1cUxyRjZJRw$MkhhJb4O3Pk7/5Al3wXaVg3poIIJNKosEdCilUXHKqE",
    "last_login": "2025-10-02T05:33:06.356Z",
    "is_superuser": false,
    "username": "intern@demo.test",
    "first_name": "",
    "last_name": "",
    "email": "intern@demo.test",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T06:30:26.727Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$YlR4b2Vhem1RSE1LdjFSZ3FHWHZLTA$JpFmam2U93AyY1GTt4TFuVoy37jwqV0TxAPiDR2W+9Y",
    "last_login": null,
    "is_superuser": false,
    "username": "registrar@demo.test",
    "first_name": "",
    "last_name": "",
    "email": "registrar@demo.test",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T06:31:05.213Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$eW5MNUpUOGJzY2xqdG56UlhUZ3JHSw$V6ENTZerNC9NfCtUo7FoskYEtjxOOvLPCD//Yc2ANsA",
    "last_login": null,
    "is_superuser": false,
    "username": "admin@demo.test",
    "first_name": "",
    "last_name": "",
    "email": "admin@demo.test",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T06:31:05.427Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$aXVNUVJKclFGalhxdzN0V2ZlUlRqbQ$6AwjEsjBSn54jAiU0sSAs7aAqDOvJhfbsa/iBQUgGuQ",
    "last_login": null,
    "is_superuser": false,
    "username": "test.supervisor@example.com",
    "first_name": "Test",
    "last_name": "Supervisor",
    "email": "test.supervisor@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T23:35:53.174Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$YjZvOWF0R0RPeFBYazJPRFhFT3lXZQ$B73m76jUn6FYpBXe1t7KdrZKsTjJ41svhnS7dxwfUTI",
    "last_login": null,
    "is_superuser": false,
    "username": "test.provisional@example.com",
    "first_name": "Test",
    "last_name": "Provisional",
    "email": "test.provisional@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T23:43:43.090Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$NGpRcWhrRDV4VFhYRmJ0eWNJNWZLZw$23dfNTp6fZEpWzPcw4iCQn/SGKrXf8FKflP2wsAP0us",
    "last_login": null,
    "is_superuser": false,
    "username": "new.provisional@example.com",
    "first_name": "New",
    "last_name": "Provisional",
    "email": "new.provisional@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T23:44:32.922Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$NjgyR0ZrV1AyM2Z3RlQ5dEx0UmdQOQ$8ylt3qK2s1On7S6IyvPaLhvEGA+VfsDOlPf87CVqMi0",
    "last_login": null,
    "is_superuser": false,
    "username": "test.cleanup@example.com",
    "first_name": "Test",
    "last_name": "Cleanup",
    "email": "test.cleanup@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T23:49:08.083Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$RTJtajRzbndBOU5DSU1RQnoyTUNjYQ$ivYqKqduNJNWoMfpiy8Lq5QDegxBfG6A3xYWKuzPc9o",
    "last_login": null,
    "is_superuser": false,
    "username": "test.new.user@example.com",
    "first_name": "Test",
    "last_name": "User",
    "email": "test.new.user@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-20T23:54:55.990Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$UVNaWHFRWUFuaDFtN3ZxczB0cm9hUA$c4mIe9r/AEljtLOureXo/TBk7Ce+wyDg5uij9L9urUE",
    "last_login": null,
    "is_superuser": false,
    "username": "test.redirect@example.com",
    "first_name": "Test",
    "last_name": "Redirect",
    "email": "test.redirect@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-21T00:01:53.081Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$eUhETXg4YXc1V1BsVEtjV1lwZDNQZA$KSPzh1JvWAz5oRrbxtxFeVaiVF1Xan4yWRQDGru7ZBk",
    "last_login": null,
    "is_superuser": false,
    "username": "supervisor.demo@cymp.com.au",
    "first_name": "Brett",
    "last_name": "Mackie",
    "email": "supervisor.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-21T01:49:02.607Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$UGJ1WUdiNG81aWh6MWFuMFlOTkhsMQ$Mq46AGcs6cKzQMuS4KDnKVgSK8EFOf7I/9eZuNj44Dw",
    "last_login": "2025-09-30T21:42:55.371Z",
    "is_superuser": true,
    "username": "admin",
    "first_name": "",
    "last_name": "",
    "email": "admin@psychpath.com.au",
    "is_staff": true,
    "is_active": true,
    "date_joined": "2025-09-21T05:28:34.365Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$QmJuU0VGV1R4R2xaa2VBcGJKRlQ0VQ$rIIoRQ1lpo+Ih4gO3ze4PLgTX14XNsJryKxNflqGBqM",
    "last_login": null,
    "is_superuser": false,
    "username": "intern1.demo@cymp.com.au",
    "first_name": "Phil",
    "last_name": "O'Brien",
    "email": "intern1.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-21T21:09:56.706Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$eEJpSU9VaVZKaGpUWEl0NWwwZlVxbA$VcmfEOaY+AnUsTdnVsqLv6NC9gVgQkrmi816znCRvmI",
    "last_login": null,
    "is_superuser": false,
    "username": "registrar1.demo@cymp.com.au",
    "first_name": "Registrar",
    "last_name": "One",
    "email": "registrar1.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-21T21:48:02.577Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$Wm1oMzVRemJwZUpkbkdiSmdpeXBYVQ$OmYnLdfq+LQP22McaCRtDS+EQv1b9IPck+0AIllUI5U",
    "last_login": null,
    "is_superuser": false,
    "username": "registrar.demo@cymp.com.au",
    "first_name": "",
    "last_name": "",
    "email": "registrar.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-21T23:25:13.809Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$R1UyQ3VEVVpncnh1MjhOTktxd3QzWA$M3yrITEDiGWeoFB4+RU6e2Zo5+94NPZX007fnsFoUJs",
    "last_login": null,
    "is_superuser": true,
    "username": "brett@cymp.com.au",
    "first_name": "",
    "last_name": "",
    "email": "brett@cymp.com.au",
    "is_staff": true,
    "is_active": true,
    "date_joined": "2025-09-23T11:20:14Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$Sm40dHZRblJ2eUhSOURTczFQME1pVA$NhW6d3ZhFiroIyt9vNeQxA4f+F7Y+eeHwvxtIM2GKhA",
    "last_login": null,
    "is_superuser": false,
    "username": "intern2.demo@cymp.com.au",
    "first_name": "Maryam",
    "last_name": "Baboli",
    "email": "intern2.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-26T03:08:55.825Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$YVVJR0tpYVNnTDJLZHVaOWNHTnBIWg$lCDqsV3wJ+rBl7rtIrrImstNYJlZxuitD4yu7ce/fII",
    "last_login": null,
    "is_superuser": false,
    "username": "supervisor2.demo@cymp.com.au",
    "first_name": "Supervisor2",
    "last_name": "Demo",
    "email": "supervisor2.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-26T08:38:50.950Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$Uk5MaEFYNjFOQmVBM012bm5KZTNSeQ$0VxTQYXMNNkm81N4VtcSELQXwl7adCO1hB73zPzdiiQ",
    "last_login": null,
    "is_superuser": false,
    "username": "registrar",
    "first_name": "Sarah",
    "last_name": "Johnson",
    "email": "registrar@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-30T04:51:26.234Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$cDNmNWdFcjBxRTNSQmNVbjY5Skl6Uw$qwV2CjzABpuHnTE8iERk1WFyNs/xOc2GhCfkENywI5E",
    "last_login": null,
    "is_superuser": false,
    "username": "principal_supervisor",
    "first_name": "Dr. Michael",
    "last_name": "Chen",
    "email": "principal.supervisor@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-30T04:51:26.330Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$ZXdGSHVVWjJ3Rm5mbWVtb1VodmNUbA$TgelR6DoXHkp4avNI0w98nyHoGVcFAbzrTGTE0HiaCE",
    "last_login": null,
    "is_superuser": false,
    "username": "secondary_supervisor",
    "first_name": "Dr. Emma",
    "last_name": "Williams",
    "email": "secondary.supervisor@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-30T04:51:26.369Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$dHE4cGZ5M1pYTVZ6YXJQM2R6NDNRQg$wMWktCqVmXHQuAaDnycywWYpgrWSExHqA2TJxeFLEaI",
    "last_login": null,
    "is_superuser": false,
    "username": "other_supervisor",
    "first_name": "Dr. James",
    "last_name": "Brown",
    "email": "other.supervisor@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-30T04:51:26.407Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$YUxlVUZHbnlSeWNCTHk3S08yd0FPVQ$VHKUtfWwIJ3gJcI7r/jKRCCqcJOqjV/IZrQ9efKsoUM",
    "last_login": null,
    "is_superuser": false,
    "username": "testregistrar",
    "first_name": "Test",
    "last_name": "Registrar",
    "email": "testregistrar@example.com",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-09-30T10:21:12.519Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$SDhoMVBaR0swSHBSNk1mc0lPU2ZUVg$kCFkHVdY3DQwKylsSYDTOcBPPD/OwbG03OdjweXODUo",
    "last_login": null,
    "is_superuser": true,
    "username": "superadmin",
    "first_name": "",
    "last_name": "",
    "email": "superadmin@test.com",
    "is_staff": true,
    "is_active": true,
    "date_joined": "2025-09-30T21:35:07.410Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "auth.user",
  "fields": {
    "password": "argon2$argon2id$v=19$m=102400,t=2,p=8$azBmbXlVQkZ5ZXFCMmJPeW0xdzE4OQ$huhY2+VFXzlHGdKqvb4yHVICPa0Agfly1URDGx8Za6M",
    "last_login": "2025-10-02T06:00:54.985Z",
    "is_superuser": false,
    "username": "intern4.demo@cymp.com.au",
    "first_name": "Charlotte",
    "last_name": "Gorham Mackie",
    "email": "intern4.demo@cymp.com.au",
    "is_staff": false,
    "is_active": true,
    "date_joined": "2025-10-01T10:52:39.660Z",
    "groups": [],
    "user_permissions": []
  }
},
{
  "model": "api.userprofile",
  "pk": 2,
  "fields": {
    "user": [
      "supervisor@demo.test"
    ],
    "role": "SUPERVISOR",
    "organization": 1,
    "first_name": "Demo",
    "middle_name": "",
    "last_name": "Supervisor",
    "ahpra_registration_number": "SUP001",
    "city": "Melbourne",
    "state": "Victoria",
    "timezone": "Australia/Melbourne",
    "mobile": "+61498868928",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": null,
    "secondary_supervisor": "",
    "secondary_supervisor_email": null,
    "supervisor_emails": "",
    "signature_url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T06:30:26.640Z",
    "updated_at": "2025-10-02T05:31:17.503Z",
    "profile_completed": false,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 4,
  "fields": {
    "user": [
      "intern@demo.test"
    ],
    "role": "PROVISIONAL",
    "organization": 1,
    "first_name": "Demo",
    "middle_name": "",
    "last_name": "Intern",
    "ahpra_registration_number": "INT001",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": null,
    "secondary_supervisor": "",
    "secondary_supervisor_email": null,
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T06:31:05.132Z",
    "updated_at": "2025-10-02T05:31:17.505Z",
    "profile_completed": false,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 5,
  "fields": {
    "user": [
      "registrar@demo.test"
    ],
    "role": "REGISTRAR",
    "organization": 1,
    "first_name": "Demo",
    "middle_name": "",
    "last_name": "Registrar",
    "ahpra_registration_number": "REG001",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": null,
    "secondary_supervisor": "",
    "secondary_supervisor_email": null,
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T06:31:05.316Z",
    "updated_at": "2025-10-02T05:31:17.508Z",
    "profile_completed": false,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 6,
  "fields": {
    "user": [
      "admin@demo.test"
    ],
    "role": "ORG_ADMIN",
    "organization": 1,
    "first_name": "Demo",
    "middle_name": "",
    "last_name": "Admin",
    "ahpra_registration_number": "ADM001",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": null,
    "secondary_supervisor": "",
    "secondary_supervisor_email": null,
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T06:31:05.577Z",
    "updated_at": "2025-10-02T05:31:17.512Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 8,
  "fields": {
    "user": [
      "test.supervisor@example.com"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Supervisor",
    "ahpra_registration_number": "PSY123456789",
    "city": "Sydney",
    "state": "",
    "timezone": "",
    "mobile": "+61412345678",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T23:35:53.219Z",
    "updated_at": "2025-09-20T23:35:53.219Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 9,
  "fields": {
    "user": [
      "test.provisional@example.com"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Provisional",
    "ahpra_registration_number": "PSY987654321",
    "city": "Melbourne",
    "state": "",
    "timezone": "",
    "mobile": "+61498765432",
    "provisional_start_date": "2022-01-01",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": true,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T23:43:43.128Z",
    "updated_at": "2025-09-22T03:55:25.488Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 11,
  "fields": {
    "user": [
      "new.provisional@example.com"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "New",
    "middle_name": "",
    "last_name": "Provisional",
    "ahpra_registration_number": "PSY111222333",
    "city": "Brisbane",
    "state": "",
    "timezone": "",
    "mobile": "+61411122233",
    "provisional_start_date": "2022-06-01",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T23:44:32.966Z",
    "updated_at": "2025-09-20T23:44:32.966Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 12,
  "fields": {
    "user": [
      "test.cleanup@example.com"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Cleanup",
    "ahpra_registration_number": "PSY999888777",
    "city": "Perth",
    "state": "",
    "timezone": "",
    "mobile": "+61499988877",
    "provisional_start_date": "2022-12-01",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T23:49:08.159Z",
    "updated_at": "2025-09-20T23:49:08.159Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 17,
  "fields": {
    "user": [
      "test.new.user@example.com"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "User",
    "ahpra_registration_number": "PSY999999999",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": "2025-01-01",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-20T23:57:09.711Z",
    "updated_at": "2025-09-20T23:57:09.711Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 18,
  "fields": {
    "user": [
      "test.redirect@example.com"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Redirect",
    "ahpra_registration_number": "PSY888777666",
    "city": "Sydney",
    "state": "",
    "timezone": "",
    "mobile": "+61488877766",
    "provisional_start_date": "2025-01-01",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-21T00:01:53.121Z",
    "updated_at": "2025-09-21T00:02:11.592Z",
    "profile_completed": true,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 25,
  "fields": {
    "user": [
      "supervisor.demo@cymp.com.au"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Brett",
    "middle_name": "",
    "last_name": "Mackie",
    "ahpra_registration_number": "PSY0000000000",
    "city": "Coffs Harbour",
    "state": "Queensland",
    "timezone": "Australia/Brisbane",
    "mobile": "+61498868927",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHEAAAA4CAYAAADKKRd0AAAMP2lDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkEBoAQSkhN4EkRpASggt9N5EJSQBQokxEFTs6KKCaxcL2NBVEQUrzYIidhbF3hcLKsq6WLArb1JA133le/N9c+e//5z5z5kzc8sAoHacIxLloeoA5AsLxbHB/vTklFQ66SlAgQ4gA2NgyOEWiJjR0eEAlqH27+XddYBI2yv2Uq1/9v/XosHjF3ABQKIhzuAVcPMhPggAXsUViQsBIEp5symFIimGFWiJYYAQL5TiLDmukuIMOd4rs4mPZUHcDoCSCocjzgJA9RLk6UXcLKih2g+xo5AnEAKgRofYJz9/Eg/idIitoY0IYqk+I+MHnay/aWYMa3I4WcNYPhdZUQoQFIjyONP+z3T875KfJxnyYQmrSrY4JFY6Z5i3m7mTwqRYBeI+YUZkFMSaEH8Q8GT2EKOUbElIgtweNeAWsGDO4EoD1JHHCQiD2ADiIGFeZLiCz8gUBLEhhjsEnSooZMdDrAvxQn5BYJzCZrN4UqzCF9qQKWYxFfxZjljmV+rrviQ3ganQf53NZyv0MdXi7PgkiCkQmxcJEiMhVoXYoSA3LkxhM7Y4mxU5ZCOWxErjN4c4li8M9pfrY0WZ4qBYhX1ZfsHQfLHN2QJ2pALvL8yOD5HnB2vncmTxw7lgl/hCZsKQDr8gOXxoLjx+QKB87tgzvjAhTqHzQVToHysfi1NEedEKe9yUnxcs5U0hdikoilOMxRML4YaU6+OZosLoeHmceHEOJzRaHg++DIQDFggAdCCBNQNMAjlA0NnX2Afv5D1BgAPEIAvwgb2CGRqRJOsRwmscKAZ/QsQHBcPj/GW9fFAE+a/DrPxqDzJlvUWyEbngCcT5IAzkwXuJbJRw2FsieAwZwT+8c2DlwnjzYJX2/3t+iP3OMCETrmAkQx7pakOWxEBiADGEGES0wfVxH9wLD4dXP1idcAbuMTSP7/aEJ4QuwkPCNUI34dZEQYn4pygjQDfUD1LkIuPHXOCWUNMV98e9oTpUxnVwfWCPu0A/TNwXenaFLEsRtzQr9J+0/zaDH1ZDYUd2JKPkEWQ/svXPI1VtVV2HVaS5/jE/8lgzhvPNGu752T/rh+zzYBv2syW2EDuAncFOYOewI1gjoGOtWBPWgR2V4uHd9Vi2u4a8xcriyYU6gn/4G1pZaSYLHGsdex2/yPsK+VOl72jAmiSaJhZkZRfSmfCLwKezhVyHUXQnRydnAKTfF/nr602M7LuB6HR85+b9AYB36+Dg4OHvXGgrAPvc4ePf/J2zZsBPhzIAZ5u5EnGRnMOlFwJ8S6jBJ00PGAEzYA3n4wTcgBfwA4EgFESBeJACJsDos+E+F4MpYAaYC0pBOVgGVoP1YBPYCnaCPWA/aARHwAlwGlwAl8A1cAfunh7wAvSDd+AzgiAkhIrQED3EGLFA7BAnhIH4IIFIOBKLpCDpSBYiRCTIDGQeUo6sQNYjW5AaZB/SjJxAziFdyC3kAdKLvEY+oRiqgmqhhqglOhploEw0DI1Hx6NZ6GS0GJ2PLkHXotXobrQBPYFeQK+h3egLdAADmDKmg5lg9hgDY2FRWCqWiYmxWVgZVoFVY3VYC1znK1g31od9xIk4Dafj9nAHh+AJOBefjM/CF+Pr8Z14A96OX8Ef4P34NwKVYECwI3gS2IRkQhZhCqGUUEHYTjhEOAWfpR7COyKRqEO0IrrDZzGFmEOcTlxM3ECsJx4ndhEfEQdIJJIeyY7kTYoicUiFpFLSOtJuUivpMqmH9EFJWclYyUkpSClVSahUolShtEvpmNJlpadKn8nqZAuyJzmKzCNPIy8lbyO3kC+Se8ifKRoUK4o3JZ6SQ5lLWUupo5yi3KW8UVZWNlX2UI5RFijPUV6rvFf5rPID5Y8qmiq2KiyVNBWJyhKVHSrHVW6pvKFSqZZUP2oqtZC6hFpDPUm9T/2gSlN1UGWr8lRnq1aqNqheVn2pRlazUGOqTVArVqtQO6B2Ua1Pnaxuqc5S56jPUq9Ub1a/oT6gQdMYoxGlka+xWGOXxjmNZ5okTUvNQE2e5nzNrZonNR/RMJoZjUXj0ubRttFO0Xq0iFpWWmytHK1yrT1anVr92praLtqJ2lO1K7WPanfrYDqWOmydPJ2lOvt1rut8GmE4gjmCP2LRiLoRl0e81x2p66fL1y3Trde9pvtJj64XqJert1yvUe+ePq5vqx+jP0V/o/4p/b6RWiO9RnJHlo3cP/K2AWpgaxBrMN1gq0GHwYChkWGwochwneFJwz4jHSM/oxyjVUbHjHqNacY+xgLjVcatxs/p2nQmPY++lt5O7zcxMAkxkZhsMek0+WxqZZpgWmJab3rPjGLGMMs0W2XWZtZvbmweYT7DvNb8tgXZgmGRbbHG4ozFe0sryyTLBZaNls+sdK3YVsVWtVZ3ranWvtaTrautr9oQbRg2uTYbbC7Zorauttm2lbYX7VA7NzuB3Qa7rlGEUR6jhKOqR92wV7Fn2hfZ19o/cNBxCHcocWh0eDnafHTq6OWjz4z+5ujqmOe4zfHOGM0xoWNKxrSMee1k68R1qnS66kx1DnKe7dzk/MrFzoXvstHlpivNNcJ1gWub61c3dzexW51br7u5e7p7lfsNhhYjmrGYcdaD4OHvMdvjiMdHTzfPQs/9nn952Xvleu3yejbWaix/7Laxj7xNvTneW7y7feg+6T6bfbp9TXw5vtW+D/3M/Hh+2/2eMm2YOczdzJf+jv5i/0P+71merJms4wFYQHBAWUBnoGZgQuD6wPtBpkFZQbVB/cGuwdODj4cQQsJClofcYBuyuewadn+oe+jM0PYwlbC4sPVhD8Ntw8XhLRFoRGjEyoi7kRaRwsjGKBDFjloZdS/aKnpy9OEYYkx0TGXMk9gxsTNiz8TR4ibG7Yp7F+8fvzT+ToJ1giShLVEtMS2xJvF9UkDSiqTu5NHJM5MvpOinCFKaUkmpianbUwfGBY5bPa4nzTWtNO36eKvxU8efm6A/IW/C0YlqEzkTD6QT0pPSd6V/4URxqjkDGeyMqox+Lou7hvuC58dbxevle/NX8J9memeuyHyW5Z21Mqs32ze7IrtPwBKsF7zKCcnZlPM+Nyp3R+5gXlJefb5Sfnp+s1BTmCtsn2Q0aeqkLpGdqFTUPdlz8urJ/eIw8fYCpGB8QVOhFvyR75BYS36RPCjyKaos+jAlccqBqRpThVM7ptlOWzTtaXFQ8W/T8enc6W0zTGbMnfFgJnPmllnIrIxZbbPNZs+f3TMneM7OuZS5uXN/L3EsWVHydl7SvJb5hvPnzH/0S/AvtaWqpeLSGwu8FmxaiC8ULOxc5Lxo3aJvZbyy8+WO5RXlXxZzF5//dcyva38dXJK5pHOp29KNy4jLhMuuL/ddvnOFxoriFY9WRqxsWEVfVbbq7eqJq89VuFRsWkNZI1nTvTZ8bdM683XL1n1Zn73+WqV/ZX2VQdWiqvcbeBsub/TbWLfJcFP5pk+bBZtvbgne0lBtWV2xlbi1aOuTbYnbzvzG+K1mu/728u1fdwh3dO+M3dle415Ts8tg19JatFZS27s7bfelPQF7murs67bU69SX7wV7JXuf70vfd31/2P62A4wDdQctDlYdoh0qa0AapjX0N2Y3djelNHU1hza3tXi1HDrscHjHEZMjlUe1jy49Rjk2/9hga3HrwHHR8b4TWScetU1su3My+eTV9pj2zlNhp86eDjp98gzzTOtZ77NHznmeaz7PON94we1CQ4drx6HfXX8/1OnW2XDR/WLTJY9LLV1ju45d9r184krAldNX2VcvXIu81nU94frNG2k3um/ybj67lXfr1e2i25/vzLlLuFt2T/1exX2D+9V/2PxR3+3WffRBwIOOh3EP7zziPnrxuODxl575T6hPKp4aP6155vTsSG9Q76Xn4573vBC9+NxX+qfGn1UvrV8e/Mvvr47+5P6eV+JXg68Xv9F7s+Oty9u2geiB++/y331+X/ZB78POj4yPZz4lfXr6ecoX0pe1X22+tnwL+3Z3MH9wUMQRc2S/AhisaGYmAK93AEBNAYAGz2eUcfLzn6wg8jOrDIH/hOVnRFlxA6AO/r/H9MG/mxsA7N0Gj19QXy0NgGgqAPEeAHV2Hq5DZzXZuVJaiPAcsDn2a0Z+Bvg3RX7m/CHun1sgVXUBP7f/AiGpfGlzWaa8AAAAlmVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAJAAAAABAAAAkAAAAAEAA5KGAAcAAAASAAAAhKACAAQAAAABAAAAcaADAAQAAAABAAAAOAAAAABBU0NJSQAAAFNjcmVlbnNob3STfwV4AAAACXBIWXMAABYlAAAWJQFJUiTwAAAC12lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6VXNlckNvbW1lbnQ+U2NyZWVuc2hvdDwvZXhpZjpVc2VyQ29tbWVudD4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjE4MDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjE0NDwvdGlmZjpZUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+MTQ0PC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4K/ADFuQAAESFJREFUeAHtnAXMnEUTx7elaHAILsUdgntwDRokeIpbcAgEAgQNEIJDkOLu7pTi7q4t7u6+3/z+9P/kea+n793Ld4VO8tjK7OzMzu7M7N71ywFpNIzSHOj/T1A/epz0LZf7XIh//fVX6tevX9/24j+Ovc+EiPZx9e/fX8/ff//9P87qvut+x4WI4P78809pHxr40EMPSZA33nijejF6au28MAd0EiVTJ5o3xhhjpG+//TYdfvjh6YUXXkjPP/98mn322dXU6Km1kxz/G1dHNREB/vLLL+mZZ55JW221VVpggQXSnXfemeaff/40zjjjdIz60drck5Ud1cShQ4emiy++OI077rh6TjjhhGrNGtqz6d59IcDR2tyTd/2CKW35iRbQDTfckO6///40yyyzpEGDBqXxxx9fayPa2SmmW4AvvvhimmOOOdJYY43Vszf/0a+2p1OEBLz00ktpwIABaeONN5YA//jjD62NnRKgXZXPP/88vfPOOxJgm+PvXyPytoWIsIAppphCxgtr4rvvviuBdpLJHixvv/12Wmyxxf41AuhER9oSItqB9iG0CSaYQBbpbbfdlqabbjrR1q4WehD88MMP6ZVXXkkMmI8++ihNOeWUHcHfCQZ2A45eGzYwGO34+eefEwbNmmuuKeY+9dRTmka9VrbTSdpgIHzyySd64q5MP/30QtkJ/O3Q1pd16bf73owi9FoTaQS4/vrr0yqrrJJuuummdNBBB6Vzzz1XGomAXabdDn/11VdpkkkmSR9++GGad955hc7Ta7u4u7E+gqN/PJvhYa800VqA1uHEsw5uv/326eqrr064FRgfE000UTGaessoC4qQHQLkifvi9nuLt9vrPfbYYzLcBg4cmCaddNKGfGxZExkZMPf7779Pr732mhz5rbfeOu23335pww03TCussELCBQCamQoaMZTID4J788030zzzzNOo+L8in36iBAzcZqBlTUSICOfaa69Na6yxRnrwwQd1sS4CY445pq7XX39dvlxvtcb1vvjiC2nge++9p0FCGwwi6DAtnRgs4AUf0Cl8QtaLG0YiF+A+1kPTkiaCEAZiaEw22WRqaOWVV04PP/ywjBm7G4ssskh69tlnCyLqEVArz1MpbTEimVqwhN0GjKZMpxhuZoHPwqxFW1+n0z6D2DQ1aq9lIYIQX22hhRZKp5xyStp8883TUkstpXZgMo1PNdVUcvi/++67wlJtREg530z89NNPlUz8ddFFFy3a4IXp/OWXX1ZwnTbbATMLSxt35v8tyFYHaEvTKSMfhjG13XvvvemQQw4RI2Eg6TTOBfz222+Kn2633XZp7LHHbmpUWXjgYicEIX7zzTdphhlmkGvBN34i2klYj8Ey22yzSSPVaC9uFiBtHnnkkaL/sMMOU/u9QNewCu0AnmkaVmiiQNNCdGfBSYht8ODBaa+99kpzzz23mikL8IwzzpCWoq0IYe+995ZxUsZh2kjjKk+NCBCtIIjwxhtvSJiPPvqoFnscfdpkYFQD4yOvTFO1sqSZJlykLbfcUms9YT1iwDC8k8x2P8vt1qKrpfRA3BTERq/KhQay+usK51tp5EWH9R5+ovLCzcjDhg3Le+yxR/7xxx+VRxnK+lJi6RZTWQ6DKD/yyCP51FNPFZ4QWA7NK5X6+xVcvpxpGvxdfprGchnSgBgoOQL4er/yyitzGGt6d74+2rwZFzyLjXJhK9PSDvqm1sQgQCPyueeek1ZgeQ4Na3S++eYrBgyjHmNm2223TbfeemuafPLJ0z333JNmnXXWNN544xXTLSPbF3hx5HFJhgwZIgMpOqMp8qefftJuyPrrr1+E2aLT0hwatZbxBKjHO25PDIL0+OOPS5uVGTdrOmUoy0UavucDDzwgS5uyTN1PP/20q3XkCd20hYaztwptADR0AhpOpxDA9Pb111+LybvssouY5Z16MwMjBj8RJhCCQ4AYIwgJ63LaaacVvffdd5/qY0LjPjAtzjjjjD22ltjSWnzxxbW5vOqqq6qeGdGo01jNbEC/+uqr6bLLLtOggkbWcNoD78CwdMGHQIn1Lr/88sW21kwzzZSuueYaNQPjOwHGc/bZZwvdWmut1Su0NXkQHWwKTj/99ByOt8qGma8pkQ9PE5dccommvyeeeELT00UXXaSyoRn5jjvu0HtEIlQmOpODoUVdMoNAlQmtzMHofM455+TYM8wRDVK68/VR41YuE6cL8s4775xjcAlXjH5N6yGgHDOGMEDbLbfconf6BITVmzfYYIMca7m+yziV0OLN/AltV9/XXnvtHOu9sJDXDP7KMpXfqHRNMAEIIYwZlXNn+TAy1r8YWnmLLbbIw4cPz+eff77Kusyll16aQxvzggsumEM7c1iuPfJjStP3Bx98kEPD8+677y58Z555ptJNR1GpzovpY22DppNOOkkDxlXCp80xY+jz5JNPzjFt652+uD8RA9baTEa9tqsJgbTKdPoLb6AnZge1V7653XKa38t58CM8A2WV02vOF1FI8/j7778vn4xQEGlMrYbAplfWFGDZZZdNWJHrrruuvqMzmrLYhT/xxBO1ZnJ4iqgOeQA48S/x+yiz2WabKY28pZdemkdLYPpYF5m2WKOZYln7ANZzrhhYaaWVVipisV5bKcO0i2UMuI/6GHEjjYtp0musy5LmdPeRWGjMVGnTTTfVRVnaYFeGZxnHiCaKh9vH4r/77rvlVhWZfolCNQFphyvRY7S6MHkAIz+C3xplU089dY5AgNIZjVxAxD2VHyZ8MT2S7vxff/1V7Zx11ln55ptvzjFg8pJLLlm1XerVAtP02WefqT1PldZ06oVvqzysX8B1eDc9LAVoaTlNH3Erlw8DKMcaryynRwAix85OjkFQpO+www5qM3zcDG1M6bEW59hAyF5ajL/89KzC7BHyKpYz0+myVadTFwrJF9Oo01zRRKPeNMB11113KbuybGif8oeFywGQ7zJMNQiPtlh3IyarsldddVVRVi9N3IxzyJAhwhFHJVXLzMDVieiS8r788suR8Lt+GGU5IlEjteh8Mo477jjh8TJDWpytlYDA7WkPlwnehK+cwxfNuGCs0wb6zjICmM7y+1tvvdWjnXIZVYrbSEI0oSC+8MILVc5prsTTQmR0QWTl+uU67kRMjYVmWTMg6JhjjsngwP/EOAIP+MoCL7db7900HX/88cJh48Qdj6VB6UcddZTQmEbj9DdtQwN+KwBe5/F9wAEHKP/jjz/mUxChwbzOOuv4s3jab15ttdVyuGhFOi98QwvG22677SbNJN38CY9A7XhAux+UKcNIQjQjYCgWJOC0ckUjxFGmwxgvgDvr/IivKv/YY4/NYfYXKML1yEcffXSGEVi9WIRo4aGHHprpcLU2i8pVXlwexkPPTjvtVJQyTVjO5KFFgOu4oL/RlDgzK9rIc194P/DAA2V8sQQY4BN4rZXOYyYgncvLjOvAi3BtJDCmfcowEADTSx9iw72g0/QZh589hOjKjBDmbKDcAb4pY2SM7P33318EYEIDjCLjwWqNfbEcxkXGxEfbgCeffDKjLWggcNppp+VlllkmI1g6c8UVVyjdePTR4OaydmMi4FDgcB6WYTVmVUPNoAojrUcWVivWM1Mcbop5s+eee2oQUthtIcAw8NQe6x5AeepecMEFikixlJQF7QgYZW+//XbVjQABnwVefVTcejj7WFXRkKIeG220UfQ3FdZo1OthnbKzgCUY00AKLZMDTXksTSAEJeuLeGSsRWmaaabR0Y3hw4frqEV0XPWj0zolHoaEHHLqhlHDoyWwdRnrsuo5GMEH/QKIwwIOPOij4kY/wYU17l2UGLTqY0x9ilTFwFUAA0s8hJLCjUkx5QkTbWGNxnIkS5vfoBCsJ/iBxQv+JZZYQsdMOBnBYWsAeueaay5tHGClx5SdjjjiCAVCqANengD02ApXQmQIPIJQabQGsFY5jzS0CwOEEW/Yd999pT1Mi1hnLODWBIwJpgu0gKkVZ9qARoM7mCXtjn1I+XBuzxrv8rWeLsdID/clH3zwwUVR5+EPou3R6aaWCSxIZhnguuuuU72IVmWMnvXWWy/vs88+yqOv4LQWEfe1LREuhfKwdDF0ygYNyxVlMeio7+WGIIeXIKxSAH54naR9ghRO56np1B1lPQGBv1VyxA3mgyDO0RTWlJlNA5jaCI5BgKArgSjF4HBXAOpVayMOHsu4cRkVbuEGTujAIAD4No0YajBr1113LRhSjQaXJ8ARJxcUuaEel4UDE7E2AQfqWQqYGm3g4WJQh+BGHF1RWW4MNHhsIyeOs6gcxpKXGy8JXmOpA4CTAVFJt4RowvFbWK8AKqKRGC64DqHimZCYwXUqEVbmuxwaidFSjtZUlmWkOszmvN4+TZfb9xoT22d1UboemhNxVA0IGGwL0ZXZWWHQo50I67zzzpOP63x4STo8GxIuDzxECMxirIsAfb388svlmtgSJh2jh7px1pZPAZp+wgknFPwxnWRKiLyQSKjKaksa7gGjgxFmgCllBKTzTbqvcr6ZCOEOOTnNOI2j/N3bd3BXa5/tJRiDI16vPde1OzJshG9resh3GdIQDNpYtrxJZ7CiANYihMkU6inV6ZQ1lGmnLBobmwGSC5a7rd5K/hH+Eg6sLUc4nGbkftZKd361p+sQkEabAadVlq9kUGV+O9+0yfTkmaAsiDJepzP9s76iUUAl06vR6rplfLxX9rf8zTtXtboMAmi28MBVrdwAW3XDw2pcccUVY7D+vVfHMyrwEGAd2cpzWitP8A+MLaB6YFrqleltHrRjcQLBC1mg1XCZBraziAWHBqWFF154pPIuBy7jc5rxwj/zrVyuzMfyu+vxpDxHTwzgAn9lG+T3JzFUXK5B5YFfE1CrITdQ7+m64fv1IKpenb7K86CsxohymzAQIJAfvqzea9UhnT5Wy3ffQVCvnBqouFEeermgp1YbVJMDxcFcjskD7oA+2ryZaTACn4rNX6Bah9tsqqnqZabWq2AecPqajVz6Ac1Or1e3k3nQW094bktC5JQ1O/J9BQQGdtxxRzm9MOL/JcRW+8dhKRx1D8ZW6/9T5SVETqT552LNjtZGBCIscLFPuM022+jIBnX+6dHciM56+fCEs60R31WxbqVdQgzrSAyv16FW89xhwk5zzjmn/oQBHKOCFppGH6UPy7TV7v+j5RXo7PR8by3EYCJ2yu81iPUxLXVK0/uSSxYiJ/Y4rccPXGeKA1TdCtJEiOskc72GcHQRcEDbzFFiF988izBDEeCOyIqodXq3kS4hoiXhUHaEUDoOPn6vwXmZCHcVWjiqCNF08uQUe8SCxZtODvRODgQJceaZZ9b2CYjRot6OOAuQg79MQ7G7kVZffXXRa8Z0kvi+xAUfGIyD4u9c+Bkf0K196I/A+OenOMCjk88QDrF0wtNiI2a5LHXZO+TnbpxUi4C3qpLfrQxo1Df6xI9cuxmKNXGTTTaRKR17ZxIEU4enDwuJJ0Lnchqdc1mOv+NXLbfccjoabx/LeLqZEbVoo59d/6dHIZAeQVUC1RzZ4+gg+2bRCYrUBHY9iPj7KCD7iYZGdV2uG5+xNIgsTqOFgIvN7G7sUw8XI6hOcUpbV2yxKPjLAdeJJ55YfwDAmkfoLHYCFFMkqB1Rdh2AZQplKuXHMwC4RtUpVB0YcfNP6GK/r2sjTsUZGxjutZAnwuLC0cU644cxmNr8tBv/iYvofhxV6PEPikw/TJ+jugBNv92Lbl4Sav5BH5rE1SzxCI+Ou/Pl0TyqvsdSoV92xaa47AV+mexB2k19qilEE4kgAT+d7ue/TXDuF/2lb/x3K7MQv9vo1gHaUIju1Ohn93Lgf4iqfCeFKmb2AAAAAElFTkSuQmCC",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-21T01:49:02.666Z",
    "updated_at": "2025-09-26T08:26:15.360Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": true,
    "supervisor_registration_date": "2022-07-11",
    "can_supervise_provisionals": true,
    "can_supervise_registrars": true,
    "supervisor_welcome_seen": true
  }
},
{
  "model": "api.userprofile",
  "pk": 39,
  "fields": {
    "user": [
      "intern1.demo@cymp.com.au"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Phil",
    "middle_name": "",
    "last_name": "O'Brien",
    "ahpra_registration_number": "PSY0000000001",
    "city": "Ballarat",
    "state": "Victoria",
    "timezone": "Australia/Melbourne",
    "mobile": "+61498868921",
    "provisional_start_date": "2025-08-31",
    "report_start_day": "Monday",
    "principal_supervisor": "Brett Mackie",
    "principal_supervisor_email": "supervisor.demo@cymp.com.au",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": true,
    "provisional_registration_date": "2025-09-01",
    "internship_start_date": "2025-09-28",
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": "5+1",
    "start_date": null,
    "target_weeks": 44,
    "weekly_commitment": "17.50",
    "created_at": "2025-09-21T21:09:56.776Z",
    "updated_at": "2025-09-26T00:05:34.045Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 40,
  "fields": {
    "user": [
      "registrar1.demo@cymp.com.au"
    ],
    "role": "REGISTRAR",
    "organization": null,
    "first_name": "Registrar",
    "middle_name": "",
    "last_name": "One",
    "ahpra_registration_number": "PSY0000000011",
    "city": "Brisbane",
    "state": "Queensland",
    "timezone": "Australia/Brisbane",
    "mobile": "+61498868911",
    "provisional_start_date": "2025-08-31",
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": true,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": "CLINICAL",
    "qualification_level": "MASTERS",
    "program_type": "registrar",
    "start_date": null,
    "target_weeks": 88,
    "weekly_commitment": "34.10",
    "created_at": "2025-09-21T21:48:02.646Z",
    "updated_at": "2025-09-30T05:34:40.769Z",
    "profile_completed": true,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 41,
  "fields": {
    "user": [
      "registrar.demo@cymp.com.au"
    ],
    "role": "REGISTRAR",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Registrar",
    "ahpra_registration_number": "REG0000000000",
    "city": "Ballarat",
    "state": "Victoria",
    "timezone": "Australia/Melbourne",
    "mobile": "0498868938",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": true,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": "HEALTH",
    "qualification_level": "DOCTORATE",
    "program_type": "registrar",
    "start_date": null,
    "target_weeks": 44,
    "weekly_commitment": "34.10",
    "created_at": "2025-09-21T23:25:13.887Z",
    "updated_at": "2025-09-27T00:28:24.784Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 42,
  "fields": {
    "user": [
      "brett@cymp.com.au"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "",
    "middle_name": "",
    "last_name": "",
    "ahpra_registration_number": "",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-23T12:04:26.508Z",
    "updated_at": "2025-09-23T12:04:26.508Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 43,
  "fields": {
    "user": [
      "intern2.demo@cymp.com.au"
    ],
    "role": "PROVISIONAL",
    "organization": null,
    "first_name": "Maryam",
    "middle_name": "",
    "last_name": "Baboli",
    "ahpra_registration_number": "PSY0000000002",
    "city": "Hervey Bay",
    "state": "Queensland",
    "timezone": "Australia/Brisbane",
    "mobile": "+61498868922",
    "provisional_start_date": "2025-08-31",
    "report_start_day": "Monday",
    "principal_supervisor": "Supervisor2 Demo",
    "principal_supervisor_email": "supervisor2.demo@cymp.com.au",
    "secondary_supervisor": "Brett Mackie",
    "secondary_supervisor_email": "supervisor.demo@cymp.com.au",
    "supervisor_emails": "",
    "signature_url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHEAAAA4CAYAAADKKRd0AAAMP2lDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkEBoAQSkhN4EkRpASggt9N5EJSQBQokxEFTs6KKCaxcL2NBVEQUrzYIidhbF3hcLKsq6WLArb1JA133le/N9c+e//5z5z5kzc8sAoHacIxLloeoA5AsLxbHB/vTklFQ66SlAgQ4gA2NgyOEWiJjR0eEAlqH27+XddYBI2yv2Uq1/9v/XosHjF3ABQKIhzuAVcPMhPggAXsUViQsBIEp5symFIimGFWiJYYAQL5TiLDmukuIMOd4rs4mPZUHcDoCSCocjzgJA9RLk6UXcLKih2g+xo5AnEAKgRofYJz9/Eg/idIitoY0IYqk+I+MHnay/aWYMa3I4WcNYPhdZUQoQFIjyONP+z3T875KfJxnyYQmrSrY4JFY6Z5i3m7mTwqRYBeI+YUZkFMSaEH8Q8GT2EKOUbElIgtweNeAWsGDO4EoD1JHHCQiD2ADiIGFeZLiCz8gUBLEhhjsEnSooZMdDrAvxQn5BYJzCZrN4UqzCF9qQKWYxFfxZjljmV+rrviQ3ganQf53NZyv0MdXi7PgkiCkQmxcJEiMhVoXYoSA3LkxhM7Y4mxU5ZCOWxErjN4c4li8M9pfrY0WZ4qBYhX1ZfsHQfLHN2QJ2pALvL8yOD5HnB2vncmTxw7lgl/hCZsKQDr8gOXxoLjx+QKB87tgzvjAhTqHzQVToHysfi1NEedEKe9yUnxcs5U0hdikoilOMxRML4YaU6+OZosLoeHmceHEOJzRaHg++DIQDFggAdCCBNQNMAjlA0NnX2Afv5D1BgAPEIAvwgb2CGRqRJOsRwmscKAZ/QsQHBcPj/GW9fFAE+a/DrPxqDzJlvUWyEbngCcT5IAzkwXuJbJRw2FsieAwZwT+8c2DlwnjzYJX2/3t+iP3OMCETrmAkQx7pakOWxEBiADGEGES0wfVxH9wLD4dXP1idcAbuMTSP7/aEJ4QuwkPCNUI34dZEQYn4pygjQDfUD1LkIuPHXOCWUNMV98e9oTpUxnVwfWCPu0A/TNwXenaFLEsRtzQr9J+0/zaDH1ZDYUd2JKPkEWQ/svXPI1VtVV2HVaS5/jE/8lgzhvPNGu752T/rh+zzYBv2syW2EDuAncFOYOewI1gjoGOtWBPWgR2V4uHd9Vi2u4a8xcriyYU6gn/4G1pZaSYLHGsdex2/yPsK+VOl72jAmiSaJhZkZRfSmfCLwKezhVyHUXQnRydnAKTfF/nr602M7LuB6HR85+b9AYB36+Dg4OHvXGgrAPvc4ePf/J2zZsBPhzIAZ5u5EnGRnMOlFwJ8S6jBJ00PGAEzYA3n4wTcgBfwA4EgFESBeJACJsDos+E+F4MpYAaYC0pBOVgGVoP1YBPYCnaCPWA/aARHwAlwGlwAl8A1cAfunh7wAvSDd+AzgiAkhIrQED3EGLFA7BAnhIH4IIFIOBKLpCDpSBYiRCTIDGQeUo6sQNYjW5AaZB/SjJxAziFdyC3kAdKLvEY+oRiqgmqhhqglOhploEw0DI1Hx6NZ6GS0GJ2PLkHXotXobrQBPYFeQK+h3egLdAADmDKmg5lg9hgDY2FRWCqWiYmxWVgZVoFVY3VYC1znK1g31od9xIk4Dafj9nAHh+AJOBefjM/CF+Pr8Z14A96OX8Ef4P34NwKVYECwI3gS2IRkQhZhCqGUUEHYTjhEOAWfpR7COyKRqEO0IrrDZzGFmEOcTlxM3ECsJx4ndhEfEQdIJJIeyY7kTYoicUiFpFLSOtJuUivpMqmH9EFJWclYyUkpSClVSahUolShtEvpmNJlpadKn8nqZAuyJzmKzCNPIy8lbyO3kC+Se8ifKRoUK4o3JZ6SQ5lLWUupo5yi3KW8UVZWNlX2UI5RFijPUV6rvFf5rPID5Y8qmiq2KiyVNBWJyhKVHSrHVW6pvKFSqZZUP2oqtZC6hFpDPUm9T/2gSlN1UGWr8lRnq1aqNqheVn2pRlazUGOqTVArVqtQO6B2Ua1Pnaxuqc5S56jPUq9Ub1a/oT6gQdMYoxGlka+xWGOXxjmNZ5okTUvNQE2e5nzNrZonNR/RMJoZjUXj0ubRttFO0Xq0iFpWWmytHK1yrT1anVr92praLtqJ2lO1K7WPanfrYDqWOmydPJ2lOvt1rut8GmE4gjmCP2LRiLoRl0e81x2p66fL1y3Trde9pvtJj64XqJert1yvUe+ePq5vqx+jP0V/o/4p/b6RWiO9RnJHlo3cP/K2AWpgaxBrMN1gq0GHwYChkWGwochwneFJwz4jHSM/oxyjVUbHjHqNacY+xgLjVcatxs/p2nQmPY++lt5O7zcxMAkxkZhsMek0+WxqZZpgWmJab3rPjGLGMMs0W2XWZtZvbmweYT7DvNb8tgXZgmGRbbHG4ozFe0sryyTLBZaNls+sdK3YVsVWtVZ3ranWvtaTrautr9oQbRg2uTYbbC7Zorauttm2lbYX7VA7NzuB3Qa7rlGEUR6jhKOqR92wV7Fn2hfZ19o/cNBxCHcocWh0eDnafHTq6OWjz4z+5ujqmOe4zfHOGM0xoWNKxrSMee1k68R1qnS66kx1DnKe7dzk/MrFzoXvstHlpivNNcJ1gWub61c3dzexW51br7u5e7p7lfsNhhYjmrGYcdaD4OHvMdvjiMdHTzfPQs/9nn952Xvleu3yejbWaix/7Laxj7xNvTneW7y7feg+6T6bfbp9TXw5vtW+D/3M/Hh+2/2eMm2YOczdzJf+jv5i/0P+71merJms4wFYQHBAWUBnoGZgQuD6wPtBpkFZQbVB/cGuwdODj4cQQsJClofcYBuyuewadn+oe+jM0PYwlbC4sPVhD8Ntw8XhLRFoRGjEyoi7kRaRwsjGKBDFjloZdS/aKnpy9OEYYkx0TGXMk9gxsTNiz8TR4ibG7Yp7F+8fvzT+ToJ1giShLVEtMS2xJvF9UkDSiqTu5NHJM5MvpOinCFKaUkmpianbUwfGBY5bPa4nzTWtNO36eKvxU8efm6A/IW/C0YlqEzkTD6QT0pPSd6V/4URxqjkDGeyMqox+Lou7hvuC58dbxevle/NX8J9memeuyHyW5Z21Mqs32ze7IrtPwBKsF7zKCcnZlPM+Nyp3R+5gXlJefb5Sfnp+s1BTmCtsn2Q0aeqkLpGdqFTUPdlz8urJ/eIw8fYCpGB8QVOhFvyR75BYS36RPCjyKaos+jAlccqBqRpThVM7ptlOWzTtaXFQ8W/T8enc6W0zTGbMnfFgJnPmllnIrIxZbbPNZs+f3TMneM7OuZS5uXN/L3EsWVHydl7SvJb5hvPnzH/0S/AvtaWqpeLSGwu8FmxaiC8ULOxc5Lxo3aJvZbyy8+WO5RXlXxZzF5//dcyva38dXJK5pHOp29KNy4jLhMuuL/ddvnOFxoriFY9WRqxsWEVfVbbq7eqJq89VuFRsWkNZI1nTvTZ8bdM683XL1n1Zn73+WqV/ZX2VQdWiqvcbeBsub/TbWLfJcFP5pk+bBZtvbgne0lBtWV2xlbi1aOuTbYnbzvzG+K1mu/728u1fdwh3dO+M3dle415Ts8tg19JatFZS27s7bfelPQF7murs67bU69SX7wV7JXuf70vfd31/2P62A4wDdQctDlYdoh0qa0AapjX0N2Y3djelNHU1hza3tXi1HDrscHjHEZMjlUe1jy49Rjk2/9hga3HrwHHR8b4TWScetU1su3My+eTV9pj2zlNhp86eDjp98gzzTOtZ77NHznmeaz7PON94we1CQ4drx6HfXX8/1OnW2XDR/WLTJY9LLV1ju45d9r184krAldNX2VcvXIu81nU94frNG2k3um/ybj67lXfr1e2i25/vzLlLuFt2T/1exX2D+9V/2PxR3+3WffRBwIOOh3EP7zziPnrxuODxl575T6hPKp4aP6155vTsSG9Q76Xn4573vBC9+NxX+qfGn1UvrV8e/Mvvr47+5P6eV+JXg68Xv9F7s+Oty9u2geiB++/y331+X/ZB78POj4yPZz4lfXr6ecoX0pe1X22+tnwL+3Z3MH9wUMQRc2S/AhisaGYmAK93AEBNAYAGz2eUcfLzn6wg8jOrDIH/hOVnRFlxA6AO/r/H9MG/mxsA7N0Gj19QXy0NgGgqAPEeAHV2Hq5DZzXZuVJaiPAcsDn2a0Z+Bvg3RX7m/CHun1sgVXUBP7f/AiGpfGlzWaa8AAAAlmVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAJAAAAABAAAAkAAAAAEAA5KGAAcAAAASAAAAhKACAAQAAAABAAAAcaADAAQAAAABAAAAOAAAAABBU0NJSQAAAFNjcmVlbnNob3STfwV4AAAACXBIWXMAABYlAAAWJQFJUiTwAAAC12lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6VXNlckNvbW1lbnQ+U2NyZWVuc2hvdDwvZXhpZjpVc2VyQ29tbWVudD4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjE4MDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjE0NDwvdGlmZjpZUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+MTQ0PC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4K/ADFuQAAESFJREFUeAHtnAXMnEUTx7elaHAILsUdgntwDRokeIpbcAgEAgQNEIJDkOLu7pTi7q4t7u6+3/z+9P/kea+n793Ld4VO8tjK7OzMzu7M7N71ywFpNIzSHOj/T1A/epz0LZf7XIh//fVX6tevX9/24j+Ovc+EiPZx9e/fX8/ff//9P87qvut+x4WI4P78809pHxr40EMPSZA33nijejF6au28MAd0EiVTJ5o3xhhjpG+//TYdfvjh6YUXXkjPP/98mn322dXU6Km1kxz/G1dHNREB/vLLL+mZZ55JW221VVpggQXSnXfemeaff/40zjjjdIz60drck5Ud1cShQ4emiy++OI077rh6TjjhhGrNGtqz6d59IcDR2tyTd/2CKW35iRbQDTfckO6///40yyyzpEGDBqXxxx9fayPa2SmmW4AvvvhimmOOOdJYY43Vszf/0a+2p1OEBLz00ktpwIABaeONN5YA//jjD62NnRKgXZXPP/88vfPOOxJgm+PvXyPytoWIsIAppphCxgtr4rvvviuBdpLJHixvv/12Wmyxxf41AuhER9oSItqB9iG0CSaYQBbpbbfdlqabbjrR1q4WehD88MMP6ZVXXkkMmI8++ihNOeWUHcHfCQZ2A45eGzYwGO34+eefEwbNmmuuKeY+9dRTmka9VrbTSdpgIHzyySd64q5MP/30QtkJ/O3Q1pd16bf73owi9FoTaQS4/vrr0yqrrJJuuummdNBBB6Vzzz1XGomAXabdDn/11VdpkkkmSR9++GGad955hc7Ta7u4u7E+gqN/PJvhYa800VqA1uHEsw5uv/326eqrr064FRgfE000UTGaessoC4qQHQLkifvi9nuLt9vrPfbYYzLcBg4cmCaddNKGfGxZExkZMPf7779Pr732mhz5rbfeOu23335pww03TCussELCBQCamQoaMZTID4J788030zzzzNOo+L8in36iBAzcZqBlTUSICOfaa69Na6yxRnrwwQd1sS4CY445pq7XX39dvlxvtcb1vvjiC2nge++9p0FCGwwi6DAtnRgs4AUf0Cl8QtaLG0YiF+A+1kPTkiaCEAZiaEw22WRqaOWVV04PP/ywjBm7G4ssskh69tlnCyLqEVArz1MpbTEimVqwhN0GjKZMpxhuZoHPwqxFW1+n0z6D2DQ1aq9lIYIQX22hhRZKp5xyStp8883TUkstpXZgMo1PNdVUcvi/++67wlJtREg530z89NNPlUz8ddFFFy3a4IXp/OWXX1ZwnTbbATMLSxt35v8tyFYHaEvTKSMfhjG13XvvvemQQw4RI2Eg6TTOBfz222+Kn2633XZp7LHHbmpUWXjgYicEIX7zzTdphhlmkGvBN34i2klYj8Ey22yzSSPVaC9uFiBtHnnkkaL/sMMOU/u9QNewCu0AnmkaVmiiQNNCdGfBSYht8ODBaa+99kpzzz23mikL8IwzzpCWoq0IYe+995ZxUsZh2kjjKk+NCBCtIIjwxhtvSJiPPvqoFnscfdpkYFQD4yOvTFO1sqSZJlykLbfcUms9YT1iwDC8k8x2P8vt1qKrpfRA3BTERq/KhQay+usK51tp5EWH9R5+ovLCzcjDhg3Le+yxR/7xxx+VRxnK+lJi6RZTWQ6DKD/yyCP51FNPFZ4QWA7NK5X6+xVcvpxpGvxdfprGchnSgBgoOQL4er/yyitzGGt6d74+2rwZFzyLjXJhK9PSDvqm1sQgQCPyueeek1ZgeQ4Na3S++eYrBgyjHmNm2223TbfeemuafPLJ0z333JNmnXXWNN544xXTLSPbF3hx5HFJhgwZIgMpOqMp8qefftJuyPrrr1+E2aLT0hwatZbxBKjHO25PDIL0+OOPS5uVGTdrOmUoy0UavucDDzwgS5uyTN1PP/20q3XkCd20hYaztwptADR0AhpOpxDA9Pb111+LybvssouY5Z16MwMjBj8RJhCCQ4AYIwgJ63LaaacVvffdd5/qY0LjPjAtzjjjjD22ltjSWnzxxbW5vOqqq6qeGdGo01jNbEC/+uqr6bLLLtOggkbWcNoD78CwdMGHQIn1Lr/88sW21kwzzZSuueYaNQPjOwHGc/bZZwvdWmut1Su0NXkQHWwKTj/99ByOt8qGma8pkQ9PE5dccommvyeeeELT00UXXaSyoRn5jjvu0HtEIlQmOpODoUVdMoNAlQmtzMHofM455+TYM8wRDVK68/VR41YuE6cL8s4775xjcAlXjH5N6yGgHDOGMEDbLbfconf6BITVmzfYYIMca7m+yziV0OLN/AltV9/XXnvtHOu9sJDXDP7KMpXfqHRNMAEIIYwZlXNn+TAy1r8YWnmLLbbIw4cPz+eff77Kusyll16aQxvzggsumEM7c1iuPfJjStP3Bx98kEPD8+677y58Z555ptJNR1GpzovpY22DppNOOkkDxlXCp80xY+jz5JNPzjFt652+uD8RA9baTEa9tqsJgbTKdPoLb6AnZge1V7653XKa38t58CM8A2WV02vOF1FI8/j7778vn4xQEGlMrYbAplfWFGDZZZdNWJHrrruuvqMzmrLYhT/xxBO1ZnJ4iqgOeQA48S/x+yiz2WabKY28pZdemkdLYPpYF5m2WKOZYln7ANZzrhhYaaWVVipisV5bKcO0i2UMuI/6GHEjjYtp0musy5LmdPeRWGjMVGnTTTfVRVnaYFeGZxnHiCaKh9vH4r/77rvlVhWZfolCNQFphyvRY7S6MHkAIz+C3xplU089dY5AgNIZjVxAxD2VHyZ8MT2S7vxff/1V7Zx11ln55ptvzjFg8pJLLlm1XerVAtP02WefqT1PldZ06oVvqzysX8B1eDc9LAVoaTlNH3Erlw8DKMcaryynRwAix85OjkFQpO+www5qM3zcDG1M6bEW59hAyF5ajL/89KzC7BHyKpYz0+myVadTFwrJF9Oo01zRRKPeNMB11113KbuybGif8oeFywGQ7zJMNQiPtlh3IyarsldddVVRVi9N3IxzyJAhwhFHJVXLzMDVieiS8r788suR8Lt+GGU5IlEjteh8Mo477jjh8TJDWpytlYDA7WkPlwnehK+cwxfNuGCs0wb6zjICmM7y+1tvvdWjnXIZVYrbSEI0oSC+8MILVc5prsTTQmR0QWTl+uU67kRMjYVmWTMg6JhjjsngwP/EOAIP+MoCL7db7900HX/88cJh48Qdj6VB6UcddZTQmEbj9DdtQwN+KwBe5/F9wAEHKP/jjz/mUxChwbzOOuv4s3jab15ttdVyuGhFOi98QwvG22677SbNJN38CY9A7XhAux+UKcNIQjQjYCgWJOC0ckUjxFGmwxgvgDvr/IivKv/YY4/NYfYXKML1yEcffXSGEVi9WIRo4aGHHprpcLU2i8pVXlwexkPPTjvtVJQyTVjO5KFFgOu4oL/RlDgzK9rIc194P/DAA2V8sQQY4BN4rZXOYyYgncvLjOvAi3BtJDCmfcowEADTSx9iw72g0/QZh589hOjKjBDmbKDcAb4pY2SM7P33318EYEIDjCLjwWqNfbEcxkXGxEfbgCeffDKjLWggcNppp+VlllkmI1g6c8UVVyjdePTR4OaydmMi4FDgcB6WYTVmVUPNoAojrUcWVivWM1Mcbop5s+eee2oQUthtIcAw8NQe6x5AeepecMEFikixlJQF7QgYZW+//XbVjQABnwVefVTcejj7WFXRkKIeG220UfQ3FdZo1OthnbKzgCUY00AKLZMDTXksTSAEJeuLeGSsRWmaaabR0Y3hw4frqEV0XPWj0zolHoaEHHLqhlHDoyWwdRnrsuo5GMEH/QKIwwIOPOij4kY/wYU17l2UGLTqY0x9ilTFwFUAA0s8hJLCjUkx5QkTbWGNxnIkS5vfoBCsJ/iBxQv+JZZYQsdMOBnBYWsAeueaay5tHGClx5SdjjjiCAVCqANengD02ApXQmQIPIJQabQGsFY5jzS0CwOEEW/Yd999pT1Mi1hnLODWBIwJpgu0gKkVZ9qARoM7mCXtjn1I+XBuzxrv8rWeLsdID/clH3zwwUVR5+EPou3R6aaWCSxIZhnguuuuU72IVmWMnvXWWy/vs88+yqOv4LQWEfe1LREuhfKwdDF0ygYNyxVlMeio7+WGIIeXIKxSAH54naR9ghRO56np1B1lPQGBv1VyxA3mgyDO0RTWlJlNA5jaCI5BgKArgSjF4HBXAOpVayMOHsu4cRkVbuEGTujAIAD4No0YajBr1113LRhSjQaXJ8ARJxcUuaEel4UDE7E2AQfqWQqYGm3g4WJQh+BGHF1RWW4MNHhsIyeOs6gcxpKXGy8JXmOpA4CTAVFJt4RowvFbWK8AKqKRGC64DqHimZCYwXUqEVbmuxwaidFSjtZUlmWkOszmvN4+TZfb9xoT22d1UboemhNxVA0IGGwL0ZXZWWHQo50I67zzzpOP63x4STo8GxIuDzxECMxirIsAfb388svlmtgSJh2jh7px1pZPAZp+wgknFPwxnWRKiLyQSKjKaksa7gGjgxFmgCllBKTzTbqvcr6ZCOEOOTnNOI2j/N3bd3BXa5/tJRiDI16vPde1OzJshG9resh3GdIQDNpYtrxJZ7CiANYihMkU6inV6ZQ1lGmnLBobmwGSC5a7rd5K/hH+Eg6sLUc4nGbkftZKd361p+sQkEabAadVlq9kUGV+O9+0yfTkmaAsiDJepzP9s76iUUAl06vR6rplfLxX9rf8zTtXtboMAmi28MBVrdwAW3XDw2pcccUVY7D+vVfHMyrwEGAd2cpzWitP8A+MLaB6YFrqleltHrRjcQLBC1mg1XCZBraziAWHBqWFF154pPIuBy7jc5rxwj/zrVyuzMfyu+vxpDxHTwzgAn9lG+T3JzFUXK5B5YFfE1CrITdQ7+m64fv1IKpenb7K86CsxohymzAQIJAfvqzea9UhnT5Wy3ffQVCvnBqouFEeermgp1YbVJMDxcFcjskD7oA+2ryZaTACn4rNX6Bah9tsqqnqZabWq2AecPqajVz6Ac1Or1e3k3nQW094bktC5JQ1O/J9BQQGdtxxRzm9MOL/JcRW+8dhKRx1D8ZW6/9T5SVETqT552LNjtZGBCIscLFPuM022+jIBnX+6dHciM56+fCEs60R31WxbqVdQgzrSAyv16FW89xhwk5zzjmn/oQBHKOCFppGH6UPy7TV7v+j5RXo7PR8by3EYCJ2yu81iPUxLXVK0/uSSxYiJ/Y4rccPXGeKA1TdCtJEiOskc72GcHQRcEDbzFFiF988izBDEeCOyIqodXq3kS4hoiXhUHaEUDoOPn6vwXmZCHcVWjiqCNF08uQUe8SCxZtODvRODgQJceaZZ9b2CYjRot6OOAuQg79MQ7G7kVZffXXRa8Z0kvi+xAUfGIyD4u9c+Bkf0K196I/A+OenOMCjk88QDrF0wtNiI2a5LHXZO+TnbpxUi4C3qpLfrQxo1Df6xI9cuxmKNXGTTTaRKR17ZxIEU4enDwuJJ0Lnchqdc1mOv+NXLbfccjoabx/LeLqZEbVoo59d/6dHIZAeQVUC1RzZ4+gg+2bRCYrUBHY9iPj7KCD7iYZGdV2uG5+xNIgsTqOFgIvN7G7sUw8XI6hOcUpbV2yxKPjLAdeJJ55YfwDAmkfoLHYCFFMkqB1Rdh2AZQplKuXHMwC4RtUpVB0YcfNP6GK/r2sjTsUZGxjutZAnwuLC0cU644cxmNr8tBv/iYvofhxV6PEPikw/TJ+jugBNv92Lbl4Sav5BH5rE1SzxCI+Ou/Pl0TyqvsdSoV92xaa47AV+mexB2k19qilEE4kgAT+d7ue/TXDuF/2lb/x3K7MQv9vo1gHaUIju1Ohn93Lgf4iqfCeFKmb2AAAAAElFTkSuQmCC",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": true,
    "provisional_registration_date": "2025-07-01",
    "internship_start_date": "2025-09-01",
    "is_full_time": true,
    "estimated_completion_weeks": 44,
    "weekly_commitment_hours": "17.50",
    "aope": null,
    "qualification_level": null,
    "program_type": "5+1",
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-26T03:08:55.880Z",
    "updated_at": "2025-09-26T08:24:49.532Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 44,
  "fields": {
    "user": [
      "supervisor2.demo@cymp.com.au"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Supervisor2",
    "middle_name": "",
    "last_name": "Demo",
    "ahpra_registration_number": "PSY000000020",
    "city": "Gold Coast",
    "state": "Queensland",
    "timezone": "Australia/Brisbane",
    "mobile": "0498868902",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-26T08:38:51.013Z",
    "updated_at": "2025-09-27T01:30:50.082Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": true,
    "supervisor_registration_date": "2025-09-29",
    "can_supervise_provisionals": true,
    "can_supervise_registrars": true,
    "supervisor_welcome_seen": true
  }
},
{
  "model": "api.userprofile",
  "pk": 45,
  "fields": {
    "user": [
      "registrar"
    ],
    "role": "REGISTRAR",
    "organization": null,
    "first_name": "Sarah",
    "middle_name": "",
    "last_name": "Johnson",
    "ahpra_registration_number": "PSY000123456",
    "city": "Melbourne",
    "state": "VIC",
    "timezone": "Australia/Melbourne",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-30T04:51:26.325Z",
    "updated_at": "2025-09-30T04:51:26.325Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 46,
  "fields": {
    "user": [
      "principal_supervisor"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Dr. Michael",
    "middle_name": "",
    "last_name": "Chen",
    "ahpra_registration_number": "PSY000789012",
    "city": "Melbourne",
    "state": "VIC",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-30T04:51:26.367Z",
    "updated_at": "2025-09-30T04:51:26.367Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": true,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": true,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 47,
  "fields": {
    "user": [
      "secondary_supervisor"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Dr. Emma",
    "middle_name": "",
    "last_name": "Williams",
    "ahpra_registration_number": "PSY000345678",
    "city": "Melbourne",
    "state": "VIC",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-30T04:51:26.406Z",
    "updated_at": "2025-09-30T04:51:26.406Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": true,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": true,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 48,
  "fields": {
    "user": [
      "other_supervisor"
    ],
    "role": "SUPERVISOR",
    "organization": null,
    "first_name": "Dr. James",
    "middle_name": "",
    "last_name": "Brown",
    "ahpra_registration_number": "PSY000901234",
    "city": "Melbourne",
    "state": "VIC",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-30T04:51:26.443Z",
    "updated_at": "2025-09-30T04:51:26.443Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": true,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": true,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 49,
  "fields": {
    "user": [
      "testregistrar"
    ],
    "role": "REGISTRAR",
    "organization": null,
    "first_name": "Test",
    "middle_name": "",
    "last_name": "Registrar",
    "ahpra_registration_number": "PSY000123457",
    "city": "",
    "state": "",
    "timezone": "",
    "mobile": "",
    "provisional_start_date": null,
    "report_start_day": "Monday",
    "principal_supervisor": "",
    "principal_supervisor_email": "",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": false,
    "prior_hours_submitted": false,
    "provisional_registration_date": null,
    "internship_start_date": null,
    "is_full_time": true,
    "estimated_completion_weeks": null,
    "weekly_commitment_hours": null,
    "aope": null,
    "qualification_level": null,
    "program_type": null,
    "start_date": null,
    "target_weeks": null,
    "weekly_commitment": null,
    "created_at": "2025-09-30T10:21:12.602Z",
    "updated_at": "2025-09-30T10:21:12.602Z",
    "profile_completed": false,
    "first_login_completed": false,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
},
{
  "model": "api.userprofile",
  "pk": 50,
  "fields": {
    "user": [
      "intern4.demo@cymp.com.au"
    ],
    "role": "PROVISIONAL",
    "organization": 2,
    "first_name": "Charlotte",
    "middle_name": "",
    "last_name": "Gorham Mackie",
    "ahpra_registration_number": "PSY0000000004",
    "city": "Melbourne",
    "state": "VIC",
    "timezone": "Australia/Melbourne",
    "mobile": "0498868924",
    "provisional_start_date": "2024-09-01",
    "report_start_day": "Monday",
    "principal_supervisor": "Demo Supervisor",
    "principal_supervisor_email": "demo.supervisor@example.com",
    "secondary_supervisor": "",
    "secondary_supervisor_email": "",
    "supervisor_emails": "",
    "signature_url": "",
    "initials_url": "",
    "prior_hours": {},
    "prior_hours_declined": true,
    "prior_hours_submitted": false,
    "provisional_registration_date": "2024-07-01",
    "internship_start_date": "2024-09-01",
    "is_full_time": true,
    "estimated_completion_weeks": 44,
    "weekly_commitment_hours": "17.50",
    "aope": null,
    "qualification_level": null,
    "program_type": "5+1",
    "start_date": "2024-09-08",
    "target_weeks": 44,
    "weekly_commitment": "17.50",
    "created_at": "2025-10-01T10:52:39.722Z",
    "updated_at": "2025-10-02T09:39:39.529Z",
    "profile_completed": true,
    "first_login_completed": true,
    "is_board_approved_supervisor": false,
    "supervisor_registration_date": null,
    "can_supervise_provisionals": false,
    "can_supervise_registrars": false,
    "supervisor_welcome_seen": false
  }
}