import React from 'react'
import { apiFetch } from './api'

export interface LastSessionData {
  presenting_issues: string
  place_of_practice: string
  client_age: number | null
  session_activity_types: string[]
}

/**
 * Get client pseudonym suggestions for autocomplete
 */
export async function getClientSuggestions(query?: string): Promise<string[]> {
  const params = query ? `?q=${encodeURIComponent(query)}` : ''
  const response = await apiFetch(`/api/section-a/entries/client_autocomplete/${params}`)
  
  if (!response.ok) {
    throw new Error('Failed to fetch client suggestions')
  }
  
  return response.json()
}

/**
 * Get place of practice suggestions for autocomplete
 */
export async function getPlaceSuggestions(query?: string): Promise<string[]> {
  const params = query ? `?q=${encodeURIComponent(query)}` : ''
  const response = await apiFetch(`/api/section-a/entries/place_autocomplete/${params}`)
  
  if (!response.ok) {
    throw new Error('Failed to fetch place suggestions')
  }
  
  return response.json()
}

/**
 * Smart autocomplete hook for real-time suggestions
 */
export function useSmartAutocomplete<T>(
  fetchFn: (query: string) => Promise<T[]>,
  minChars: number = 2,
  debounceMs: number = 300
) {
  const [suggestions, setSuggestions] = React.useState<T[]>([])
  const [loading, setLoading] = React.useState(false)
  const [query, setQuery] = React.useState('')

  React.useEffect(() => {
    if (query.length < minChars) {
      setSuggestions([])
      return
    }

    const timeoutId = setTimeout(async () => {
      setLoading(true)
      try {
        const results = await fetchFn(query)
        setSuggestions(results)
      } catch (error) {
        console.error('Failed to fetch suggestions:', error)
        setSuggestions([])
      } finally {
        setLoading(false)
      }
    }, debounceMs)

    return () => clearTimeout(timeoutId)
  }, [query, fetchFn, minChars, debounceMs])

  return {
    suggestions,
    loading,
    query,
    setQuery
  }
}

/**
 * Get last session data for a specific client to prefill form fields
 */
export async function getLastSessionData(clientId: string): Promise<LastSessionData> {
  const response = await apiFetch(`/api/section-a/entries/last_session_data/?client_id=${encodeURIComponent(clientId)}`)
  
  if (!response.ok) {
    if (response.status === 404) {
      // No previous sessions found - return empty data
      return {
        presenting_issues: '',
        place_of_practice: '',
        client_age: null,
        session_activity_types: []
      }
    }
    throw new Error('Failed to fetch last session data')
  }
  
  return response.json()
}

/**
 * Get activity type suggestions (standard types)
 */
export function getActivityTypeSuggestions(): string[] {
  return [
    'psychological_assessment',
    'intervention',
    'prevention',
    'evaluation'
  ]
}

/**
 * Get professional development activity type suggestions
 */
export function getPDActivityTypeSuggestions(): string[] {
  return [
    'WORKSHOP',
    'WEBINAR', 
    'LECTURE',
    'PRESENTATION',
    'READING',
    'COURSE',
    'CONFERENCE',
    'TRAINING',
    'OTHER'
  ]
}

/**
 * Get supervision type suggestions
 */
export function getSupervisionTypeSuggestions(): string[] {
  return [
    'INDIVIDUAL',
    'GROUP',
    'OTHER'
  ]
}

/**
 * Get supervisor type suggestions
 */
export function getSupervisorTypeSuggestions(): string[] {
  return [
    'PRINCIPAL',
    'SECONDARY'
  ]
}
