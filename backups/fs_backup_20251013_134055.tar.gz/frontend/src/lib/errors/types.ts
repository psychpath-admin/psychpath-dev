/**
 * PsychPATH Universal Error Handling Module
 * 
 * This module provides a complete, reusable error handling system with:
 * - 3-part error message structure (Issue, What This Means, What You Can Do)
 * - Automatic error logging to support audit trail
 * - Error highlighting and help page integration
 * - Consistent UX across the application
 */

export interface ErrorDetails {
  /** Unique error identifier */
  errorId?: string
  /** Brief error title */
  title: string
  /** What the error is about */
  summary: string
  /** Detailed explanation of what this means */
  explanation: string
  /** Steps the user can take to resolve it */
  userAction: string
  /** Optional category for error classification */
  category?: 'Validation' | 'Network' | 'Server' | 'Client' | 'General' | 'System'
  /** Additional context for debugging */
  context?: Record<string, any>
}

export interface ErrorOverlayProps {
  /** Error details to display */
  error: ErrorDetails
  /** Whether the overlay is visible */
  isOpen: boolean
  /** Callback when user clicks "I Understand" */
  onClose: () => void
  /** Callback when user clicks "I Need More Help" */
  onGetHelp?: () => void
  /** Custom help URL (defaults to /help/errors) */
  helpUrl?: string
  /** Whether to open help in new tab (default: true) */
  openInNewTab?: boolean
}

export interface ErrorLogData {
  error_id?: string
  error_title: string
  error_summary: string
  error_explanation?: string
  user_action?: string
  page_url?: string
  additional_context?: Record<string, any>
}

export interface ErrorHelpPageProps {
  /** Initial error to highlight (from URL params) */
  initialError?: ErrorDetails
  /** Whether to show support form */
  showSupportForm?: boolean
  /** Custom error database (optional) */
  errorDatabase?: ErrorEntry[]
}

export interface ErrorEntry {
  id: string
  summary: string
  explanation: string
  stepsToResolve: string[]
  category: 'Validation' | 'Network' | 'Server' | 'Client' | 'General' | 'System'
  frequency: number
}

export interface ErrorHandlerConfig {
  /** Base URL for help page */
  helpBaseUrl?: string
  /** Whether to automatically log errors */
  autoLogErrors?: boolean
  /** Custom error logging function */
  logErrorFunction?: (errorData: ErrorLogData) => Promise<void>
  /** Default error category */
  defaultCategory?: ErrorDetails['category']
}
