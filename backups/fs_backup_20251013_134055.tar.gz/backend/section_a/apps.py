from django.apps import AppConfig


class SectionAConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'section_a'
