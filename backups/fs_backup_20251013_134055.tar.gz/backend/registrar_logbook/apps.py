from django.apps import AppConfig


class RegistrarLogbookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'registrar_logbook'
