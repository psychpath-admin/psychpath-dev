export interface CityInfo {
  state: string;
  timezone: string;
}

export const cityToStateTimezone: Record<string, CityInfo> = {
  // Major Cities
  "Melbourne": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Sydney": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Brisbane": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Hobart": { state: "Tasmania", timezone: "Australia/Hobart" },
  "Darwin": { state: "Northern Territory", timezone: "Australia/Darwin" },
  "Perth": { state: "Western Australia", timezone: "Australia/Perth" },
  "Adelaide": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Canberra": { state: "Australian Capital Territory", timezone: "Australia/Sydney" },
  
  // Regional Cities - Victoria
  "Geelong": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Ballarat": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Bendigo": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Warrnambool": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Shepparton": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Mildura": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Wodonga": { state: "Victoria", timezone: "Australia/Melbourne" },
  "Traralgon": { state: "Victoria", timezone: "Australia/Melbourne" },
  
  // Regional Cities - New South Wales
  "Newcastle": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Wollongong": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Wagga Wagga": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Albury": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Maitland": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Tamworth": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Orange": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Dubbo": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Lismore": { state: "New South Wales", timezone: "Australia/Sydney" },
  "Bathurst": { state: "New South Wales", timezone: "Australia/Sydney" },
  
  // Regional Cities - Queensland
  "Gold Coast": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Townsville": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Cairns": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Toowoomba": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Rockhampton": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Mackay": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Bundaberg": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Coffs Harbour": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Hervey Bay": { state: "Queensland", timezone: "Australia/Brisbane" },
  "Gladstone": { state: "Queensland", timezone: "Australia/Brisbane" },
  
  // Regional Cities - Western Australia
  "Fremantle": { state: "Western Australia", timezone: "Australia/Perth" },
  "Rockingham": { state: "Western Australia", timezone: "Australia/Perth" },
  "Mandurah": { state: "Western Australia", timezone: "Australia/Perth" },
  "Bunbury": { state: "Western Australia", timezone: "Australia/Perth" },
  "Geraldton": { state: "Western Australia", timezone: "Australia/Perth" },
  "Albany": { state: "Western Australia", timezone: "Australia/Perth" },
  "Kalgoorlie": { state: "Western Australia", timezone: "Australia/Perth" },
  "Broome": { state: "Western Australia", timezone: "Australia/Perth" },
  
  // Regional Cities - South Australia
  "Mount Gambier": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Whyalla": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Murray Bridge": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Port Augusta": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Port Pirie": { state: "South Australia", timezone: "Australia/Adelaide" },
  "Port Lincoln": { state: "South Australia", timezone: "Australia/Adelaide" },
  
  // Regional Cities - Tasmania
  "Launceston": { state: "Tasmania", timezone: "Australia/Hobart" },
  "Devonport": { state: "Tasmania", timezone: "Australia/Hobart" },
  "Burnie": { state: "Tasmania", timezone: "Australia/Hobart" },
  "Ulverstone": { state: "Tasmania", timezone: "Australia/Hobart" },
  
  // Regional Cities - Northern Territory
  "Alice Springs": { state: "Northern Territory", timezone: "Australia/Darwin" },
  "Katherine": { state: "Northern Territory", timezone: "Australia/Darwin" },
  "Nhulunbuy": { state: "Northern Territory", timezone: "Australia/Darwin" },
};

export function getCityInfo(city: string): CityInfo | null {
  return cityToStateTimezone[city] || null;
}

export function getCitiesByState(): Record<string, string[]> {
  const citiesByState: Record<string, string[]> = {};
  
  Object.entries(cityToStateTimezone).forEach(([city, info]) => {
    if (!citiesByState[info.state]) {
      citiesByState[info.state] = [];
    }
    citiesByState[info.state].push(city);
  });
  
  return citiesByState;
}

export const cityOptions = Object.keys(cityToStateTimezone).sort();

