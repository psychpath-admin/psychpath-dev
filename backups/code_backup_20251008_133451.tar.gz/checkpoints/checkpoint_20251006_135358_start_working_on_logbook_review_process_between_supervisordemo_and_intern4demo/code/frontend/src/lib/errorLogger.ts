import { apiFetch } from './api'

export interface ErrorLogEntry {
  userId?: string
  userRole?: string
  pagePath: string
  timestamp: string
  errorType: 'ValidationError' | 'ServerError' | 'NetworkError' | 'ClientError' | 'UnknownError'
  errorMessage: string
  stackTrace?: string
  affectedComponent?: string
  userAgent: string
  additionalData?: Record<string, any>
}

class ErrorLogger {
  private isLogging = false

  async logError(error: Error, context: Partial<ErrorLogEntry> = {}): Promise<void> {
    if (this.isLogging) {
      console.warn('Error logging already in progress, skipping duplicate log')
      return
    }

    this.isLogging = true

    try {
      const errorEntry: ErrorLogEntry = {
        pagePath: window.location.pathname,
        timestamp: new Date().toISOString(),
        errorType: this.categorizeError(error),
        errorMessage: error.message || 'Unknown error occurred',
        stackTrace: error.stack,
        userAgent: navigator.userAgent,
        ...context
      }

      // Log to console for development
      console.error('PsychPATH Error Logged:', errorEntry)

      // Send to backend audit log
      await this.sendToBackend(errorEntry)
    } catch (loggingError) {
      console.error('Failed to log error:', loggingError)
    } finally {
      this.isLogging = false
    }
  }

  private categorizeError(error: Error): ErrorLogEntry['errorType'] {
    if (error.name === 'ValidationError') return 'ValidationError'
    if (error.name === 'TypeError' && error.message.includes('fetch')) return 'NetworkError'
    if (error.message.includes('500') || error.message.includes('Internal Server Error')) return 'ServerError'
    if (error.message.includes('400') || error.message.includes('Bad Request')) return 'ValidationError'
    if (error.message.includes('401') || error.message.includes('Unauthorized')) return 'ValidationError'
    if (error.message.includes('403') || error.message.includes('Forbidden')) return 'ValidationError'
    if (error.message.includes('404') || error.message.includes('Not Found')) return 'ClientError'
    return 'UnknownError'
  }

  private async sendToBackend(errorEntry: ErrorLogEntry): Promise<void> {
    try {
      await apiFetch('/api/audit-log/errors/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(errorEntry)
      })
    } catch (error) {
      // If backend logging fails, store locally as fallback
      this.storeLocally(errorEntry)
    }
  }

  private storeLocally(errorEntry: ErrorLogEntry): void {
    try {
      const existingLogs = JSON.parse(localStorage.getItem('psychpath_error_logs') || '[]')
      existingLogs.push(errorEntry)
      
      // Keep only last 50 errors to prevent storage bloat
      if (existingLogs.length > 50) {
        existingLogs.splice(0, existingLogs.length - 50)
      }
      
      localStorage.setItem('psychpath_error_logs', JSON.stringify(existingLogs))
    } catch (error) {
      console.error('Failed to store error locally:', error)
    }
  }

  // Get user context for error logging
  async getUserContext(): Promise<{ userId?: string; userRole?: string }> {
    try {
      const response = await apiFetch('/api/me/')
      if (response.ok) {
        const userData = await response.json()
        return {
          userId: userData.id?.toString(),
          userRole: userData.role
        }
      }
    } catch (error) {
      // User context not available, continue without it
    }
    return {}
  }
}

// Global error handler
export const setupGlobalErrorHandling = () => {
  const errorLogger = new ErrorLogger()

  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', async (event) => {
    const error = event.reason instanceof Error ? event.reason : new Error(String(event.reason))
    const userContext = await errorLogger.getUserContext()
    await errorLogger.logError(error, {
      ...userContext,
      affectedComponent: 'Global Promise Rejection'
    })
  })

  // Handle uncaught errors
  window.addEventListener('error', async (event) => {
    const error = new Error(event.message)
    error.stack = event.error?.stack
    const userContext = await errorLogger.getUserContext()
    await errorLogger.logError(error, {
      ...userContext,
      affectedComponent: 'Global Error Handler'
    })
  })

  return errorLogger
}

export const errorLogger = new ErrorLogger()
export default errorLogger
