import React from 'react'
import { AlertTriangle, X, HelpCircle } from 'lucide-react'
import type { ErrorOverlayProps } from './types'

/**
 * Universal Error Overlay Component
 * 
 * Displays a 3-part error message with consistent PsychPATH styling:
 * 1. What is the error (title)
 * 2. Why it occurred (explanation) 
 * 3. What you need to do to fix it (userAction)
 */
export const ErrorOverlay: React.FC<ErrorOverlayProps> = ({
  error,
  isOpen,
  onClose,
  onGetHelp,
  helpUrl = '/help/errors',
  openInNewTab = true
}) => {
  if (!isOpen) return null

  const handleGetHelp = () => {
    if (onGetHelp) {
      onGetHelp()
      return
    }

    // Close the overlay first
    onClose()

    // Build URL with error details for highlighting
    const params = new URLSearchParams()
    if (error.errorId) {
      params.set('errorId', error.errorId)
    }
    if (error.summary) {
      params.set('summary', error.summary)
    }
    if (error.explanation) {
      params.set('explanation', error.explanation)
    }
    if (error.userAction) {
      params.set('userAction', error.userAction)
    }

    const fullHelpUrl = params.toString() ? `${helpUrl}?${params.toString()}` : helpUrl

    if (openInNewTab) {
      window.open(fullHelpUrl, '_blank')
    } else {
      window.location.href = fullHelpUrl
    }
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" style={{ pointerEvents: 'auto' }}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] border border-red-200 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-100 rounded-full">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">
              {error.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Error Content - Scrollable */}
        <div className="p-6 space-y-4 flex-1 overflow-y-auto">
          {/* What is the error */}
          <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
            <h3 className="font-medium text-red-800 mb-2">What is the error?</h3>
            <p className="text-red-700 text-sm">{error.summary}</p>
          </div>

          {/* Why it occurred */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg">
            <h3 className="font-medium text-blue-800 mb-2">Why it occurred</h3>
            <p className="text-blue-700 text-sm">{error.explanation}</p>
          </div>

          {/* What you can do */}
          <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded-r-lg">
            <h3 className="font-medium text-green-800 mb-2">What you can do</h3>
            <p className="text-green-700 text-sm whitespace-pre-line">{error.userAction}</p>
          </div>
        </div>

        {/* Actions - Fixed at bottom */}
        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50 rounded-b-xl flex-shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            I Understand
          </button>
          <button
            onClick={handleGetHelp}
            onPointerDown={(e) => {
              e.preventDefault()
              e.stopPropagation()
              handleGetHelp()
            }}
            className="px-4 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 transition-colors font-medium inline-flex items-center gap-2"
          >
            <HelpCircle className="w-4 h-4" />
            I Need More Help
          </button>
        </div>
      </div>
    </div>
  )
}

export default ErrorOverlay
