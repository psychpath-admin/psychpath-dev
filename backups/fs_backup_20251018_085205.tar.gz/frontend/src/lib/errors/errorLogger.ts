import type { ErrorLogData, ErrorDetails, ErrorHandlerConfig } from './types'

/**
 * Error Logging Utility
 * 
 * Handles automatic error logging to the support audit trail
 * with fallback mechanisms and error context capture
 */

let config: ErrorHandlerConfig = {
  helpBaseUrl: '/help/errors',
  autoLogErrors: true,
  defaultCategory: 'General'
}

/**
 * Configure the error handler
 */
export const configureErrorHandler = (newConfig: Partial<ErrorHandlerConfig>) => {
  config = { ...config, ...newConfig }
}

/**
 * Default error logging function that calls the API
 */
const defaultLogError = async (errorData: ErrorLogData): Promise<void> => {
  try {
    const response = await fetch('/api/audit-log/errors/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
      },
      body: JSON.stringify({
        ...errorData,
        page_url: errorData.page_url || window.location.href,
        additional_context: {
          ...errorData.additional_context,
          user_agent: navigator.userAgent,
          timestamp: new Date().toISOString(),
          url: window.location.href,
          referrer: document.referrer
        }
      })
    })

    if (!response.ok) {
      console.error('Failed to log error to support audit trail:', response.status)
    }
  } catch (error) {
    console.error('Error logging error:', error)
  }
}

/**
 * Log an error to the support audit trail
 */
export const logError = async (errorDetails: ErrorDetails): Promise<void> => {
  if (!config.autoLogErrors) return

  try {
    const errorData: ErrorLogData = {
      error_id: errorDetails.errorId || `ERROR_${Date.now()}`,
      error_title: errorDetails.title,
      error_summary: errorDetails.summary,
      error_explanation: errorDetails.explanation,
      user_action: errorDetails.userAction,
      page_url: window.location.href,
      additional_context: {
        ...errorDetails.context,
        category: errorDetails.category || config.defaultCategory,
        user_agent: navigator.userAgent,
        timestamp: new Date().toISOString()
      }
    }

    const logFunction = config.logErrorFunction || defaultLogError
    await logFunction(errorData)
  } catch (error) {
    console.error('Failed to log error:', error)
  }
}

/**
 * Create a standardized error from various error types
 */
export const createErrorDetails = (
  error: Error | string | any,
  context?: {
    title?: string
    category?: ErrorDetails['category']
    customExplanation?: string
    customUserAction?: string
  }
): ErrorDetails => {
  const title = context?.title || 'An error occurred'
  const category = context?.category || config.defaultCategory || 'General'

  // Handle different error types
  if (typeof error === 'string') {
    return {
      errorId: `STRING_ERROR_${Date.now()}`,
      title,
      summary: error,
      explanation: context?.customExplanation || 'This error was triggered by the application.',
      userAction: context?.customUserAction || 'Please try again or contact support if the issue persists.',
      category,
      context: { originalError: error }
    }
  }

  if (error instanceof Error) {
    return {
      errorId: `ERROR_${Date.now()}`,
      title,
      summary: error.message,
      explanation: context?.customExplanation || 'An unexpected error occurred while processing your request.',
      userAction: context?.customUserAction || 'Please try again or contact support if the issue persists.',
      category,
      context: { 
        originalError: error.message,
        stack: error.stack,
        name: error.name
      }
    }
  }

  // Handle API errors
  if (error?.response || error?.status) {
    const status = error.status || error.response?.status
    const message = error.message || error.response?.data?.message || 'API request failed'
    
    return {
      errorId: `API_ERROR_${status}_${Date.now()}`,
      title: `API Error (${status})`,
      summary: message,
      explanation: context?.customExplanation || `The server returned an error with status code ${status}.`,
      userAction: context?.customUserAction || 'Please check your connection and try again. If the problem persists, contact support.',
      category: 'Network',
      context: { 
        status,
        originalError: error,
        url: error.config?.url
      }
    }
  }

  // Fallback for unknown error types
  return {
    errorId: `UNKNOWN_ERROR_${Date.now()}`,
    title,
    summary: 'An unexpected error occurred',
    explanation: context?.customExplanation || 'Something went wrong that we didn\'t expect.',
    userAction: context?.customUserAction || 'Please try again or contact support if the issue persists.',
    category,
    context: { originalError: error }
  }
}

/**
 * Show error overlay with automatic logging
 */
export const showErrorOverlay = async (
  error: Error | string | any,
  context?: {
    title?: string
    category?: ErrorDetails['category']
    customExplanation?: string
    customUserAction?: string
  }
): Promise<ErrorDetails> => {
  const errorDetails = createErrorDetails(error, context)
  await logError(errorDetails)
  return errorDetails
}
