# PsychPATH Universal Error Handling Module

A complete, reusable error handling system that provides consistent error management across the entire application.

## Features

- **3-Part Error Structure**: Clear, user-friendly error messages with "What is the error", "Why it occurred", and "What you can do"
- **Automatic Error Logging**: All errors are automatically logged to the support audit trail
- **Error Help Page**: Comprehensive help page with error database and support form
- **Error Highlighting**: Specific errors are highlighted when navigating from error overlays
- **Consistent UX**: Standardized error handling across all components
- **Easy Integration**: Simple hooks and components for quick implementation

## Quick Start

### 1. Basic Usage with Hook

```tsx
import { useErrorHandler } from '@/lib/errors'

function MyComponent() {
  const { errorOverlay, showError, hideError } = useErrorHandler()

  const handleSubmit = async () => {
    try {
      await submitData()
    } catch (error) {
      // Automatically shows error overlay and logs to audit trail
      await showError(error, {
        title: 'Submission Failed',
        category: 'Validation'
      })
    }
  }

  return (
    <div>
      <button onClick={handleSubmit}>Submit</button>
      
      {/* Error overlay is automatically managed */}
      <ErrorOverlay {...errorOverlay} />
    </div>
  )
}
```

### 2. API Error Handling

```tsx
import { useErrorHandler } from '@/lib/errors'

function ApiComponent() {
  const { handleApiError } = useErrorHandler()

  const fetchData = async () => {
    try {
      const response = await api.get('/data')
      return response.data
    } catch (error) {
      // Automatically categorizes API errors and shows appropriate messages
      await handleApiError(error, {
        title: 'Failed to Load Data',
        customExplanation: 'Unable to retrieve your data from the server.',
        customUserAction: 'Please check your connection and try again.'
      })
    }
  }

  return <div>...</div>
}
```

### 3. Custom Error Details

```tsx
import { useErrorHandler, ErrorDetails } from '@/lib/errors'

function CustomErrorComponent() {
  const { showCustomError } = useErrorHandler()

  const handleCustomError = async () => {
    const errorDetails: ErrorDetails = {
      errorId: 'CUSTOM_VALIDATION_ERROR',
      title: 'Invalid Input',
      summary: 'The email address format is invalid',
      explanation: 'The email address you entered does not match the required format.',
      userAction: 'Please enter a valid email address (e.g., user@example.com)',
      category: 'Validation',
      context: { field: 'email', value: 'invalid-email' }
    }

    await showCustomError(errorDetails)
  }

  return <button onClick={handleCustomError}>Trigger Custom Error</button>
}
```

### 4. Error Help Page

```tsx
import { ErrorHelpPage } from '@/lib/errors'

function HelpPage() {
  return (
    <ErrorHelpPage 
      showSupportForm={true}
      // Custom error database (optional)
      errorDatabase={myCustomErrors}
    />
  )
}
```

### 5. Configuration

```tsx
import { configureErrorHandler } from '@/lib/errors'

// Configure the error handler
configureErrorHandler({
  helpBaseUrl: '/help/errors',
  autoLogErrors: true,
  defaultCategory: 'General',
  logErrorFunction: async (errorData) => {
    // Custom logging function
    await myCustomLogger.log(errorData)
  }
})
```

## Components

### ErrorOverlay

A modal overlay that displays error information in a structured format.

**Props:**
- `error: ErrorDetails` - Error information to display
- `isOpen: boolean` - Whether the overlay is visible
- `onClose: () => void` - Callback when user clicks "I Understand"
- `onGetHelp?: () => void` - Custom help handler
- `helpUrl?: string` - Custom help page URL (default: '/help/errors')
- `openInNewTab?: boolean` - Whether to open help in new tab (default: true)

### ErrorHelpPage

A comprehensive help page with error database and support form.

**Props:**
- `initialError?: ErrorDetails` - Error to highlight initially
- `showSupportForm?: boolean` - Whether to show support form (default: true)
- `errorDatabase?: ErrorEntry[]` - Custom error database

## Hooks

### useErrorHandler

Main hook for error handling functionality.

**Returns:**
- `errorOverlay: ErrorOverlayProps` - Current error overlay state
- `showError(error, context?)` - Show error with automatic logging
- `showCustomError(errorDetails)` - Show custom error details
- `hideError()` - Hide current error overlay
- `handleApiError(error, context?)` - Handle API errors with categorization

## Utilities

### logError

Log an error to the support audit trail.

```tsx
import { logError } from '@/lib/errors'

await logError({
  errorId: 'MY_ERROR',
  title: 'Something went wrong',
  summary: 'Brief description',
  explanation: 'Detailed explanation',
  userAction: 'Steps to resolve',
  category: 'General'
})
```

### createErrorDetails

Create standardized error details from various error types.

```tsx
import { createErrorDetails } from '@/lib/errors'

const errorDetails = createErrorDetails(new Error('Something failed'), {
  title: 'Custom Title',
  category: 'Validation'
})
```

## Error Categories

- `Validation` - Input validation errors
- `Network` - Network/API errors
- `Server` - Server-side errors
- `Client` - Client-side errors
- `General` - General errors
- `System` - System-level errors

## Integration Examples

### With React Query

```tsx
import { useErrorHandler } from '@/lib/errors'
import { useQuery } from '@tanstack/react-query'

function DataComponent() {
  const { handleApiError } = useErrorHandler()
  
  const { data, error } = useQuery({
    queryKey: ['data'],
    queryFn: fetchData,
    onError: (error) => {
      handleApiError(error, {
        title: 'Failed to Load Data',
        customExplanation: 'Unable to retrieve data from the server.'
      })
    }
  })

  return <div>{data && <div>{data}</div>}</div>
}
```

### With Form Validation

```tsx
import { useErrorHandler } from '@/lib/errors'

function FormComponent() {
  const { showError } = useErrorHandler()
  
  const handleSubmit = async (data) => {
    try {
      await validateForm(data)
      await submitForm(data)
    } catch (error) {
      if (error.type === 'validation') {
        await showError(error, {
          title: 'Validation Error',
          category: 'Validation',
          customExplanation: 'Please check your input and try again.',
          customUserAction: 'Review the highlighted fields and correct any errors.'
        })
      }
    }
  }

  return <form onSubmit={handleSubmit}>...</form>
}
```

## Best Practices

1. **Use the hook**: Always use `useErrorHandler` for consistent error handling
2. **Provide context**: Include meaningful titles and explanations
3. **Categorize errors**: Use appropriate error categories for better organization
4. **Test error flows**: Ensure error overlays work correctly in your components
5. **Customize messages**: Provide user-friendly, actionable error messages
6. **Log everything**: Let the system automatically log errors for debugging

## Migration from Existing Error Handling

If you have existing error handling, you can gradually migrate:

1. Replace `alert()` calls with `showError()`
2. Replace custom error dialogs with `ErrorOverlay`
3. Add error logging to existing try-catch blocks
4. Update error pages to use `ErrorHelpPage`

The module is designed to be backward-compatible and can be integrated incrementally.
