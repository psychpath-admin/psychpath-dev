import React, { useState, useEffect } from 'react'
import { AlertTriangle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import type { ErrorHelpPageProps, ErrorEntry } from './types'

/**
 * Error Help Page Component
 * 
 * Displays a comprehensive error help page with:
 * - Error database with search functionality
 * - Error highlighting for specific errors
 * - Support form for additional help
 * - Custom error display from URL parameters
 */

// Default error database
const defaultErrorDatabase: ErrorEntry[] = [
  {
    id: 'LOGBOOK_SUBMIT_REJECTED',
    summary: 'Logbook cannot be submitted because it is marked as rejected',
    explanation: 'The logbook has been rejected by your supervisor and cannot be resubmitted in its current state.',
    stepsToResolve: [
      'Check if your supervisor has provided feedback',
      'Review the rejection comments',
      'Make necessary corrections to your logbook',
      'Contact your supervisor if you need clarification'
    ],
    category: 'Validation',
    frequency: 15
  },
  {
    id: 'LOGBOOK_SUBMIT_DRAFT',
    summary: 'Logbook cannot be submitted because it is still in draft status',
    explanation: 'The logbook needs to be completed and marked as ready before submission.',
    stepsToResolve: [
      'Complete all required sections',
      'Review your entries for accuracy',
      'Mark the logbook as ready',
      'Then submit for supervisor review'
    ],
    category: 'Validation',
    frequency: 12
  },
  {
    id: 'NETWORK_ERROR',
    summary: 'Network connection error',
    explanation: 'Unable to connect to the server. This could be due to internet connectivity issues or server maintenance.',
    stepsToResolve: [
      'Check your internet connection',
      'Try refreshing the page',
      'Wait a few minutes and try again',
      'Contact support if the issue persists'
    ],
    category: 'Network',
    frequency: 8
  },
  {
    id: 'AUTHENTICATION_ERROR',
    summary: 'Authentication failed',
    explanation: 'Your session has expired or your login credentials are invalid.',
    stepsToResolve: [
      'Log out and log back in',
      'Clear your browser cache and cookies',
      'Check if your password is correct',
      'Contact support if you cannot log in'
    ],
    category: 'Client',
    frequency: 6
  },
  {
    id: 'SERVER_ERROR',
    summary: 'Internal server error',
    explanation: 'The server encountered an unexpected error while processing your request.',
    stepsToResolve: [
      'Try refreshing the page',
      'Wait a few minutes and try again',
      'Check if other users are experiencing the same issue',
      'Contact support with the error details'
    ],
    category: 'Server',
    frequency: 4
  }
]

export const ErrorHelpPage: React.FC<ErrorHelpPageProps> = ({
  showSupportForm = true,
  errorDatabase = defaultErrorDatabase
}) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedError, setSelectedError] = useState<ErrorEntry | null>(null)
  const [highlightedErrorId, setHighlightedErrorId] = useState<string | null>(null)
  const [customError, setCustomError] = useState<ErrorEntry | null>(null)
  const [supportForm, setSupportForm] = useState({
    subject: '',
    description: '',
    errorId: '',
    userEmail: ''
  })

  // Helper function to scroll to error and show details section
  const scrollToErrorWithDetails = (errorId: string) => {
    setTimeout(() => {
      const element = document.getElementById(`error-${errorId}`)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' })
        // Add a highlight effect
        element.classList.add('ring-2', 'ring-yellow-400')
        setTimeout(() => {
          element.classList.remove('ring-2', 'ring-yellow-400')
        }, 3000)
      }
    }, 100)
  }

  // Read URL parameters and highlight matching error
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const errorId = urlParams.get('errorId')
    const summary = urlParams.get('summary')
    const explanation = urlParams.get('explanation')
    const userAction = urlParams.get('userAction')
    
    // If we have explanation and userAction from URL, create a custom error entry
    if (explanation && userAction) {
      const customErrorEntry: ErrorEntry = {
        id: errorId || 'CUSTOM-ERROR',
        summary: summary || 'Custom Error',
        explanation: explanation,
        stepsToResolve: userAction.split('\n').filter(step => step.trim()),
        category: 'General',
        frequency: 1
      }
      setCustomError(customErrorEntry)
      setSelectedError(customErrorEntry)
      setHighlightedErrorId(customErrorEntry.id)
      // Pre-fill support form with error details
      setSupportForm(prev => ({
        ...prev,
        subject: `Error: ${customErrorEntry.summary}`,
        errorId: customErrorEntry.id,
        description: `I encountered this error: ${customErrorEntry.summary}\n\n${customErrorEntry.explanation}`
      }))
      return
    }
    
    if (errorId) {
      // Try to find exact match by errorId
      const exactMatch = errorDatabase.find(error => error.id === errorId)
      if (exactMatch) {
        setSelectedError(exactMatch)
        setHighlightedErrorId(errorId)
        // Pre-fill support form with error details
        setSupportForm(prev => ({
          ...prev,
          subject: `Error: ${exactMatch.summary}`,
          errorId: exactMatch.id,
          description: `I encountered this error: ${exactMatch.summary}\n\n${exactMatch.explanation}`
        }))
        // Scroll to the error and ensure details section is visible
        scrollToErrorWithDetails(errorId)
        return
      }
    }
    
    if (summary) {
      // Try to find match by summary text
      const summaryMatch = errorDatabase.find(error => 
        error.summary.toLowerCase().includes(summary.toLowerCase()) ||
        summary.toLowerCase().includes(error.summary.toLowerCase())
      )
      if (summaryMatch) {
        setSelectedError(summaryMatch)
        setHighlightedErrorId(summaryMatch.id)
        // Pre-fill support form with error details
        setSupportForm(prev => ({
          ...prev,
          subject: `Error: ${summaryMatch.summary}`,
          errorId: summaryMatch.id,
          description: `I encountered this error: ${summaryMatch.summary}\n\n${summaryMatch.explanation}`
        }))
        // Scroll to the error and ensure details section is visible
        scrollToErrorWithDetails(summaryMatch.id)
        return
      }
    }
    
    // If no exact match, try to find by keywords from the error
    if (summary) {
      const keywords = summary.toLowerCase().split(' ')
      const keywordMatch = errorDatabase.find(error => 
        keywords.some(keyword => 
          error.summary.toLowerCase().includes(keyword) ||
          error.explanation.toLowerCase().includes(keyword)
        )
      )
      if (keywordMatch) {
        setSelectedError(keywordMatch)
        setHighlightedErrorId(keywordMatch.id)
        // Pre-fill support form with error details
        setSupportForm(prev => ({
          ...prev,
          subject: `Error: ${keywordMatch.summary}`,
          errorId: keywordMatch.id,
          description: `I encountered this error: ${keywordMatch.summary}\n\n${keywordMatch.explanation}`
        }))
        // Scroll to the error and ensure details section is visible
        scrollToErrorWithDetails(keywordMatch.id)
      }
    }
  }, [])

  // Combine database errors with custom error
  const allErrors = customError ? [customError, ...errorDatabase] : errorDatabase
  
  const filteredErrors = allErrors.filter(error =>
    error.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
    error.explanation.toLowerCase().includes(searchTerm.toLowerCase()) ||
    error.category.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => {
    // If there's a highlighted error, put it first
    if (highlightedErrorId) {
      if (a.id === highlightedErrorId) return -1
      if (b.id === highlightedErrorId) return 1
    }
    // Custom errors should always be at the top
    if (a.id === 'CUSTOM-ERROR') return -1
    if (b.id === 'CUSTOM-ERROR') return 1
    // Otherwise sort by frequency (most common first)
    return b.frequency - a.frequency
  })

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      // Here you would typically send the support request to your backend
      console.log('Support form submitted:', supportForm)
      alert('Support request submitted successfully! We will get back to you soon.')
      
      // Reset form
      setSupportForm({
        subject: '',
        description: '',
        errorId: '',
        userEmail: ''
      })
    } catch (error) {
      console.error('Error submitting support form:', error)
      alert('Failed to submit support request. Please try again.')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-red-100 rounded-full">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Error Help Center</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Find solutions to common errors and get help when you need it. 
            Search through our error database or submit a support request.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Error List */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  Common Errors
                </CardTitle>
                <div className="mt-4">
                  <input
                    type="text"
                    placeholder="Search errors..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {filteredErrors.map((error) => (
                    <div
                      key={error.id}
                      id={`error-${error.id}`}
                      className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                        highlightedErrorId === error.id
                          ? 'border-yellow-300 bg-yellow-50'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                      onClick={() => {
                        setSelectedError(error)
                        setHighlightedErrorId(error.id)
                      }}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium text-gray-900">
                            {error.summary}
                          </h3>
                          {(highlightedErrorId === error.id || error.id === 'CUSTOM-ERROR') && (
                            <span className="px-2 py-1 bg-yellow-200 text-yellow-800 text-xs font-medium rounded-full animate-pulse">
                              Your Error
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {error.explanation}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span className="px-2 py-1 bg-gray-100 rounded-full">
                            {error.category}
                          </span>
                          <span>{error.frequency} reports</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredErrors.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      No errors found matching your search.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Error Details and Support */}
          <div className="space-y-6">
            {/* Error Details */}
            {selectedError && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Error Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">What is the error?</h3>
                      <p className="text-gray-700">{selectedError.summary}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Why it occurred</h3>
                      <p className="text-gray-700">{selectedError.explanation}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Steps to resolve</h3>
                      <ol className="list-decimal list-inside space-y-1 text-gray-700">
                        {selectedError.stepsToResolve.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Support Form */}
            {showSupportForm && (
              <Card>
                <CardHeader>
                  <CardTitle>Need More Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSupportSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Subject
                      </label>
                      <input
                        type="text"
                        value={supportForm.subject}
                        onChange={(e) => setSupportForm(prev => ({ ...prev, subject: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Error ID (if known)
                      </label>
                      <input
                        type="text"
                        value={supportForm.errorId}
                        onChange={(e) => setSupportForm(prev => ({ ...prev, errorId: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea
                        value={supportForm.description}
                        onChange={(e) => setSupportForm(prev => ({ ...prev, description: e.target.value }))}
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Describe the error and what you were trying to do..."
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Your Email
                      </label>
                      <input
                        type="email"
                        value={supportForm.userEmail}
                        onChange={(e) => setSupportForm(prev => ({ ...prev, userEmail: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Submit Support Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default ErrorHelpPage
