/**
 * Token utility functions for JWT management
 * Prevents authentication loops and handles token expiration gracefully
 */

export interface TokenPayload {
  exp: number
  iat: number
  token_type: string
  user_id: number
  jti: string
}

/**
 * Decode JWT token without verification (for client-side expiration check)
 */
export function decodeToken(token: string): TokenPayload | null {
  try {
    const base64Url = token.split('.')[1]
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    )
    return JSON.parse(jsonPayload)
  } catch (error) {
    console.warn('Failed to decode token:', error)
    return null
  }
}

/**
 * Check if token is expired (with 5 minute buffer for refresh)
 */
export function isTokenExpired(token: string, bufferMinutes: number = 5): boolean {
  const payload = decodeToken(token)
  if (!payload) return true
  
  const now = Date.now() / 1000 // Convert to seconds
  const expiration = payload.exp
  const buffer = bufferMinutes * 60 // Convert minutes to seconds
  
  return now >= (expiration - buffer)
}

/**
 * Check if token will expire soon (within specified minutes)
 */
export function isTokenExpiringSoon(token: string, minutes: number = 15): boolean {
  const payload = decodeToken(token)
  if (!payload) return true
  
  const now = Date.now() / 1000
  const expiration = payload.exp
  const threshold = minutes * 60
  
  return (expiration - now) <= threshold
}

/**
 * Get time until token expires (in seconds)
 */
export function getTokenTimeToExpiry(token: string): number {
  const payload = decodeToken(token)
  if (!payload) return 0
  
  const now = Date.now() / 1000
  const expiration = payload.exp
  
  return Math.max(0, expiration - now)
}

/**
 * Validate token exists and is not expired
 */
export function isTokenValid(token: string): boolean {
  if (!token) return false
  return !isTokenExpired(token)
}

/**
 * Check if we should attempt token refresh (token exists but expired/expiring)
 */
export function shouldRefreshToken(accessToken: string, refreshToken: string): boolean {
  if (!accessToken || !refreshToken) return false
  
  // Refresh if token is expired or expiring soon
  return isTokenExpired(accessToken) || isTokenExpiringSoon(accessToken)
}

/**
 * Clean up all authentication data
 */
export function clearAuthData(): void {
  localStorage.removeItem('accessToken')
  localStorage.removeItem('refreshToken')
  
  // Clear any other auth-related data
  localStorage.removeItem('userData')
  localStorage.removeItem('lastTokenRefresh')
}

/**
 * Store authentication data with timestamp
 */
export function storeAuthData(accessToken: string, refreshToken: string): void {
  localStorage.setItem('accessToken', accessToken)
  localStorage.setItem('refreshToken', refreshToken)
  localStorage.setItem('lastTokenRefresh', Date.now().toString())
}

/**
 * Get stored tokens with validation
 */
export function getStoredTokens(): { accessToken: string | null; refreshToken: string | null; isValid: boolean } {
  const accessToken = localStorage.getItem('accessToken')
  const refreshToken = localStorage.getItem('refreshToken')
  
  if (!accessToken || !refreshToken) {
    return { accessToken: null, refreshToken: null, isValid: false }
  }
  
  return {
    accessToken,
    refreshToken,
    isValid: isTokenValid(accessToken)
  }
}
