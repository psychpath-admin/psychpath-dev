Checkpoint: setting up section C shortcuts - 20251011_205537
