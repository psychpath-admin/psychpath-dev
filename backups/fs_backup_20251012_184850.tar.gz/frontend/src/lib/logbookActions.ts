import { apiFetch } from './api'

export interface LogbookValidActions {
  can_submit: boolean
  can_approve: boolean
  can_reject: boolean
  can_return_for_edits: boolean
  can_unlock: boolean
  valid_transitions: string[]
  current_status: string
  user_role: string
}

export async function getLogbookValidActions(logbookId: number): Promise<LogbookValidActions> {
  const response = await apiFetch(`/api/logbook/${logbookId}/valid-actions/`)
  
  if (!response.ok) {
    throw new Error('Failed to fetch valid actions')
  }
  
  return response.json()
}
