/**
 * PsychPATH Universal Error Handling Module
 * 
 * A complete, reusable error handling system that provides:
 * - 3-part error message structure (Issue, What This Means, What You Can Do)
 * - Automatic error logging to support audit trail
 * - Error highlighting and help page integration
 * - Consistent UX across the application
 * - Easy integration with any component
 */

// Export all types
export * from './types'

// Export components
export { ErrorOverlay } from './ErrorOverlay'
export { ErrorHelpPage } from './ErrorHelpPage'

// Export utilities
export { 
  logError, 
  createErrorDetails, 
  showErrorOverlay,
  configureErrorHandler 
} from './errorLogger'

// Export hooks
export { useErrorHandler } from './useErrorHandler'

// Default exports for convenience
export { default as ErrorOverlayComponent } from './ErrorOverlay'
export { default as ErrorHelpPageComponent } from './ErrorHelpPage'
export { default as useErrorHandlerHook } from './useErrorHandler'
