from django.apps import AppConfig


class CompetenciesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'competencies'
    verbose_name = 'AHPRA Competencies'
