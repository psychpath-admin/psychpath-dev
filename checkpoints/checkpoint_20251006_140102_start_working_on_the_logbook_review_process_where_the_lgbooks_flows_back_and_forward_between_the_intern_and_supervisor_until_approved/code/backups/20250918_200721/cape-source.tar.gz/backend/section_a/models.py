from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from datetime import datetime, timedelta


class CustomSessionActivityType(models.Model):
    """Custom session activity types created by individual trainees"""
    trainee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='custom_activity_types')
    name = models.CharField(max_length=100, help_text="Custom activity type name")
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['trainee', 'name']
        ordering = ['name']
    
    def __str__(self):
        return f"{self.trainee.username}: {self.name}"

class SectionAEntry(models.Model):
    """Standalone Section A entries for Direct Client Contact and Client Related Activities"""
    
    ENTRY_TYPE_CHOICES = [
        ('client_contact', 'Client Contact'),
        ('simulated_contact', 'Simulated Client Contact'),
        ('independent_activity', 'Independent Client Related Activity'),
        ('cra', 'Client Related Activity'),
    ]
    
    SESSION_ACTIVITY_CHOICES = [
        ('evaluation', 'Evaluation'),
        ('intervention', 'Intervention'),
        ('assessment', 'Assessment'),
        ('consultation', 'Consultation'),
        ('supervision', 'Supervision'),
        ('other', 'Other'),
    ]
    
    # Entry details
    trainee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='section_a_entries')
    entry_type = models.CharField(max_length=20, choices=ENTRY_TYPE_CHOICES, default='client_contact')
    
    # Simulated flag for SDCC (Simulated Direct Client Contact)
    simulated = models.BooleanField(default=False, help_text="True if this is a simulated client contact (SDCC)")
    
    # Link CRA entries to their parent DCC entry
    parent_dcc_entry = models.ForeignKey(
        'self', 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True, 
        related_name='cra_entries',
        help_text="Parent DCC entry for CRA entries"
    )
    
    # Client and session details
    client_id = models.CharField(max_length=50, blank=True, help_text="Client pseudonym e.g., LN-1985-M")
    session_date = models.DateField(null=True, blank=True)
    week_starting = models.DateField(null=True, blank=True, help_text="Week starting date for this session")
    place_of_practice = models.CharField(max_length=200, blank=True)
    
    # Client demographics
    client_age = models.PositiveIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(120)],
        null=True, blank=True
    )
    
    # Session details
    presenting_issues = models.TextField(blank=True, help_text="Detailed description of presenting issues")
    session_activity_types = models.JSONField(
        default=list,
        help_text="List of selected activity types (standard and custom)"
    )
    # Legacy field for backward compatibility
    session_activity_type = models.CharField(
        max_length=20, 
        choices=SESSION_ACTIVITY_CHOICES, 
        default='evaluation',
        blank=True
    )
    duration_minutes = models.PositiveIntegerField(null=True, blank=True, help_text="Duration in minutes")
    reflections_on_experience = models.TextField(blank=True, help_text="Reflections on the experience")
    
    # Legacy fields for backward compatibility
    client_pseudonym = models.CharField(max_length=50, blank=True, help_text="Legacy field")
    activity_description = models.TextField(blank=True, help_text="Legacy field")
    duration_hours = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, help_text="Legacy field")
    reflection = models.TextField(blank=True, help_text="Legacy field")
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-session_date', '-created_at']
        verbose_name = 'Section A Entry'
        verbose_name_plural = 'Section A Entries'
    
    def __str__(self):
        return f"{self.client_id} - {self.get_entry_type_display()} ({self.session_date})"
    
    @staticmethod
    def calculate_week_starting(session_date):
        """
        Calculate week starting date based on session date.
        Week starting = Monday immediately before the session date.
        If session date is Monday, then week starting = session date.
        """
        if isinstance(session_date, str):
            session_date = datetime.strptime(session_date, '%Y-%m-%d').date()
        
        # Get the day of the week (0=Monday, 6=Sunday)
        days_since_monday = session_date.weekday()
        
        # Calculate the Monday of that week
        week_starting = session_date - timedelta(days=days_since_monday)
        
        return week_starting
    
    @classmethod
    def get_simulated_hours_total(cls, trainee):
        """
        Calculate total simulated hours for a trainee.
        Returns the total hours and whether the 60-hour limit has been reached.
        """
        simulated_entries = cls.objects.filter(
            trainee=trainee,
            entry_type__in=['client_contact', 'simulated_contact'],
            simulated=True
        )
        
        total_minutes = 0
        for entry in simulated_entries:
            if entry.duration_minutes:
                total_minutes += entry.duration_minutes
            elif entry.duration_hours:
                total_minutes += int(entry.duration_hours * 60)
        
        total_hours = total_minutes / 60
        limit_reached = total_hours >= 60
        
        return {
            'total_hours': total_hours,
            'total_minutes': total_minutes,
            'limit_reached': limit_reached,
            'remaining_hours': max(0, 60 - total_hours)
        }
    
    def save(self, *args, **kwargs):
        """Auto-calculate week_starting if not provided"""
        if self.session_date and not self.week_starting:
            self.week_starting = self.calculate_week_starting(self.session_date)
        super().save(*args, **kwargs)